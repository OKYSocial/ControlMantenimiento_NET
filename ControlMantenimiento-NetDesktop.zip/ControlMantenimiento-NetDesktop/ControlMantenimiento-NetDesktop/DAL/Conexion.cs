﻿// Clase que nos devuelve la conexion con el proveedor que se desee
namespace ControlMantenimiento_NetDesktop.DAL
{
    public class Conexion
    {
        public static string obtenerConexion
        {
            get
            {
               return System.Configuration.ConfigurationManager.ConnectionStrings["Conexion"].ToString();
            }
        }
    }
}
