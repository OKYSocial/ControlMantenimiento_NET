﻿namespace ControlMantenimiento_NetDesktop
{
    partial class FormCambioClave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCambioClave));
            this.errorPro = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TextBoxConfirmar = new System.Windows.Forms.TextBox();
            this.TextBoxClaveNueva = new System.Windows.Forms.TextBox();
            this.TextBoxClave = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ButtonCancelar = new System.Windows.Forms.Button();
            this.ButtonSalir = new System.Windows.Forms.Button();
            this.ButtonGrabar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // errorPro
            // 
            this.errorPro.ContainerControl = this;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.TextBoxConfirmar);
            this.panel2.Controls.Add(this.TextBoxClaveNueva);
            this.panel2.Controls.Add(this.TextBoxClave);
            this.panel2.Location = new System.Drawing.Point(29, 20);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(602, 208);
            this.panel2.TabIndex = 281;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(168, 139);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 17);
            this.label3.TabIndex = 22;
            this.label3.Text = "Confirmar";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(168, 89);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 17);
            this.label2.TabIndex = 21;
            this.label2.Text = "Clave Nueva";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(168, 37);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 17);
            this.label1.TabIndex = 20;
            this.label1.Text = "Clave Actual";
            // 
            // TextBoxConfirmar
            // 
            this.TextBoxConfirmar.Location = new System.Drawing.Point(281, 135);
            this.TextBoxConfirmar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TextBoxConfirmar.MaxLength = 20;
            this.TextBoxConfirmar.Name = "TextBoxConfirmar";
            this.TextBoxConfirmar.PasswordChar = '*';
            this.TextBoxConfirmar.Size = new System.Drawing.Size(132, 22);
            this.TextBoxConfirmar.TabIndex = 2;
            this.TextBoxConfirmar.TabStop = false;
            // 
            // TextBoxClaveNueva
            // 
            this.TextBoxClaveNueva.Location = new System.Drawing.Point(281, 85);
            this.TextBoxClaveNueva.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TextBoxClaveNueva.MaxLength = 20;
            this.TextBoxClaveNueva.Name = "TextBoxClaveNueva";
            this.TextBoxClaveNueva.PasswordChar = '*';
            this.TextBoxClaveNueva.Size = new System.Drawing.Size(132, 22);
            this.TextBoxClaveNueva.TabIndex = 1;
            this.TextBoxClaveNueva.TabStop = false;
            // 
            // TextBoxClave
            // 
            this.TextBoxClave.Location = new System.Drawing.Point(281, 33);
            this.TextBoxClave.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TextBoxClave.MaxLength = 20;
            this.TextBoxClave.Name = "TextBoxClave";
            this.TextBoxClave.PasswordChar = '*';
            this.TextBoxClave.Size = new System.Drawing.Size(132, 22);
            this.TextBoxClave.TabIndex = 0;
            this.TextBoxClave.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.ButtonCancelar);
            this.panel1.Controls.Add(this.ButtonSalir);
            this.panel1.Controls.Add(this.ButtonGrabar);
            this.panel1.Location = new System.Drawing.Point(29, 224);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(602, 83);
            this.panel1.TabIndex = 282;
            // 
            // ButtonCancelar
            // 
            this.ButtonCancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCancelar.ForeColor = System.Drawing.Color.Black;
            this.ButtonCancelar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonCancelar.Image")));
            this.ButtonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonCancelar.Location = new System.Drawing.Point(260, 21);
            this.ButtonCancelar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ButtonCancelar.Name = "ButtonCancelar";
            this.ButtonCancelar.Size = new System.Drawing.Size(80, 43);
            this.ButtonCancelar.TabIndex = 4;
            this.ButtonCancelar.TabStop = false;
            this.ButtonCancelar.Text = "Cancelar";
            this.ButtonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonCancelar.UseVisualStyleBackColor = false;
            this.ButtonCancelar.Click += new System.EventHandler(this.ButtonCancelar_Click);
            // 
            // ButtonSalir
            // 
            this.ButtonSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.ButtonSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSalir.ForeColor = System.Drawing.Color.Black;
            this.ButtonSalir.Image = ((System.Drawing.Image)(resources.GetObject("ButtonSalir.Image")));
            this.ButtonSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonSalir.Location = new System.Drawing.Point(336, 21);
            this.ButtonSalir.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ButtonSalir.Name = "ButtonSalir";
            this.ButtonSalir.Size = new System.Drawing.Size(80, 43);
            this.ButtonSalir.TabIndex = 6;
            this.ButtonSalir.TabStop = false;
            this.ButtonSalir.Text = "Salir";
            this.ButtonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonSalir.UseVisualStyleBackColor = false;
            this.ButtonSalir.Click += new System.EventHandler(this.ButtonSalir_Click);
            // 
            // ButtonGrabar
            // 
            this.ButtonGrabar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonGrabar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonGrabar.ForeColor = System.Drawing.Color.Black;
            this.ButtonGrabar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonGrabar.Image")));
            this.ButtonGrabar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonGrabar.Location = new System.Drawing.Point(185, 21);
            this.ButtonGrabar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ButtonGrabar.Name = "ButtonGrabar";
            this.ButtonGrabar.Size = new System.Drawing.Size(80, 43);
            this.ButtonGrabar.TabIndex = 3;
            this.ButtonGrabar.TabStop = false;
            this.ButtonGrabar.Text = "Modificar";
            this.ButtonGrabar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonGrabar.UseVisualStyleBackColor = false;
            this.ButtonGrabar.Click += new System.EventHandler(this.ButtonGrabar_Click);
            // 
            // FormCambioClave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 327);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FormCambioClave";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cambio Clave";
            this.Load += new System.EventHandler(this.FormCambioClave_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ErrorProvider errorPro;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button ButtonCancelar;
        private System.Windows.Forms.Button ButtonSalir;
        private System.Windows.Forms.Button ButtonGrabar;
        private System.Windows.Forms.TextBox TextBoxConfirmar;
        private System.Windows.Forms.TextBox TextBoxClaveNueva;
        private System.Windows.Forms.TextBox TextBoxClave;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}