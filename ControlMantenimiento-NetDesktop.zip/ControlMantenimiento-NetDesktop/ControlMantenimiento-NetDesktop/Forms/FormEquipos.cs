﻿using System;
using System.Windows.Forms;
using ControlMantenimiento_NetDesktop.BLL;
using ControlMantenimiento_NetDesktop.BO;
using System.Collections;

namespace ControlMantenimiento_NetDesktop
{
    public partial class FormEquipos : Form
    {
        public FormEquipos()
        {
            InitializeComponent();
            this.TextBoxNombreEquipo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxNombreEquipo_KeyPress);
            this.TextBoxSerie.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxSerie_KeyPress);
            this.DropDownListMarcas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DropDownListMarcas_KeyPress);
            this.DropDownListLineas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DropDownListLineas_KeyPress);
        }

        private Controlador _controlador = Funciones.CrearControlador();
        private bool Grabar;
        private KeyPressEventArgs Tecla = new KeyPressEventArgs('\r'); // Send Enter

        private void FormEquipos_Load(object sender, EventArgs e)
        {
            ArrayList arlListado = new ArrayList();
            ArrayList arlListadoMarcas = new ArrayList();
            ArrayList arlListadoLineas = new ArrayList();
            ArrayList arlListadoEquipos = new ArrayList();

            var controlador = Funciones.CrearControlador();
            arlListado = controlador.ControlProgramacion("CONTROLEQUIPOS");

            for (int i = 0; i < arlListado.Count; i++)
            {
                if (Convert.ToString(arlListado[i]).Trim().Equals("EQUIPOS"))
                {
                    arlListadoEquipos.Add(new CargaCombosListas(arlListado[i + 1].ToString(), arlListado[i + 1].ToString() + " " + arlListado[i + 2].ToString()));
                    i++; i++; 
                }
                else if (Convert.ToString(arlListado[i]).Trim().Equals("LINEAS"))
                {
                    arlListadoLineas.Add(new CargaCombosListas(arlListado[i + 1].ToString(), arlListado[i + 1].ToString() + " " + arlListado[i + 2].ToString()));
                    i++; i++; 
                }
                else if (Convert.ToString(arlListado[i]).Trim().Equals("MARCAS"))
                {
                    arlListadoMarcas.Add(new CargaCombosListas(arlListado[i + 1].ToString(), arlListado[i + 1].ToString() + " " + arlListado[i + 2].ToString()));
                    i++; i++; 
                }
            }
            
            
            ListBoxEquipos.ValueMember = "CODIGO";
            ListBoxEquipos.DisplayMember = "DETALLE";
            ListBoxEquipos.DataSource = arlListadoEquipos;

            DropDownListLineas.ValueMember = "CODIGO";
            DropDownListLineas.DisplayMember = "DETALLE";
            DropDownListLineas.DataSource = arlListadoLineas;

            DropDownListMarcas.ValueMember = "CODIGO";
            DropDownListMarcas.DisplayMember = "DETALLE";
            DropDownListMarcas.DataSource = arlListadoMarcas;
        }

        private void CargarListaSeleccion()
        {
            ListBoxEquipos.ValueMember = "CODIGO";
            ListBoxEquipos.DisplayMember = "DETALLE";
            ListBoxEquipos.DataSource = _controlador.CargarListas("EQUIPOS");
        }

        private void TextBoxNombreEquipo_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (string.IsNullOrEmpty(TextBoxNombreEquipo.Text))
                {
                    Grabar = false;
                    MessageBox.Show(BLL.Mensajes.MensajeCampoRequerido, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxNombreEquipo.Focus();
                    errorPro.SetError(TextBoxNombreEquipo, BLL.Mensajes.MensajeCampoRequerido);
                }
                else
                {
                    TextBoxNombreEquipo.Text = BLL.Funciones.EliminarTabulador(TextBoxNombreEquipo.Text, "MAY");
                    DropDownListMarcas.Focus();
                }
            }
        }

        private void TextBoxSerie_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (string.IsNullOrEmpty(TextBoxSerie.Text))
                {
                    Grabar = false;
                    MessageBox.Show(BLL.Mensajes.MensajeCampoRequerido, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxSerie.Focus();
                    errorPro.SetError(TextBoxSerie, BLL.Mensajes.MensajeCampoRequerido);
                }
                else
                {
                    DropDownListLineas.Focus();
                }
            }
        }

        private void DropDownListMarcas_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                TextBoxSerie.Focus();
            }
        }

        private void DropDownListLineas_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                chkLubricacion.Focus();
            }
        }

        private void ButtonGrabar_Click(object sender, EventArgs e)
        {
            Grabar = true;
            TextBoxNombreEquipo_KeyPress(ButtonGrabar, Tecla);
            if (Grabar)
            {
                TextBoxSerie_KeyPress(ButtonGrabar, Tecla);
                if (Grabar)
                {
                    Guardar(Convert.ToInt32(lblCodigo.Text), (lblCodigo.Text == "0") ? BLL.Mensajes.MensajeGraba : BLL.Mensajes.MensajeActualiza);                  
                }
            }
        }

        private void Guardar(int ElCodigo, string Mensaje)
        {
            int Resultado;
            Equipo equipo = new Equipo();
            equipo.codigoequipo = ElCodigo;
            equipo.nombreequipo = TextBoxNombreEquipo.Text.Trim();
            equipo.codigomarca = Convert.ToInt32(DropDownListMarcas.SelectedValue.ToString());
            equipo.serie = TextBoxSerie.Text.Trim();
            equipo.codigolinea = Convert.ToInt32(DropDownListLineas.SelectedValue.ToString());
            if (chkLubricacion.Checked)
            {
                equipo.lubricacion = 1;
            }
            else
            {
                equipo.lubricacion = 0;
            }

            Resultado = _controlador.Guardar(equipo, "");
            if (Resultado == 0)
            {
                MessageBox.Show(Mensaje, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarListaSeleccion();
                Limpiar();
            }
            else if (Resultado == 1)
            {
                MessageBox.Show(BLL.Mensajes.Mensaje7, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                TextBoxSerie.Focus();
                errorPro.SetError(TextBoxSerie, BLL.Mensajes.Mensaje7);
            }
            else
            {
                MessageBox.Show(BLL.Mensajes.MensajeErrorBD, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }            
        }

        private void Limpiar()
        {
            BLL.Funciones.LimpiarForma(panel2);
            ListBoxEquipos.Visible = false;
            ButtonEliminar.Enabled = false;
            errorPro.Clear();
            lblCodigo.Text = "0";
            chkLubricacion.Checked = false;
            TextBoxNombreEquipo.Focus();
        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void LlenarCampos()
        {
            Equipo equipo = (Equipo)_controlador.ObtenerRegistro(lblCodigo.Text, "EQUIPOS");
            if (equipo != null)
            {
                ButtonEliminar.Enabled = true;
                TextBoxNombreEquipo.Text = equipo.nombreequipo;
                DropDownListMarcas.SelectedValue = equipo.codigomarca.ToString();
                TextBoxSerie.Text = equipo.serie;
                DropDownListLineas.SelectedValue = equipo.codigolinea.ToString();
                if (equipo.lubricacion == 1)
                {
                    chkLubricacion.Checked = true;
                }
                else
                {
                    chkLubricacion.Checked = false;
                }
            }
            TextBoxNombreEquipo.Focus();
        }

        private void ButtonBuscar_Click(object sender, EventArgs e)
        {
            if (ListBoxEquipos.Items.Count != 0)
            {
                ListBoxEquipos.Visible = true;
            }
        }

        private void ListBoxEquipos_DoubleClick(object sender, EventArgs e)
        {
            lblCodigo.Text = ListBoxEquipos.SelectedValue.ToString();
            ListBoxEquipos.Visible = false;
            LlenarCampos();
        }

        private void ButtonSalir_Click(object sender, EventArgs e)
        {
            _controlador = null;
            this.Close();
            this.Dispose();
        }

        private void ButtonEliminar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(BLL.Mensajes.MensajeConfirmarBorrado, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {
                if (_controlador.EliminarRegistro(lblCodigo.Text, "EQUIPOS") == 0)
                {
                    MessageBox.Show(BLL.Mensajes.MensajeBorrado, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CargarListaSeleccion();
                    Limpiar();
                }
                else
                {
                    MessageBox.Show(BLL.Mensajes.MensajeErrorBD, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ButtonAyuda_Click(object sender, EventArgs e)
        {
            /* System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.EnableRaisingEvents = false;
            proc.StartInfo.FileName = "E:/Fuentes CM/ControlMantenimiento-NetDesktop/ControlMantenimiento-NetDesktop/Ayudas/Ayuda.chm";
            proc.Start();
            proc.Dispose();*/

            // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
            // donde descomprimió el archivo descargado de la web
        }

    }
}
    
    

