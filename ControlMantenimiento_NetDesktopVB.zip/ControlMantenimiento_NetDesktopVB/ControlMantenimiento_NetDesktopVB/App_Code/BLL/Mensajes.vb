﻿Option Strict On

' Coleccion de mensajes lanzados por el sistema

Public Class Mensajes
    Public Const MensajeAplicacion As String = "SIMI - SISTEMA DE MANTENIMIENTO INDUSTRIAL"
    Public Const MensajeGraba As String = "El registro ha sido grabado satisfactoriamente"
    Public Const MensajeActualiza As String = "El registro ha sido modificado satisfactoriamente"
    Public Const MensajeBorrado As String = "El registro ha sido eliminado satisfactoriamente"
    Public Const MensajeConfirmarBorrado As String = "¿ Esta seguro que desea eliminar este registro ?"
    Public Const MensajeCampoRequerido As String = "Error, este campo es requerido por favor ingresar la informacion"
    Public Const MensajeErrorBD As String = "Se ha producido un error accesando la base de datos"
    Public Const Mensaje2 As String = "Error, la clave es incorrecta, intente de nuevo"
    Public Const Mensaje3 As String = "Error, esta no es su clave actual, reportese  con el administrador"
    Public Const Mensaje4 As String = "Error, debe ingresar una clave diferente de la anterior"
    Public Const Mensaje5 As String = "Error, esta no es la misma clave digitada en clave nueva"
    Public Const Mensaje6 As String = "Error, primera cifra no puede ser 0"
    Public Const Mensaje7 As String = "Error, esta serie ya esta asignada a otro equipo"
    Public Const Mensaje8 As String = "Error, este nombre ya esta asignado"
    Public Const Mensaje9 As String = "Error, este registro no se puede eliminar ya que esta relacionado en equipos"
    Public Const Mensaje10 As String = "Error, ya existe una programacion para este operario en esta fecha"
    Public Const Mensaje11 As String = "No existen Marcas disponibles para relacionar al equipo"
    Public Const Mensaje12 As String = "No existen Lineas disponibles para relacionar al equipo"
    Public Const Mensaje13 As String = "No existen Operarios disponibles para relacionar al mantenimiento"
    Public Const Mensaje14 As String = "No existen Equipos disponibles para relacionar al mantenimiento"
    Public Const Mensaje15 As String = "Error, documentos no pueden ser menores de 6 digitos"
    Public Const Mensaje16 As String = "Error, correo con formato errado"
    Public Const Mensaje17 As String = "Error, la longitud del telefono debe tener 7 o 10 dígitos"
    Public Const Mensaje18 As String = "Error, no se encontro la foto referenciada en la ruta"
    Public Const Mensaje19 As String = "Error, el formato de la imagen no es valido"
    Public Const Mensaje20 As String = "Error, este operario no se puede eliminar ya que tiene programaciones pendientes"
    Public Const Mensaje21 As String = "Error, por favor ingrese una clave que contenga al menos 6 digitos"
    Public Const Mensaje22 As String = "Error, este equipo no se puede eliminar ya que tiene programacion pendiente por ejecutar"
    Public Const Mensaje23 As String = "Error, existen caracteres numericos en este campo"
    Public Const Mensaje24 As String = "Error, No se encontro la foto referenciada en la ruta"
    Public Const Mensaje25 As String = "Error, caracteres no numericos en este campo"
    Public Const Mensaje26 As String = "Error, este registro ya existe"
    Public Const Mensaje27 As String = "Error, fecha no puede ser menor que la actual"
    Public Const Mensaje28 As String = "Error, La longitud del campo supera los caracteres permitidos"
    Public Const Mensaje29 As String = "Error, El peso de la imagen debe ser tipo 3x4"


End Class
