﻿'Patron de Creacion: Factory Method

Public Class AccesoDatosFactory

    Public Shared Function GetAccesoDatos() As IAccesoDatos
        Return New AccesoDatos
    End Function

End Class
