﻿' Esta es una clase transversal, desde donde se instancia el Factory Method y hay algunas validaciones

Option Strict On

Imports System.Text.RegularExpressions

Public Class Funciones
    Public Shared ValorTipo As String
    Public Shared Fuente As String
    Public Shared PerfilAcceso As Integer
    Public Shared NombreUsuario As String
    Public Shared UsuarioConectado As String

    Public Shared Function CrearControlador() As Controlador
        Dim _accesoDatos As AccesoDatos = CType(AccesoDatosFactory.GetAccesoDatos(), AccesoDatos)
        Return New Controlador(_accesoDatos)
    End Function

    'Funcion para validar campos de formulario vacios
    Public Shared Function Validar_CampoVacio(ByVal Cadena As String) As Boolean
        Dim Vacio As Boolean = False
        Cadena = Cadena.Trim()
        If (String.IsNullOrEmpty(Cadena)) Then
            Vacio = True
        End If
        Return Vacio
    End Function

    'Funcion para eliminar posibles espacios de tabulacion en un campo de texto
    Public Shared Function EliminarTabulador(ByVal Cadena As String, ByVal Conversion As String) As String
        Cadena = Cadena.Trim()
        While (Cadena.IndexOf("  ", 0) <> -1)
            Cadena = (Cadena.Replace("  ", " "))
        End While
        If (Conversion = "MAY") Then
            Cadena = Cadena.ToUpper()
        ElseIf (Conversion = "1MAY") Then 'Organizar primera letra en Mayuscula y siguientes en Minuscula
            Cadena = Cadena.ToLower()
            Cadena = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(Cadena)
        End If
        Return Cadena
    End Function

    'Funcion para validar direcciones de correo electronico
    Public Shared Function Validar_Correo(ByVal Cadena As String) As Boolean
        Cadena = Cadena.Trim()
        Return Regex.IsMatch(Cadena, "^\w+[\+\.\w-]*@([\w-]+\.)*\w+[\w-]*\.([a-z]{2,4}|\d+)$")
    End Function

    'Funcion para limpiar los controles en un formulario (Solo TextBox)
    Public Shared Sub LimpiarForma(ByVal pnl As Panel)
        For Each oControls As Control In pnl.Controls '  If (TypeOf ctl Is TextBox) Then ctl.Text = ""
            If (TypeOf oControls Is TextBox) Then
                oControls.Text = ""
            End If
        Next
    End Sub

    'Funcion para comprobar existencia de caracteres diferentes de letras
    Public Shared Function Validar_SoloLetras(ByVal Cadena As String) As Boolean
        Dim i As Integer
        For i = 0 To Cadena.Length - 1
            If (Char.IsNumber(Cadena(i))) Then
                Validar_SoloLetras = True
                Exit For
            End If
        Next i
    End Function

End Class

