﻿'Este es el Controlador Manager general de todo el sistema. Todo tiene que pasar por esta claseOption Strict On

Public Class Controlador

    Private ReadOnly _accesoDatos As IAccesoDatos

    Sub New(accesoDatos As IAccesoDatos)
        _accesoDatos = accesoDatos
    End Sub

    Public Function CargarListas(ByVal Tabla As String) As ArrayList
        Return _accesoDatos.CargarListas(Tabla)
    End Function

    Public Function ControlProgramacion(ByVal Tabla As String) As ArrayList
        Return _accesoDatos.ControlProgramacion(Tabla)
    End Function

    Public Sub ControlEquipos(ByVal Tabla As String)
        _accesoDatos.ControlProgramacion(Tabla)
    End Sub

    Public Function ValidarTablaVacia(ByVal Tabla As String) As Integer
        Return _accesoDatos.ValidarTablaVacia(Tabla)
    End Function

    'Obtener Registro
    Public Function ObtenerRegistro(ByVal DatoBuscar As String, ByVal Tabla As String) As Object
        Dim objeto As Object = Nothing
        Select Case (Tabla)
            Case "OPERARIOS"
                objeto = _accesoDatos.ObtenerOperario(DatoBuscar)
            Case "EQUIPOS"
                objeto = _accesoDatos.ObtenerEquipo(DatoBuscar)
            Case "MANTENIMIENTO"
                objeto = _accesoDatos.ObtenerMantenimiento(DatoBuscar)
            Case "LISTAVALORES"
                objeto = _accesoDatos.ObtenerListaValores(DatoBuscar)
        End Select
        Return objeto
    End Function

    Public Function ObtenerAcceso(ByVal DatoBuscar As String, ByVal Clave As String) As Operario
        Dim _Operario = New Operario
        _Operario = _accesoDatos.ObtenerAcceso(DatoBuscar, Clave)
        Return _Operario
    End Function

    'Grabar en BD
    Public Function Guardar(ByVal o As Object, ByVal Accion As String) As Integer
        If (o.GetType.ToString() = "ControlMantenimiento_NetDesktopVB.Operario") Then
            Guardar = _accesoDatos.GuardarOperario(CType(o, Operario), Accion, Funciones.UsuarioConectado)
        ElseIf (o.GetType.ToString() = "ControlMantenimiento_NetDesktopVB.Mantenimiento") Then
            Guardar = _accesoDatos.GuardarMantenimiento(CType(o, Mantenimiento), Accion, Funciones.UsuarioConectado)
        ElseIf (o.GetType.ToString() = "ControlMantenimiento_NetDesktopVB.Equipo") Then
            Guardar = _accesoDatos.GuardarEquipo(CType(o, Equipo), Funciones.UsuarioConectado)
        ElseIf (o.GetType.ToString() = "ControlMantenimiento_NetDesktopVB.ListaValores") Then
            Guardar = _accesoDatos.GuardarListaValores(CType(o, ListaValores), Funciones.UsuarioConectado)
        End If
        Return Guardar
    End Function

    Public Function GuardarCambioClave(ByVal ClaveAnterior As String, ByVal ClaveNueva As String) As Integer
        Return _accesoDatos.GuardarCambioClave(Funciones.UsuarioConectado, ClaveAnterior, ClaveNueva)
    End Function

    ' Eliminar Registro
    Public Function EliminarRegistro(ByVal DatoEliminar As String, ByVal Tabla As String) As Integer
        Return _accesoDatos.EliminarRegistro(DatoEliminar, Tabla)
    End Function



End Class

