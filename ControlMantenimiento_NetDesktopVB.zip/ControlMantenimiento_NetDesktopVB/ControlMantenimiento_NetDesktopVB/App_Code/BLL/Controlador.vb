﻿'Este es el Controlador Manager general de todo el sistema. Todo tiene que pasar por esta clase
Option Strict On

Public Class Controlador

    Private ReadOnly _accesoDatos As IAccesoDatos

    Sub New(accesoDatos As IAccesoDatos)
        _accesoDatos = accesoDatos
    End Sub

    Public Function CargarListas(ByVal Tabla As String) As ArrayList
        Return _accesoDatos.CargarListas(Tabla)
    End Function

    Public Function ControlProgramacion(ByVal Tabla As String) As ArrayList
        Return _accesoDatos.ControlProgramacion(Tabla)
    End Function

    Public Function ObtenerAcceso(ByVal DatoBuscar As String, ByVal Clave As String) As Operario
        Return _accesoDatos.ObtenerAcceso(DatoBuscar, Clave)
    End Function

    'Obtener Registro
    Public Function ObtenerRegistro(ByVal DatoBuscar As Integer, ByVal Tabla As String) As Object
        Dim objeto As Object = Nothing
        Select Case (Tabla)
            Case "TBL_OPERARIOS"
                objeto = _accesoDatos.ObtenerOperario(DatoBuscar)
            Case "TBL_EQUIPOS"
                objeto = _accesoDatos.ObtenerEquipo(DatoBuscar)
            Case "TBL_MANTENIMIENTO"
                objeto = _accesoDatos.ObtenerMantenimiento(DatoBuscar)
            Case "TBL_LISTAVALORES"
                objeto = _accesoDatos.ObtenerListaValores(DatoBuscar)
        End Select
        Return objeto
    End Function

    'Grabar en BD
    Public Function GuardarOperario(ByVal _Operario As Operario) As Integer
        Return _accesoDatos.GuardarOperario(_Operario, Funciones.UsuarioConectado)
    End Function

    Public Function GuardarEquipo(ByVal _Equipo As Equipo) As Integer
        Return _accesoDatos.GuardarEquipo(_Equipo, Funciones.UsuarioConectado)
    End Function

    Public Function GuardarListaValores(ByVal _ListaValores As ListaValores) As Integer
        Return _accesoDatos.GuardarListaValores(_ListaValores, Funciones.UsuarioConectado)
    End Function

    Public Function GuardarMantenimiento(ByVal _Mantenimiento As Mantenimiento) As Integer
        Return _accesoDatos.GuardarMantenimiento(_Mantenimiento, Funciones.UsuarioConectado)
    End Function

    Public Function GuardarCambioClave(ByVal ClaveAnterior As String, ByVal ClaveNueva As String) As Integer
        Return _accesoDatos.GuardarCambioClave(Funciones.UsuarioConectado, ClaveAnterior, ClaveNueva)
    End Function

    ' Eliminar Registro
    Public Function EliminarRegistro(ByVal DatoEliminar As Integer, ByVal Tabla As String) As Integer
        Return _accesoDatos.EliminarRegistro(DatoEliminar, Tabla)
    End Function

End Class

