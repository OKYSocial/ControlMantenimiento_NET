﻿Option Strict On

Public Class Operario ' Clase que respresenta la estructura Operarios en BD

    Private _Documento As String
    Private _Nombres As String
    Private _Apellidos As String
    Private _Correo As String
    Private _Telefono As String
    Private _Clave As String
    Private _Perfil As Integer
    Private _Foto As String

    Public Sub New()

    End Sub

    Public Property Documento() As String
        Get
            Return _Documento
        End Get
        Set(ByVal value As String)
            _Documento = value
        End Set
    End Property

    Public Property Nombres() As String
        Get
            Return _Nombres
        End Get
        Set(ByVal value As String)
            _Nombres = value
        End Set
    End Property

    Public Property Apellidos() As String
        Get
            Return _Apellidos
        End Get
        Set(ByVal value As String)
            _Apellidos = value
        End Set
    End Property

    Public Property Correo() As String
        Get
            Return _Correo
        End Get
        Set(ByVal value As String)
            _Correo = value
        End Set
    End Property

    Public Property Telefono() As String
        Get
            Return _Telefono
        End Get
        Set(ByVal value As String)
            _Telefono = value
        End Set
    End Property

    Public Property Clave() As String
        Get
            Return _Clave
        End Get
        Set(ByVal value As String)
            _Clave = value
        End Set
    End Property

    Public Property Perfil() As Integer
        Get
            Return _Perfil
        End Get
        Set(ByVal value As Integer)
            _Perfil = value
        End Set
    End Property

    Public Property Foto() As String
        Get
            Return _Foto
        End Get
        Set(ByVal value As String)
            _Foto = value
        End Set
    End Property

End Class
