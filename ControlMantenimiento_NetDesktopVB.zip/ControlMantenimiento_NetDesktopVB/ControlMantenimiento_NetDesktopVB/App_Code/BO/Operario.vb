﻿Option Strict On

Public Class Operario ' Clase que respresenta la estructura Operarios en BD

    Public Sub New()

    End Sub

    Public Property Operario_id() As Integer

    Public Property Documento() As String

    Public Property Nombres() As String

    Public Property Apellidos() As String

    Public Property Correo() As String

    Public Property Telefono() As String

    Public Property Clave() As String

    Public Property Perfil() As Integer

    Public Property Foto() As String

End Class
