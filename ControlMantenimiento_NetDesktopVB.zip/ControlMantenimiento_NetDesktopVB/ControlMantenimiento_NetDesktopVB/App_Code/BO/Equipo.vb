﻿Option Strict On

Public Class Equipo ' Clase que respresenta la estructura Equipos en BD

    Public Sub New()

    End Sub

    Public Property CodigoEquipo() As Integer

    Public Property NombreEquipo() As String

    Public Property CodigoMarca() As Integer

    Public Property Serie() As String

    Public Property CodigoLinea() As Integer

    Public Property Lubricacion() As Integer

End Class
