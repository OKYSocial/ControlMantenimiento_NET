﻿' Clase que nos permite cargar Pares de clave y valor para los ComboBox y ListBox
Option Strict On

Public Class CargaCombosListas

    Private _Codigo As String
    Private _Detalle As String

    Public Sub New()

    End Sub

    Public Sub New(ByVal Codigo As String, ByVal Detalle As String)
        _Codigo = Codigo
        _Detalle = Detalle
    End Sub

    Public Property Codigo() As String
        Get
            Return _Codigo
        End Get
        Set(ByVal value As String)
            _Codigo = value
        End Set
    End Property

    Public Property Detalle() As String
        Get
            Return _Detalle
        End Get
        Set(ByVal value As String)
            _Detalle = value
        End Set
    End Property

End Class
