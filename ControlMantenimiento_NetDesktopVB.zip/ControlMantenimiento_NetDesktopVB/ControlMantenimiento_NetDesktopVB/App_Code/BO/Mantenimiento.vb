﻿Option Strict On

Public Class Mantenimiento ' Clase que respresenta la estructura Mantenimiento en BD

    Private _CodigoEquipo As Integer
    Private _Documento As Double
    Private _Fecha As Date
    Private _Observaciones As String

    Public Sub New()

    End Sub

    Public Property CodigoEquipo() As Integer
        Get
            Return _CodigoEquipo
        End Get
        Set(ByVal value As Integer)
            _CodigoEquipo = value
        End Set
    End Property

    Public Property Documento() As Double
        Get
            Return _Documento
        End Get
        Set(ByVal value As Double)
            _Documento = value
        End Set
    End Property

    Public Property Fecha() As Date
        Get
            Return _Fecha
        End Get
        Set(ByVal value As Date)
            _Fecha = value
        End Set
    End Property

    Public Property Observaciones() As String
        Get
            Return _Observaciones
        End Get
        Set(ByVal value As String)
            _Observaciones = value
        End Set
    End Property

End Class
