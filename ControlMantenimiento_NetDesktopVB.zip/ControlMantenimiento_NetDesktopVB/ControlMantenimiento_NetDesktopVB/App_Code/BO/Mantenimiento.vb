﻿Option Strict On

Public Class Mantenimiento ' Clase que respresenta la estructura Mantenimiento en BD

    Public Sub New()

    End Sub

    Public Property Mantenimiento_id() As Integer

    Public Property Equipo_id() As Integer

    Public Property Operario_id() As Integer

    Public Property Fecha() As Date

    Public Property Observaciones() As String

End Class
