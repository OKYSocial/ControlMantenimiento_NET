﻿Option Strict On

Public Class Mantenimiento ' Clase que respresenta la estructura Mantenimiento en BD

    Public Sub New()

    End Sub

    Public Property CodigoEquipo() As Integer

    Public Property Documento() As Double

    Public Property Fecha() As Date

    Public Property Observaciones() As String

End Class
