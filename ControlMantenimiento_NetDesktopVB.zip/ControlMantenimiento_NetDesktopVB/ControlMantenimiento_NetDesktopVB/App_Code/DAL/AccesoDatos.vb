﻿' DAL: Data Access Layer - Capa Acceso Datos

Option Strict On

Imports System.Data.SqlClient
Imports ControlMantenimiento_NetDesktopVB

Public Class AccesoDatos : Implements IAccesoDatos

    Public Sub New()

    End Sub

    Private Shared Cn As SqlConnection
    Private Shared sdr As SqlDataReader
    Private Shared Cmd As SqlCommand

    Private Shared Sub BuscarRegistro(ByVal Tabla As String, ByVal DatoBuscar As Integer)
        Try
            Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
            Cmd = New SqlCommand("SPR_R_BuscarRegistro", Cn)
            Cmd.CommandType = CommandType.StoredProcedure
            Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = Tabla
            Cmd.Parameters.Add("p_DATOBUSCAR", SqlDbType.Int, 4).Value = DatoBuscar
            Cn.Open()
            sdr = Cmd.ExecuteReader()
        Catch
            LiberarRecursos()
        End Try
    End Sub

    Public Function CargarListas(ByVal Tabla As String) As ArrayList Implements IAccesoDatos.CargarListas
        Dim arlLista As New ArrayList()
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_R_CargarCombosListas", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 30).Value = Tabla
                Cn.Open()
                Using sdr = Cmd.ExecuteReader(CommandBehavior.CloseConnection)
                    While (sdr.Read())
                        arlLista.Add(New CargaCombosListas(sdr.GetValue(0).ToString(), (sdr.GetValue(0).ToString()) & " " & sdr.GetValue(1).ToString()))
                    End While
                    sdr.Close()
                    LiberarRecursos()
                End Using
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return arlLista
    End Function

    Public Function ControlProgramacion(ByVal Tabla As String) As ArrayList Implements IAccesoDatos.ControlProgramacion
        Dim arlListControlProgramacion As New ArrayList
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_R_CargarCombosListas", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = Tabla
                Cn.Open()
                Using sdr = Cmd.ExecuteReader(CommandBehavior.CloseConnection)
                    While (sdr.Read())
                        arlListControlProgramacion.Add(sdr.GetValue(2).ToString())
                        arlListControlProgramacion.Add(sdr.GetValue(0).ToString())
                        arlListControlProgramacion.Add(sdr.GetValue(1).ToString())
                    End While
                    sdr.Close()
                    LiberarRecursos()
                End Using
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return arlListControlProgramacion
    End Function

    Public Function ObtenerAcceso(ByVal Documento As String, ByVal Clave As String) As Operario Implements IAccesoDatos.ObtenerAcceso
        Dim _Operario As New Operario
        Try
            Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
            Cmd = New SqlCommand("SPR_R_ObtenerAcceso", Cn)
            Cmd.CommandType = CommandType.StoredProcedure
            Cmd.Parameters.Add("p_DOCUMENTO", SqlDbType.VarChar, 10).Value = Documento
            Cmd.Parameters.Add("p_CLAVE", SqlDbType.VarChar, 20).Value = Clave
            Cn.Open()
            sdr = Cmd.ExecuteReader()
            If (sdr.Read()) Then
                _Operario.Operario_id = Convert.ToInt32(sdr("OPERARIO_ID").ToString())
                _Operario.Nombres = sdr("NOMBRES").ToString()
                _Operario.Apellidos = sdr("APELLIDOS").ToString()
                _Operario.Perfil = Convert.ToInt32(sdr("PERFIL").ToString())
            Else
                _Operario = Nothing
            End If
            LiberarRecursos()
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return _Operario
    End Function

    Public Function ObtenerOperario(ByVal DatoBuscar As Integer) As Operario Implements IAccesoDatos.ObtenerOperario
        Dim _Operario As New Operario
        Try
            BuscarRegistro("TBL_OPERARIOS", DatoBuscar)
            If (sdr.Read()) Then
                _Operario.Operario_id = Convert.ToInt32(sdr("OPERARIO_ID").ToString())
                _Operario.Documento = sdr("DOCUMENTO").ToString()
                _Operario.Nombres = sdr("NOMBRES").ToString()
                _Operario.Apellidos = sdr("APELLIDOS").ToString()
                _Operario.Correo = sdr("CORREO").ToString()
                _Operario.Telefono = sdr("TELEFONO").ToString()
                _Operario.Foto = sdr("FOTO").ToString()
            Else
                _Operario = Nothing
            End If
            sdr.Close()
            LiberarRecursos()
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return _Operario
    End Function

    Public Function GuardarCambioClave(ByVal Documento As Integer, ByVal ClaveAnterior As String, ByVal ClaveNueva As String) As Integer Implements IAccesoDatos.GuardarCambioClave
        GuardarCambioClave = -1
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_U_CambioClave", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_DOCUMENTO", SqlDbType.VarChar, 10).Value = Documento
                Cmd.Parameters.Add("p_CLAVE_ANTERIOR", SqlDbType.VarChar, 20).Value = ClaveAnterior
                Cmd.Parameters.Add("p_CLAVE_NUEVA", SqlDbType.VarChar, 20).Value = ClaveNueva
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                GuardarCambioClave = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                LiberarRecursos()
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return GuardarCambioClave
    End Function

    Public Function GuardarOperario(ByVal _Operario As Operario, ByVal Usuario As Integer) As Integer Implements IAccesoDatos.GuardarOperario
        GuardarOperario = -1
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_IU_Operarios", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_OPERARIO_ID", SqlDbType.Int, 4).Value = _Operario.Operario_id
                Cmd.Parameters.Add("p_DOCUMENTO", SqlDbType.Int, 10).Value = _Operario.Documento
                Cmd.Parameters.Add("p_NOMBRES", SqlDbType.VarChar, 25).Value = _Operario.Nombres
                Cmd.Parameters.Add("p_APELLIDOS", SqlDbType.VarChar, 25).Value = _Operario.Apellidos
                Cmd.Parameters.Add("p_CORREO", SqlDbType.VarChar, 50).Value = _Operario.Correo
                Cmd.Parameters.Add("p_TELEFONO", SqlDbType.Int, 10).Value = _Operario.Telefono
                Cmd.Parameters.Add("p_FOTO", SqlDbType.VarChar, 50).Value = _Operario.Foto
                Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.VarChar, 10).Value = Usuario
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                GuardarOperario = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                LiberarRecursos()
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return GuardarOperario
    End Function

    Public Function ObtenerListaValores(ByVal DatoBuscar As Integer) As ListaValores Implements IAccesoDatos.ObtenerListaValores
        Dim _ListaValores As New ListaValores
        Try
            BuscarRegistro("TBL_LISTAVALORES", DatoBuscar)
            If (sdr.Read()) Then
                _ListaValores.Listavalores_id = Convert.ToInt32(sdr("LISTAVALORES_ID").ToString())
                _ListaValores.Nombre = sdr("NOMBRE").ToString()
                _ListaValores.Descripcion = sdr("DESCRIPCION").ToString()
            Else
                _ListaValores = Nothing
            End If
            sdr.Close()
            LiberarRecursos()
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return _ListaValores
    End Function

    Public Function GuardarListaValores(ByVal _listavalores As ListaValores, ByVal Usuario As Integer) As Integer Implements IAccesoDatos.GuardarListaValores
        GuardarListaValores = -1
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_IU_ListaValores", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_LISTAVALORES_ID", SqlDbType.Int, 10).Value = _listavalores.Listavalores_id
                Cmd.Parameters.Add("p_NOMBRE", SqlDbType.VarChar, 50).Value = _listavalores.Nombre
                Cmd.Parameters.Add("p_DESCRIPCION", SqlDbType.VarChar, 255).Value = _listavalores.Descripcion
                Cmd.Parameters.Add("p_TIPO", SqlDbType.VarChar, 50).Value = _listavalores.Tipo
                Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.VarChar, 10).Value = Usuario
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                GuardarListaValores = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                LiberarRecursos()
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return GuardarListaValores
    End Function

    Public Function ObtenerEquipo(ByVal DatoBuscar As Integer) As Equipo Implements IAccesoDatos.ObtenerEquipo
        Dim _Equipo As New Equipo
        Try
            BuscarRegistro("TBL_EQUIPOS", DatoBuscar)
            If (sdr.Read()) Then
                _Equipo.Equipo_id = Convert.ToInt32(sdr("EQUIPO_ID").ToString())
                _Equipo.Nombre_Equipo = sdr("NOMBRE_EQUIPO").ToString()
                _Equipo.Marca = Convert.ToInt32(sdr("MARCA").ToString())
                _Equipo.Serie = sdr("SERIE").ToString()
                _Equipo.Linea = Convert.ToInt32(sdr("LINEA").ToString())
                If (sdr.GetBoolean(sdr.GetOrdinal("LUBRICACION"))) Then
                    _Equipo.Lubricacion = 1
                End If
            Else
                _Equipo = Nothing
            End If
            sdr.Close()
            LiberarRecursos()
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return _Equipo
    End Function

    Public Function GuardarEquipo(ByVal _Equipo As Equipo, ByVal Usuario As Integer) As Integer Implements IAccesoDatos.GuardarEquipo
        GuardarEquipo = -1
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_IU_Equipos", Cn)
                Cmd.CommandType = CommandType.StoredProcedure

                Cmd.Parameters.Add("p_EQUIPO_ID", SqlDbType.Int, 10).Value = _Equipo.Equipo_id
                Cmd.Parameters.Add("p_NOMBRE_EQUIPO", SqlDbType.VarChar, 50).Value = _Equipo.Nombre_Equipo
                Cmd.Parameters.Add("p_MARCA", SqlDbType.Int, 10).Value = _Equipo.Marca
                Cmd.Parameters.Add("p_SERIE", SqlDbType.VarChar, 20).Value = _Equipo.Serie
                Cmd.Parameters.Add("p_LINEA", SqlDbType.Int, 10).Value = _Equipo.Linea
                Cmd.Parameters.Add("p_LUBRICACION", SqlDbType.Int, 1).Value = _Equipo.Lubricacion
                Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.VarChar, 10).Value = Usuario
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                GuardarEquipo = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                LiberarRecursos()
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return GuardarEquipo
    End Function

    Public Function ObtenerMantenimiento(ByVal DatoBuscar As Integer) As Mantenimiento Implements IAccesoDatos.ObtenerMantenimiento
        Dim _Mantenimiento = New Mantenimiento
        Try
            BuscarRegistro("TBL_MANTENIMIENTO", DatoBuscar)
            If (sdr.Read()) Then
                _Mantenimiento.Mantenimiento_id = Convert.ToInt32(sdr("MANTENIMIENTO_ID").ToString())
                _Mantenimiento.Equipo_id = Convert.ToInt32(sdr("EQUIPO_ID").ToString())
                _Mantenimiento.Operario_id = Convert.ToInt32(sdr("OPERARIO_ID").ToString())
                _Mantenimiento.Fecha = Convert.ToDateTime(sdr("FECHA").ToString())
                _Mantenimiento.Observaciones = sdr("OBSERVACIONES").ToString()
            Else
                _Mantenimiento = Nothing
            End If
            sdr.Close()
            LiberarRecursos()
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return _Mantenimiento
    End Function

    Public Function GuardarMantenimiento(ByVal _Mantenimiento As Mantenimiento, ByVal Usuario As Integer) As Integer Implements IAccesoDatos.GuardarMantenimiento
        GuardarMantenimiento = -1
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_IU_Mantenimiento", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_MANTENIMIENTO_ID", SqlDbType.Int, 4).Value = _Mantenimiento.Mantenimiento_id
                Cmd.Parameters.Add("p_EQUIPO_ID", SqlDbType.Int, 10).Value = _Mantenimiento.Equipo_id
                Cmd.Parameters.Add("p_OPERARIO_ID", SqlDbType.Int, 10).Value = _Mantenimiento.Operario_id
                Cmd.Parameters.Add("p_FECHA", SqlDbType.DateTime, 10).Value = _Mantenimiento.Fecha
                Cmd.Parameters.Add("p_OBSERVACIONES", SqlDbType.VarChar, 255).Value = _Mantenimiento.Observaciones
                Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.VarChar, 10).Value = Usuario
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                GuardarMantenimiento = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                LiberarRecursos()
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return GuardarMantenimiento
    End Function

    Public Function EliminarRegistro(ByVal DatoEliminar As Integer, ByVal Tabla As String) As Integer Implements IAccesoDatos.EliminarRegistro
        EliminarRegistro = -1
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_D_Registro", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = Tabla
                Cmd.Parameters.Add("p_CONDICION", SqlDbType.Int, 4).Value = DatoEliminar
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                EliminarRegistro = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                LiberarRecursos()
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return EliminarRegistro
    End Function

    Private Shared Sub LiberarRecursos()

        If Not (sdr.IsClosed) Then
            sdr.Close()
            Cmd.Dispose()
            If (Not Cn Is Nothing) Then
                Cn.Close()
                Cn.Dispose()
            End If
        End If

    End Sub

End Class

