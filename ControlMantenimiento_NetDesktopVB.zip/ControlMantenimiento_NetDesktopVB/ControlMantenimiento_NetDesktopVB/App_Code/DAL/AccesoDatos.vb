﻿' DAL: Data Access Layer - Capa Acceso Datos

Option Strict On

Imports System.Data.SqlClient
Imports ControlMantenimiento_NetDesktopVB

Public Class AccesoDatos : Implements IAccesoDatos

    Public Sub New()

    End Sub

    Private Shared Cn As SqlConnection
    Private Shared sdr As SqlDataReader
    Private Shared Cmd As SqlCommand

    Private Shared Sub BuscarRegistro(ByVal Tabla As String, ByVal DatoBuscar As String, ByVal Condicion As String)
        Try
            Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
            Cmd = New SqlCommand("spr_CBuscarRegistro", Cn)
            Cmd.CommandType = CommandType.StoredProcedure
            Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = Tabla
            Cmd.Parameters.Add("p_DATOBUSCAR", SqlDbType.VarChar, 20).Value = DatoBuscar
            Cmd.Parameters.Add("p_CONDICION", SqlDbType.VarChar, 50).Value = Condicion
            Cn.Open()
            sdr = Cmd.ExecuteReader()
        Catch
            LiberarRecursos()
        End Try
    End Sub

    Public Function ValidarTablaVacia(ByVal Tabla As String) As Integer Implements IAccesoDatos.ValidarTablaVacia
        ValidarTablaVacia = -1
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("spr_CValidarExistenciaDatos", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = Tabla
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteScalar()
                ValidarTablaVacia = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                LiberarRecursos()
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return ValidarTablaVacia
    End Function

    Public Function CargarListas(ByVal Tabla As String) As ArrayList Implements IAccesoDatos.CargarListas
        Dim arlLista As New ArrayList()
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("spr_CCargarCombosListas", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 30).Value = Tabla
                Cn.Open()
                Using sdr = Cmd.ExecuteReader(CommandBehavior.CloseConnection)
                    While (sdr.Read())
                        arlLista.Add(New CargaCombosListas(sdr.GetValue(0).ToString(), (sdr.GetValue(0).ToString()) & " " & sdr.GetValue(1).ToString()))
                    End While
                    sdr.Close()
                    LiberarRecursos()
                End Using
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return arlLista
    End Function

    Public Function ControlProgramacion(ByVal Tabla As String) As ArrayList Implements IAccesoDatos.ControlProgramacion
        Dim arlListControlProgramacion As New ArrayList
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("spr_CCargarCombosListas", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 30).Value = Tabla
                Cn.Open()
                Using sdr = Cmd.ExecuteReader(CommandBehavior.CloseConnection)
                    While (sdr.Read())
                        arlListControlProgramacion.Add(sdr.GetValue(2).ToString())
                        arlListControlProgramacion.Add(sdr.GetValue(0).ToString())
                        arlListControlProgramacion.Add(sdr.GetValue(1).ToString())
                    End While
                    sdr.Close()
                    LiberarRecursos()
                End Using
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return arlListControlProgramacion
    End Function

    Public Function ObtenerAcceso(ByVal DatoBuscar As String, ByVal Clave As String) As Operario Implements IAccesoDatos.ObtenerAcceso
        Dim _Operario As New Operario
        Try
            BuscarRegistro("OPERARIOS", DatoBuscar, Clave)
            If (sdr.Read()) Then
                _Operario.Documento = sdr("DOCUMENTO").ToString()
                _Operario.Nombres = sdr("NOMBRES").ToString()
                _Operario.Apellidos = sdr("APELLIDOS").ToString()
                _Operario.Perfil = Convert.ToInt32(sdr("PERFIL").ToString())
            Else
                _Operario = Nothing
            End If
            LiberarRecursos()
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return _Operario
    End Function

    Public Function ObtenerOperario(ByVal DatoBuscar As String) As Operario Implements IAccesoDatos.ObtenerOperario
        Dim _Operario As New Operario
        Try
            BuscarRegistro("OPERARIOS", DatoBuscar, "")
            If (sdr.Read()) Then
                _Operario.Documento = sdr("DOCUMENTO").ToString()
                _Operario.Nombres = sdr("NOMBRES").ToString()
                _Operario.Apellidos = sdr("APELLIDOS").ToString()
                _Operario.Correo = sdr("CORREO").ToString()
                _Operario.Telefono = sdr("TELEFONO").ToString()
                _Operario.Foto = sdr("FOTO").ToString()
            Else
                _Operario = Nothing
            End If
            sdr.Close()
            LiberarRecursos()
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return _Operario
    End Function

    Public Function GuardarCambioClave(ByVal Documento As String, ByVal ClaveAnterior As String, ByVal ClaveNueva As String) As Integer Implements IAccesoDatos.GuardarCambioClave
        GuardarCambioClave = -1
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("spr_UCambioClave", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_DOCUMENTO", SqlDbType.VarChar, 10).Value = Documento
                Cmd.Parameters.Add("p_CLAVE_ANTERIOR", SqlDbType.VarChar, 20).Value = ClaveAnterior
                Cmd.Parameters.Add("p_CLAVE_NUEVA", SqlDbType.VarChar, 20).Value = ClaveNueva
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                GuardarCambioClave = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                LiberarRecursos()
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return GuardarCambioClave
    End Function

    Public Function GuardarOperarios(ByVal _Operario As Operario, ByVal Accion As String, ByVal Usuario As String) As Integer Implements IAccesoDatos.GuardarOperario
        GuardarOperarios = -1
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("spr_IUOperarios", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_ACCION", SqlDbType.VarChar, 1).Value = Accion
                Cmd.Parameters.Add("p_DOCUMENTO", SqlDbType.Int, 10).Value = _Operario.Documento
                Cmd.Parameters.Add("p_NOMBRES", SqlDbType.VarChar, 25).Value = _Operario.Nombres
                Cmd.Parameters.Add("p_APELLIDOS", SqlDbType.VarChar, 25).Value = _Operario.Apellidos
                Cmd.Parameters.Add("p_CORREO", SqlDbType.VarChar, 50).Value = _Operario.Correo
                Cmd.Parameters.Add("p_TELEFONO", SqlDbType.Int, 10).Value = _Operario.Telefono
                Cmd.Parameters.Add("p_FOTO", SqlDbType.VarChar, 50).Value = _Operario.Foto
                Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.VarChar, 10).Value = Usuario
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                GuardarOperarios = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                LiberarRecursos()
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return GuardarOperarios
    End Function

    Public Function ObtenerListaValores(ByVal DatoBuscar As String) As ListaValores Implements IAccesoDatos.ObtenerListaValores
        Dim _ListaValores As New ListaValores
        Try
            BuscarRegistro("LISTAVALORES", DatoBuscar, "CODIGO")
            If (sdr.Read()) Then
                _ListaValores.Codigo = Convert.ToInt32(sdr("CODIGO").ToString())
                _ListaValores.Nombre = sdr("NOMBRE").ToString()
                _ListaValores.Descripcion = sdr("DESCRIPCION").ToString()
            Else
                _ListaValores = Nothing
            End If
            sdr.Close()
            LiberarRecursos()
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return _ListaValores
    End Function

    Public Function GuardarListaValores(ByVal _listavalores As ListaValores, ByVal Usuario As String) As Integer Implements IAccesoDatos.GuardarListaValores
        GuardarListaValores = -1
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("spr_IUListaValores", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_CODIGO", SqlDbType.Int, 10).Value = _listavalores.Codigo
                Cmd.Parameters.Add("p_NOMBRE", SqlDbType.VarChar, 50).Value = _listavalores.Nombre
                Cmd.Parameters.Add("p_DESCRIPCION", SqlDbType.VarChar, 255).Value = _listavalores.Descripcion
                Cmd.Parameters.Add("p_TIPO", SqlDbType.VarChar, 50).Value = _listavalores.Tipo
                Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.VarChar, 10).Value = Usuario
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                GuardarListaValores = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                LiberarRecursos()
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return GuardarListaValores
    End Function

    Public Function ObtenerEquipo(ByVal DatoBuscar As String) As Equipo Implements IAccesoDatos.ObtenerEquipo
        Dim _Equipo As New Equipo
        Try
            BuscarRegistro("EQUIPOS", DatoBuscar, "")
            If (sdr.Read()) Then
                _Equipo.CodigoEquipo = Convert.ToInt32(sdr("CODIGOEQUIPO").ToString())
                _Equipo.NombreEquipo = sdr("NOMBREEQUIPO").ToString()
                _Equipo.CodigoMarca = Convert.ToInt32(sdr("CODIGOMARCA").ToString())
                _Equipo.Serie = sdr("SERIE").ToString()
                _Equipo.CodigoLinea = Convert.ToInt32(sdr("CODIGOLINEA").ToString())
                If (sdr.GetBoolean(sdr.GetOrdinal("LUBRICACION"))) Then
                    _Equipo.Lubricacion = 1
                End If
            Else
                _Equipo = Nothing
            End If
            sdr.Close()
            LiberarRecursos()
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return _Equipo
    End Function

    Public Function GuardarEquipo(ByVal _Equipo As Equipo, ByVal Usuario As String) As Integer Implements IAccesoDatos.GuardarEquipo
        GuardarEquipo = -1
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("spr_IUEquipos", Cn)
                Cmd.CommandType = CommandType.StoredProcedure

                Cmd.Parameters.Add("p_CODIGOEQUIPO", SqlDbType.Int, 10).Value = _Equipo.CodigoEquipo
                Cmd.Parameters.Add("p_NOMBREEQUIPO", SqlDbType.VarChar, 50).Value = _Equipo.NombreEquipo
                Cmd.Parameters.Add("p_CODIGOMARCA", SqlDbType.Int, 10).Value = _Equipo.CodigoMarca
                Cmd.Parameters.Add("p_SERIE", SqlDbType.VarChar, 20).Value = _Equipo.Serie
                Cmd.Parameters.Add("p_CODIGOLINEA", SqlDbType.Int, 10).Value = _Equipo.CodigoLinea
                Cmd.Parameters.Add("p_LUBRICACION", SqlDbType.Int, 1).Value = _Equipo.Lubricacion
                Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.VarChar, 10).Value = Usuario
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                GuardarEquipo = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                LiberarRecursos()
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return GuardarEquipo
    End Function

    Public Function ObtenerMantenimiento(ByVal DatoBuscar As String) As Mantenimiento Implements IAccesoDatos.ObtenerMantenimiento
        Dim _Mantenimiento = New Mantenimiento
        Try
            BuscarRegistro("MANTENIMIENTO", DatoBuscar, "")
            If (sdr.Read()) Then
                _Mantenimiento.CodigoEquipo = Convert.ToInt32(sdr("CODIGOEQUIPO").ToString())
                _Mantenimiento.Documento = Convert.ToDouble(sdr("DOCUMENTO").ToString())
                _Mantenimiento.Fecha = Convert.ToDateTime(sdr("FECHA").ToString())
                _Mantenimiento.Observaciones = sdr("OBSERVACIONES").ToString()
            Else
                _Mantenimiento = Nothing
            End If
            sdr.Close()
            LiberarRecursos()
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return _Mantenimiento
    End Function

    Public Function GuardarMantenimiento(ByVal _Mantenimiento As Mantenimiento, ByVal Accion As String, ByVal Usuario As String) As Integer Implements IAccesoDatos.GuardarMantenimiento
        GuardarMantenimiento = -1
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("spr_IUMantenimiento", Cn)
                Cmd.CommandType = CommandType.StoredProcedure

                Cmd.Parameters.Add("p_ACCION", SqlDbType.VarChar, 1).Value = Accion
                Cmd.Parameters.Add("p_CODIGOEQUIPO", SqlDbType.Int, 10).Value = _Mantenimiento.CodigoEquipo
                Cmd.Parameters.Add("p_DOCUMENTO", SqlDbType.Int, 10).Value = _Mantenimiento.Documento
                Cmd.Parameters.Add("p_FECHA", SqlDbType.DateTime, 10).Value = _Mantenimiento.Fecha
                Cmd.Parameters.Add("p_OBSERVACIONES", SqlDbType.VarChar, 255).Value = _Mantenimiento.Observaciones
                Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.VarChar, 10).Value = Usuario
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                GuardarMantenimiento = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                LiberarRecursos()
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return GuardarMantenimiento
    End Function

    Public Function EliminarRegistro(ByVal DatoEliminar As String, ByVal Tabla As String) As Integer Implements IAccesoDatos.EliminarRegistro
        EliminarRegistro = -1
        Try
            Using Cn = New SqlConnection(Conexion.ObtenerConexion().ToString)
                Cmd = New SqlCommand("spr_DRegistro", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = Tabla
                Cmd.Parameters.Add("p_CONDICION", SqlDbType.Int, 10).Value = DatoEliminar
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                EliminarRegistro = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                LiberarRecursos()
            End Using
        Catch
            LiberarRecursos()
        Finally
            LiberarRecursos()
        End Try
        Return EliminarRegistro
    End Function

    Private Shared Sub LiberarRecursos()

        If Not (sdr.IsClosed) Then
            sdr.Close()
            Cmd.Dispose()
            If (Not Cn Is Nothing) Then
                Cn.Close()
                Cn.Dispose()
            End If
        End If

    End Sub

End Class

