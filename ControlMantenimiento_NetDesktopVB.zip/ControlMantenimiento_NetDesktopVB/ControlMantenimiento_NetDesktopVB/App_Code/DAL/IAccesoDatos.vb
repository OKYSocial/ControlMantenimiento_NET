﻿' Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   

Option Strict On

Public Interface IAccesoDatos

    Function ObtenerAcceso(ByVal DatoBuscar As String, ByVal Clave As String) As Operario
    Function ObtenerOperario(ByVal DatoBuscar As String) As Operario
    Function ObtenerEquipo(ByVal DatoBuscar As String) As Equipo
    Function ObtenerListaValores(ByVal DatoBuscar As String) As ListaValores
    Function ObtenerMantenimiento(ByVal DatoBuscar As String) As Mantenimiento

    Function GuardarOperario(_Operario As Operario, ByVal Accion As String, ByVal Usuario As String) As Integer
    Function GuardarCambioClave(ByVal Documento As String, ByVal ClaveAnterior As String, ByVal ClaveNueva As String) As Integer
    Function GuardarListaValores(_ListaValores As ListaValores, ByVal Usuario As String) As Integer
    Function GuardarEquipo(_Equipo As Equipo, ByVal Usuario As String) As Integer
    Function GuardarMantenimiento(_Mantenimiento As Mantenimiento, ByVal Accion As String, ByVal Usuario As String) As Integer

    Function CargarListas(ByVal Tabla As String) As ArrayList
    Function ControlProgramacion(ByVal Tabla As String) As ArrayList
    Function ValidarTablaVacia(ByVal Tabla As String) As Integer
    Function EliminarRegistro(ByVal DatoEliminar As String, ByVal Tabla As String) As Integer





End Interface
