﻿' Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   

Option Strict On

Public Interface IAccesoDatos

    Function ObtenerAcceso(ByVal DatoBuscar As String, ByVal Clave As String) As Operario
    Function ObtenerOperario(ByVal DatoBuscar As Integer) As Operario
    Function ObtenerEquipo(ByVal DatoBuscar As Integer) As Equipo
    Function ObtenerListaValores(ByVal DatoBuscar As Integer) As ListaValores
    Function ObtenerMantenimiento(ByVal DatoBuscar As Integer) As Mantenimiento

    Function GuardarOperario(_Operario As Operario, ByVal Usuario As Integer) As Integer
    Function GuardarCambioClave(ByVal Usuario As Integer, ByVal ClaveAnterior As String, ByVal ClaveNueva As String) As Integer
    Function GuardarListaValores(_ListaValores As ListaValores, ByVal Usuario As Integer) As Integer
    Function GuardarEquipo(_Equipo As Equipo, ByVal Usuario As Integer) As Integer
    Function GuardarMantenimiento(_Mantenimiento As Mantenimiento, ByVal Usuario As Integer) As Integer

    Function CargarListas(ByVal Tabla As String) As ArrayList
    Function ControlProgramacion(ByVal Tabla As String) As ArrayList
    Function EliminarRegistro(ByVal DatoEliminar As Integer, ByVal Tabla As String) As Integer





End Interface
