﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMenu))
        Me.pictureBox1 = New System.Windows.Forms.PictureBox()
        Me.toolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.salirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.tostMenu = New System.Windows.Forms.ToolStrip()
        Me.toolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.marcasToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.lineasToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.equiposToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.administracionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cambioClaveToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.menuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.programarMantenimientoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModificarProgramacionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblUsuarioConectado = New System.Windows.Forms.Label()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tostMenu.SuspendLayout()
        Me.menuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'pictureBox1
        '
        Me.pictureBox1.Image = CType(resources.GetObject("pictureBox1.Image"), System.Drawing.Image)
        Me.pictureBox1.Location = New System.Drawing.Point(0, 103)
        Me.pictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(772, 324)
        Me.pictureBox1.TabIndex = 6
        Me.pictureBox1.TabStop = False
        '
        'toolStripButton1
        '
        Me.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.toolStripButton1.Image = CType(resources.GetObject("toolStripButton1.Image"), System.Drawing.Image)
        Me.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.toolStripButton1.Name = "toolStripButton1"
        Me.toolStripButton1.Size = New System.Drawing.Size(54, 54)
        Me.toolStripButton1.Text = "Operarios"
        '
        'salirToolStripMenuItem
        '
        Me.salirToolStripMenuItem.Name = "salirToolStripMenuItem"
        Me.salirToolStripMenuItem.Size = New System.Drawing.Size(50, 24)
        Me.salirToolStripMenuItem.Text = "Salir"
        '
        'toolStripButton2
        '
        Me.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.toolStripButton2.Enabled = False
        Me.toolStripButton2.Image = CType(resources.GetObject("toolStripButton2.Image"), System.Drawing.Image)
        Me.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.toolStripButton2.Name = "toolStripButton2"
        Me.toolStripButton2.Size = New System.Drawing.Size(54, 54)
        Me.toolStripButton2.Text = "Equipos"
        '
        'tostMenu
        '
        Me.tostMenu.ImageScalingSize = New System.Drawing.Size(50, 50)
        Me.tostMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.toolStripButton1, Me.toolStripButton2, Me.toolStripButton3, Me.toolStripButton4, Me.toolStripButton5, Me.toolStripButton6})
        Me.tostMenu.Location = New System.Drawing.Point(0, 28)
        Me.tostMenu.Name = "tostMenu"
        Me.tostMenu.Size = New System.Drawing.Size(772, 57)
        Me.tostMenu.TabIndex = 5
        '
        'toolStripButton3
        '
        Me.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.toolStripButton3.Enabled = False
        Me.toolStripButton3.Image = CType(resources.GetObject("toolStripButton3.Image"), System.Drawing.Image)
        Me.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.toolStripButton3.Name = "toolStripButton3"
        Me.toolStripButton3.Size = New System.Drawing.Size(54, 54)
        Me.toolStripButton3.Text = "Programacion Mto"
        '
        'toolStripButton4
        '
        Me.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.toolStripButton4.Enabled = False
        Me.toolStripButton4.Image = CType(resources.GetObject("toolStripButton4.Image"), System.Drawing.Image)
        Me.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.toolStripButton4.Name = "toolStripButton4"
        Me.toolStripButton4.Size = New System.Drawing.Size(54, 54)
        Me.toolStripButton4.Text = "Modificar Mto"
        '
        'toolStripButton5
        '
        Me.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.toolStripButton5.Enabled = False
        Me.toolStripButton5.Image = CType(resources.GetObject("toolStripButton5.Image"), System.Drawing.Image)
        Me.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.toolStripButton5.Name = "toolStripButton5"
        Me.toolStripButton5.Size = New System.Drawing.Size(54, 54)
        Me.toolStripButton5.Text = "Lineas"
        '
        'toolStripButton6
        '
        Me.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.toolStripButton6.Enabled = False
        Me.toolStripButton6.Image = CType(resources.GetObject("toolStripButton6.Image"), System.Drawing.Image)
        Me.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.toolStripButton6.Name = "toolStripButton6"
        Me.toolStripButton6.Size = New System.Drawing.Size(54, 54)
        Me.toolStripButton6.Text = "Marcas"
        '
        'marcasToolStripMenuItem2
        '
        Me.marcasToolStripMenuItem2.Name = "marcasToolStripMenuItem2"
        Me.marcasToolStripMenuItem2.Size = New System.Drawing.Size(185, 26)
        Me.marcasToolStripMenuItem2.Text = "Marcas"
        '
        'lineasToolStripMenuItem1
        '
        Me.lineasToolStripMenuItem1.Name = "lineasToolStripMenuItem1"
        Me.lineasToolStripMenuItem1.Size = New System.Drawing.Size(185, 26)
        Me.lineasToolStripMenuItem1.Text = "Lineas"
        '
        'equiposToolStripMenuItem
        '
        Me.equiposToolStripMenuItem.Name = "equiposToolStripMenuItem"
        Me.equiposToolStripMenuItem.Size = New System.Drawing.Size(185, 26)
        Me.equiposToolStripMenuItem.Text = "Equipos"
        '
        'administracionToolStripMenuItem
        '
        Me.administracionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.cambioClaveToolStripMenuItem1})
        Me.administracionToolStripMenuItem.Name = "administracionToolStripMenuItem"
        Me.administracionToolStripMenuItem.Size = New System.Drawing.Size(58, 24)
        Me.administracionToolStripMenuItem.Text = "Menu"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(176, 26)
        Me.ToolStripMenuItem1.Text = "Operarios"
        '
        'cambioClaveToolStripMenuItem1
        '
        Me.cambioClaveToolStripMenuItem1.Name = "cambioClaveToolStripMenuItem1"
        Me.cambioClaveToolStripMenuItem1.Size = New System.Drawing.Size(176, 26)
        Me.cambioClaveToolStripMenuItem1.Text = "Cambio Clave"
        '
        'menuStrip1
        '
        Me.menuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.menuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.administracionToolStripMenuItem, Me.menuToolStripMenuItem, Me.salirToolStripMenuItem})
        Me.menuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.menuStrip1.Name = "menuStrip1"
        Me.menuStrip1.Padding = New System.Windows.Forms.Padding(8, 2, 0, 2)
        Me.menuStrip1.Size = New System.Drawing.Size(772, 28)
        Me.menuStrip1.TabIndex = 4
        Me.menuStrip1.Text = "menuStrip1"
        '
        'menuToolStripMenuItem
        '
        Me.menuToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.equiposToolStripMenuItem, Me.lineasToolStripMenuItem1, Me.marcasToolStripMenuItem2})
        Me.menuToolStripMenuItem.Enabled = False
        Me.menuToolStripMenuItem.Name = "menuToolStripMenuItem"
        Me.menuToolStripMenuItem.Size = New System.Drawing.Size(121, 24)
        Me.menuToolStripMenuItem.Text = "Administracion"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.programarMantenimientoToolStripMenuItem, Me.ModificarProgramacionToolStripMenuItem})
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(185, 26)
        Me.ToolStripMenuItem2.Text = "Mantenimiento"
        '
        'programarMantenimientoToolStripMenuItem
        '
        Me.programarMantenimientoToolStripMenuItem.Name = "programarMantenimientoToolStripMenuItem"
        Me.programarMantenimientoToolStripMenuItem.Size = New System.Drawing.Size(259, 26)
        Me.programarMantenimientoToolStripMenuItem.Text = "Programar Mantenimiento"
        '
        'ModificarProgramacionToolStripMenuItem
        '
        Me.ModificarProgramacionToolStripMenuItem.Name = "ModificarProgramacionToolStripMenuItem"
        Me.ModificarProgramacionToolStripMenuItem.Size = New System.Drawing.Size(259, 26)
        Me.ModificarProgramacionToolStripMenuItem.Text = "Modificar Programacion"
        '
        'lblUsuarioConectado
        '
        Me.lblUsuarioConectado.AutoSize = True
        Me.lblUsuarioConectado.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblUsuarioConectado.ForeColor = System.Drawing.Color.White
        Me.lblUsuarioConectado.Location = New System.Drawing.Point(13, 113)
        Me.lblUsuarioConectado.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblUsuarioConectado.Name = "lblUsuarioConectado"
        Me.lblUsuarioConectado.Size = New System.Drawing.Size(86, 17)
        Me.lblUsuarioConectado.TabIndex = 7
        Me.lblUsuarioConectado.Text = "Bienvenido: "
        '
        'FormMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(772, 424)
        Me.Controls.Add(Me.lblUsuarioConectado)
        Me.Controls.Add(Me.pictureBox1)
        Me.Controls.Add(Me.tostMenu)
        Me.Controls.Add(Me.menuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "FormMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = " SIMI - SISTEMA DE MANTENIMIENTO INDUSTRIAL"
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tostMenu.ResumeLayout(False)
        Me.tostMenu.PerformLayout()
        Me.menuStrip1.ResumeLayout(False)
        Me.menuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents pictureBox1 As System.Windows.Forms.PictureBox
    Private WithEvents toolStripButton1 As System.Windows.Forms.ToolStripButton
    Private WithEvents salirToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents toolStripButton2 As System.Windows.Forms.ToolStripButton
    Private WithEvents tostMenu As System.Windows.Forms.ToolStrip
    Private WithEvents toolStripButton3 As System.Windows.Forms.ToolStripButton
    Private WithEvents toolStripButton4 As System.Windows.Forms.ToolStripButton
    Private WithEvents toolStripButton5 As System.Windows.Forms.ToolStripButton
    Private WithEvents toolStripButton6 As System.Windows.Forms.ToolStripButton
    Private WithEvents marcasToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents lineasToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents equiposToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents administracionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents cambioClaveToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents menuStrip1 As System.Windows.Forms.MenuStrip
    Private WithEvents menuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents lblUsuarioConectado As System.Windows.Forms.Label
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents programarMantenimientoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ModificarProgramacionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
