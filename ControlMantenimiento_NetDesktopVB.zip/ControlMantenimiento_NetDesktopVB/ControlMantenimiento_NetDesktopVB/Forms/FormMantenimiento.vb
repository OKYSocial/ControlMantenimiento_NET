﻿Option Strict On

Public Class FormMantenimiento
    Private _controlador As Controlador = Funciones.CrearControlador()
    Private Grabar As Boolean
    Private _Mantenimiento As Mantenimiento
    Private Tecla As New KeyPressEventArgs(ChrW(Keys.Enter))
    Private ElMantenimiento As Integer = 0

    Private Sub FormMantenimiento_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If (Funciones.Fuente = "PROGRAMACION") Then
            ButtonBuscar.Visible = True
            lbMensaje.Visible = True
            ButtonGrabar.Enabled = False
        End If
        CargarCombos()
    End Sub

    Private Sub CargarCombos()
        Dim arlListado As New ArrayList
        Dim arlListadoEquipos As New ArrayList
        Dim arlListadoOperarios As New ArrayList
        arlListado = _controlador.ControlProgramacion(Funciones.Fuente)

        Dim i As Integer
        For i = 0 To arlListado.Count - 1
            If CBool(Convert.ToString(arlListado(i).ToString().Trim().Equals("EQUIPOS"))) Then
                arlListadoEquipos.Add(New CargaCombosListas(arlListado(i + 1).ToString(), arlListado(i + 1).ToString() + " " + arlListado(i + 2).ToString()))
            ElseIf CBool(Convert.ToString(arlListado(i).ToString().Trim().Equals("OPERARIOS"))) Then
                arlListadoOperarios.Add(New CargaCombosListas(arlListado(i + 1).ToString(), arlListado(i + 1).ToString() + " " + arlListado(i + 2).ToString()))
            End If
        Next i
        DropDownListEquipos.ValueMember = "CODIGO"
        DropDownListEquipos.DisplayMember = "DETALLE"
        DropDownListEquipos.DataSource = arlListadoEquipos
        DropDownListOperarios.ValueMember = "CODIGO"
        DropDownListOperarios.DisplayMember = "DETALLE"
        DropDownListOperarios.DataSource = arlListadoOperarios
    End Sub

    Private Sub DropDownListEquipos_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DropDownListEquipos.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            DropDownListOperarios.Focus()
        End If
    End Sub

    Private Sub DropDownListOperarios_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DropDownListOperarios.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            DateTimePickerFecha.Focus()
        End If
    End Sub

    Private Sub DateTimePickerFecha_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DateTimePickerFecha.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            DateTimePickerFecha_ValueChanged(DateTimePickerFecha, e)
        End If
    End Sub

    Private Sub DateTimePickerFecha_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePickerFecha.ValueChanged
        If (DateTimePickerFecha.Value < DateTime.Now.Date) Then
            Grabar = False
            MessageBox.Show(Mensajes.Mensaje27, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            DateTimePickerFecha.Focus()
            errorPro.SetError(DateTimePickerFecha, Mensajes.Mensaje27)
        Else
            TextBoxObservaciones.Focus()
        End If
    End Sub

    Private Sub TextBoxObservaciones_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxObservaciones.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            Funciones.EliminarTabulador(TextBoxObservaciones.Text, "")
            ButtonGrabar.Focus()
        End If
    End Sub

    Private Sub ButtonBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonBuscar.Click
        LlenarCampos()
    End Sub

    Private Sub LlenarCampos()
        _Mantenimiento = CType(_controlador.ObtenerRegistro(Convert.ToInt32(DropDownListEquipos.SelectedValue.ToString()), "TBL_MANTENIMIENTO"), Mantenimiento)
        If (Not _Mantenimiento Is Nothing) Then
            ButtonEliminar.Enabled = True
            DropDownListEquipos.Enabled = False
            ElMantenimiento = _Mantenimiento.Mantenimiento_id
            DropDownListOperarios.SelectedValue = _Mantenimiento.Operario_id.ToString()
            ButtonEliminar.Enabled = True
            DateTimePickerFecha.Value = _Mantenimiento.Fecha
            TextBoxObservaciones.Text = _Mantenimiento.Observaciones.Trim
            ButtonGrabar.Enabled = True
            DropDownListOperarios.Focus()
        End If
    End Sub

    Private Sub ButtonGrabar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGrabar.Click
        Grabar = True
        DateTimePickerFecha_KeyPress(ButtonGrabar, Tecla)
        If (Grabar) Then
            If (Funciones.Fuente = "PROGRAMAR") Then
                Guardar(Mensajes.MensajeGraba)
            Else
                Guardar(Mensajes.MensajeActualiza)
            End If
        End If
    End Sub

    Private Sub Guardar(ByVal Mensaje As String)
        Dim Resultado As Integer
        _Mantenimiento = New Mantenimiento
        _Mantenimiento.Mantenimiento_id = ElMantenimiento
        _Mantenimiento.Equipo_id = Convert.ToInt32(DropDownListEquipos.SelectedValue.ToString())
        _Mantenimiento.Operario_id = Convert.ToInt32(DropDownListOperarios.SelectedValue.ToString())
        _Mantenimiento.Fecha = Convert.ToDateTime(DateTimePickerFecha.Value)
        _Mantenimiento.Observaciones = TextBoxObservaciones.Text
        Resultado = _controlador.GuardarMantenimiento(_Mantenimiento)
        If (Resultado = 0) Then
            MessageBox.Show(Mensaje, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
            CargarCombos()
        ElseIf (Resultado = 1) Then
            MessageBox.Show(Mensajes.Mensaje10, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            DropDownListOperarios.Focus()
            errorPro.SetError(DropDownListOperarios, Mensajes.Mensaje10)
        Else
            MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        Limpiar()
        If (DropDownListEquipos.Items.Count <= 0) Then
            ButtonSalir.PerformClick()
        End If
    End Sub

    Private Sub ButtonCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancelar.Click
        Limpiar()
    End Sub

    Private Sub Limpiar()
        ElMantenimiento = 0
        ButtonEliminar.Enabled = False
        DropDownListEquipos.Enabled = True
        Funciones.LimpiarForma(panel2)
        DateTimePickerFecha.Value = DateTime.Now.Date
        errorPro.Clear()
        If (Funciones.Fuente = "PROGRAMACION") Then
            ButtonGrabar.Enabled = False
        End If
        DropDownListEquipos.Focus()
    End Sub

    Private Sub ButtonEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonEliminar.Click
        If (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.OK) Then
            If (_controlador.EliminarRegistro(ElMantenimiento, "TBL_MANTENIMIENTO") = 0) Then
                MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Limpiar()
                CargarCombos()
                If (DropDownListEquipos.Items.Count <= 0) Then
                    ButtonSalir.PerformClick()
                End If
            Else
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub ButtonSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSalir.Click
        _controlador = Nothing
        _Mantenimiento = Nothing
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub ButtonAyuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonAyuda.Click
        ' Dim myProcess As Process = Process.Start("E:/Fuentes CM/ControlMantenimiento-NetDesktopVB/ControlMantenimiento-NetDesktopVB/Ayudas/Ayuda.chm")
        ' myProcess.WaitForExit()
        ' Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
        ' donde descomprimió el archivo descargado de la web
    End Sub
End Class