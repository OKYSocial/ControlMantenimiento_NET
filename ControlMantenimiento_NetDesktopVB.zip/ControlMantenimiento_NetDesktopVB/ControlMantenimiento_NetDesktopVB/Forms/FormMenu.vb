﻿Option Strict On

Public Class FormMenu

    Private Sub FormMenu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If (Funciones.PerfilAcceso = 1) Then 'Solo si tiene perfil de Administrador habilitar
            menuToolStripMenuItem.Enabled = True
            toolStripButton2.Enabled = True
            toolStripButton3.Enabled = True
            toolStripButton4.Enabled = True
            toolStripButton5.Enabled = True
            toolStripButton6.Enabled = True
        End If
        lblUsuarioConectado.Text = lblUsuarioConectado.Text & " " & Funciones.NombreUsuario
    End Sub

    Private Sub SeleccionarOpcion(ByVal Opcion As Integer)
        Dim Resultado As Integer
        Dim _controlador As Controlador = Funciones.CrearControlador()
        Select Case Opcion
            Case 0
                FormOperarios.ShowDialog()
            Case 1
                Resultado = _controlador.ValidarTablaVacia("CMARCAS")
                If (Resultado = -1) Then
                    MessageBox.Show(Mensajes.Mensaje11, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                ElseIf (Resultado = -2) Then
                    MessageBox.Show(Mensajes.Mensaje12, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    FormEquipos.ShowDialog()
                End If
            Case 2
                Resultado = _controlador.ValidarTablaVacia("CPROGRAMAREQUIPOS")
                If (Resultado = -1) Then
                    MessageBox.Show(Mensajes.Mensaje14, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                ElseIf (Resultado = -2) Then
                    MessageBox.Show(Mensajes.Mensaje13, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    Funciones.Fuente = "CPROGRAMAREQUIPOS"
                    FormMantenimiento.ShowDialog()
                End If
            Case 3
                Resultado = _controlador.ValidarTablaVacia("CPROGRAMACION")
                If (Resultado > 0) Then
                    Funciones.Fuente = "CPROGRAMACION"
                    FormMantenimiento.ShowDialog()
                Else
                    MessageBox.Show(Mensajes.Mensaje14, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Case 4
                Funciones.ValorTipo = "LINEAS"
                FormListaValores.ShowDialog()
            Case 5
                Funciones.ValorTipo = "MARCAS"
                FormListaValores.ShowDialog()
        End Select
    End Sub

    Private Sub toolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles toolStripButton1.Click
        SeleccionarOpcion(0)
    End Sub

    Private Sub toolStripButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles toolStripButton2.Click
        SeleccionarOpcion(1)
    End Sub

    Private Sub toolStripButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles toolStripButton3.Click
        SeleccionarOpcion(2)
    End Sub

    Private Sub toolStripButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles toolStripButton4.Click
        SeleccionarOpcion(3)
    End Sub

    Private Sub toolStripButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles toolStripButton5.Click
        SeleccionarOpcion(4)
    End Sub

    Private Sub toolStripButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles toolStripButton6.Click
        SeleccionarOpcion(5)
    End Sub

    Private Sub cambioClaveToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cambioClaveToolStripMenuItem1.Click
        FormCambioClave.ShowDialog()
    End Sub

    Private Sub operariosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        SeleccionarOpcion(0)
    End Sub

    Private Sub equiposToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles equiposToolStripMenuItem.Click
        SeleccionarOpcion(1)
    End Sub

    Private Sub lineasToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lineasToolStripMenuItem1.Click
        SeleccionarOpcion(4)
    End Sub

    Private Sub marcasToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles marcasToolStripMenuItem2.Click
        SeleccionarOpcion(5)
    End Sub

    Private Sub salirToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles salirToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub programarMantenimientoToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles programarMantenimientoToolStripMenuItem.Click
        SeleccionarOpcion(2)
    End Sub

    Private Sub ModificarProgramacionToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ModificarProgramacionToolStripMenuItem.Click
        SeleccionarOpcion(3)
    End Sub
End Class