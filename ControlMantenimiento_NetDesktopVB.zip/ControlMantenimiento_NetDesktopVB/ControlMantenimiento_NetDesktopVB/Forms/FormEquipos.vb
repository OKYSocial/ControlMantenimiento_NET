﻿Option Strict On

Public Class FormEquipos
    Private _controlador As Controlador = Funciones.CrearControlador()
    Private Grabar As Boolean
    Private _Equipo As Equipo
    Private Tecla As New KeyPressEventArgs(ChrW(Keys.Enter))

    Private Sub FormEquipos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim arlListado As New ArrayList
        Dim arlListadoMarcas As New ArrayList
        Dim arlListadoLineas As New ArrayList
        Dim arlListadoEquipos As New ArrayList

        Dim _controlador As Controlador = Funciones.CrearControlador()
        arlListado = _controlador.ControlProgramacion("CONTROLEQUIPOS")

        Dim i As Integer
        For i = 0 To arlListado.Count - 1
            If CBool(Convert.ToString(arlListado(i).ToString().Trim().Equals("EQUIPOS"))) Then
                arlListadoEquipos.Add(New CargaCombosListas(arlListado(i + 1).ToString(), arlListado(i + 1).ToString() + " " + arlListado(i + 2).ToString()))
            ElseIf CBool(Convert.ToString(arlListado(i).ToString().Trim().Equals("MARCAS"))) Then
                arlListadoMarcas.Add(New CargaCombosListas(arlListado(i + 1).ToString(), arlListado(i + 1).ToString() + " " + arlListado(i + 2).ToString()))
            ElseIf CBool(Convert.ToString(arlListado(i).ToString().Trim().Equals("LINEAS"))) Then
                arlListadoLineas.Add(New CargaCombosListas(arlListado(i + 1).ToString(), arlListado(i + 1).ToString() + " " + arlListado(i + 2).ToString()))
            End If
        Next i

        ListBoxEquipos.ValueMember = "CODIGO"
        ListBoxEquipos.DisplayMember = "DETALLE"
        ListBoxEquipos.DataSource = arlListadoEquipos

        DropDownListMarcas.ValueMember = "CODIGO"
        DropDownListMarcas.DisplayMember = "DETALLE"
        DropDownListMarcas.DataSource = arlListadoMarcas

        DropDownListLineas.ValueMember = "CODIGO"
        DropDownListLineas.DisplayMember = "DETALLE"
        DropDownListLineas.DataSource = arlListadoLineas

    End Sub

    Private Sub CargarListaSeleccion()
        ListBoxEquipos.ValueMember = "CODIGO"
        ListBoxEquipos.DisplayMember = "DETALLE"
        ListBoxEquipos.DataSource = _controlador.CargarListas("EQUIPOS")
    End Sub

    Private Sub TextBoxNombreEquipo_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxNombreEquipo.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            If (Funciones.Validar_CampoVacio(TextBoxNombreEquipo.Text)) Then
                Grabar = False
                MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBoxNombreEquipo.Focus()
                errorPro.SetError(TextBoxNombreEquipo, Mensajes.MensajeCampoRequerido)
            Else
                TextBoxNombreEquipo.Text = Funciones.EliminarTabulador(TextBoxNombreEquipo.Text, "1MAY")
                errorPro.Clear()
                DropDownListMarcas.Focus()
            End If
        End If
    End Sub

    Private Sub DropDownListMarcas_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DropDownListMarcas.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            TextBoxSerie.Focus()
        End If
    End Sub

    Private Sub TextBoxSerie_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxSerie.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            If (Funciones.Validar_CampoVacio(TextBoxSerie.Text)) Then
                Grabar = False
                MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBoxSerie.Focus()
                errorPro.SetError(TextBoxSerie, Mensajes.MensajeCampoRequerido)
            Else
                DropDownListLineas.Focus()
            End If
        End If
    End Sub

    Private Sub DropDownListLineas_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DropDownListLineas.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            ButtonGrabar.Focus()
        End If
    End Sub

    Private Sub ButtonGrabar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGrabar.Click
        Grabar = True
        TextBoxNombreEquipo_KeyPress(ButtonGrabar, Tecla)
        If (Grabar) Then
            TextBoxSerie_KeyPress(ButtonGrabar, Tecla)
            If (Grabar) Then
                Guardar(Convert.ToInt32(lblCodigo.Text), CStr(IIf(Convert.ToInt32(lblCodigo.Text) = 0, Mensajes.MensajeGraba, Mensajes.MensajeActualiza)))
            End If
        End If
    End Sub

    Private Sub Guardar(ByVal ElCodigo As Integer, ByVal Mensaje As String)
        Dim Resultado As Integer
        _Equipo = New Equipo
        _Equipo.CodigoEquipo = ElCodigo
        _Equipo.NombreEquipo = TextBoxNombreEquipo.Text.Trim
        _Equipo.CodigoMarca = Convert.ToInt32(DropDownListMarcas.SelectedValue.ToString())
        _Equipo.Serie = TextBoxSerie.Text.Trim
        _Equipo.CodigoLinea = Convert.ToInt32(DropDownListLineas.SelectedValue.ToString())
        If (chkLubricacion.Checked) Then
            _Equipo.Lubricacion = 1
        Else
            _Equipo.Lubricacion = 0
        End If
        Resultado = _controlador.Guardar(_Equipo, "")
        If (Resultado = 0) Then
            MessageBox.Show(Mensaje, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
            CargarListaSeleccion()
        ElseIf (Resultado = 1) Then
            MessageBox.Show(Mensajes.Mensaje7, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            TextBoxSerie.Focus()
            errorPro.SetError(TextBoxSerie, Mensajes.Mensaje7)
        Else
            MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        Limpiar()
    End Sub

    Private Sub Limpiar()
        Funciones.LimpiarForma(panel2)
        ListBoxEquipos.Visible = False
        ButtonEliminar.Enabled = False
        errorPro.Clear()
        lblCodigo.Text = "0"
        chkLubricacion.Checked = False
        TextBoxNombreEquipo.Focus()
    End Sub

    Private Sub ButtonCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancelar.Click
        Limpiar()
    End Sub

    Private Sub ButtonEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonEliminar.Click
        If (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.OK) Then
            If (_controlador.EliminarRegistro(lblCodigo.Text, "EQUIPOS") = 0) Then
                MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                CargarListaSeleccion()
                Limpiar()
            Else
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub ButtonBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonBuscar.Click
        If (ListBoxEquipos.Items.Count <> 0) Then
            ListBoxEquipos.Visible = True
        End If
    End Sub

    Private Sub lstEquipos_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBoxEquipos.DoubleClick
        lblCodigo.Text = ListBoxEquipos.SelectedValue.ToString()
        ListBoxEquipos.Visible = False
        LlenarCampos()
    End Sub

    Private Sub LlenarCampos()
        _Equipo = CType(_controlador.ObtenerRegistro(lblCodigo.Text, "EQUIPOS"), Equipo)
        If (Not _Equipo Is Nothing) Then
            ButtonEliminar.Enabled = True
            TextBoxNombreEquipo.Text = _Equipo.NombreEquipo
            DropDownListMarcas.SelectedValue = _Equipo.CodigoMarca.ToString()
            TextBoxSerie.Text = _Equipo.Serie
            DropDownListLineas.SelectedValue = _Equipo.CodigoLinea.ToString()
            If (_Equipo.Lubricacion = 1) Then
                chkLubricacion.Checked = True
            Else
                chkLubricacion.Checked = False
            End If
            TextBoxNombreEquipo.Focus()
        End If
    End Sub

    Private Sub ButtonSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSalir.Click
        _controlador = Nothing
        _Equipo = Nothing
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub ButtonAyuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonAyuda.Click
        ' Dim myProcess As Process = Process.Start("E:/Fuentes CM/ControlMantenimiento-NetDesktopVB/ControlMantenimiento-NetDesktopVB/Ayudas/Ayuda.chm")
        ' myProcess.WaitForExit()
        ' Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
        ' donde descomprimió el archivo descargado de la web
    End Sub
End Class