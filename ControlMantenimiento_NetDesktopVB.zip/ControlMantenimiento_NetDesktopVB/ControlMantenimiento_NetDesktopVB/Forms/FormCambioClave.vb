﻿Option Strict On

Public Class FormCambioClave
    Private _controlador As Controlador = Funciones.CrearControlador()
    Private Grabar As Boolean
    Private Tecla As New KeyPressEventArgs(ChrW(Keys.Enter))

    Private Sub TextBoxClave_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxClave.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            If (Funciones.Validar_CampoVacio(TextBoxClave.Text)) Then
                Grabar = False
                MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBoxClave.Focus()
                errorPro.SetError(TextBoxClave, Mensajes.MensajeCampoRequerido)
            Else
                errorPro.Clear()
                TextBoxClaveNueva.Focus()
            End If
        End If
    End Sub

    Private Sub TextBoxClaveNueva_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxClaveNueva.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            If (Funciones.Validar_CampoVacio(TextBoxClaveNueva.Text)) Then
                Grabar = False
                MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBoxClaveNueva.Focus()
                errorPro.SetError(TextBoxClaveNueva, Mensajes.MensajeCampoRequerido)
            ElseIf (TextBoxClaveNueva.Text = TextBoxClave.Text) Then ' Clave Nueva debe ser diferente de la actual
                Grabar = False
                MessageBox.Show(Mensajes.Mensaje4, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBoxClaveNueva.Focus()
                errorPro.SetError(TextBoxClaveNueva, Mensajes.Mensaje21)
            ElseIf (TextBoxClaveNueva.Text.Length < 6) Then
                Grabar = False
                MessageBox.Show(Mensajes.Mensaje21, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBoxClaveNueva.Focus()
                errorPro.SetError(TextBoxClaveNueva, Mensajes.Mensaje21)
            Else
                errorPro.Clear()
                TextBoxConfirmar.Focus()
            End If
        End If

    End Sub

    Private Sub TextBoxConfirmar_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxConfirmar.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            If (Funciones.Validar_CampoVacio(TextBoxConfirmar.Text)) Then
                Grabar = False
                MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBoxConfirmar.Focus()
                errorPro.SetError(TextBoxConfirmar, Mensajes.MensajeCampoRequerido)
            ElseIf (TextBoxConfirmar.Text <> TextBoxClaveNueva.Text) Then ' Clave Nueva debe ser diferente de la actual
                Grabar = False
                MessageBox.Show(Mensajes.Mensaje5, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBoxConfirmar.Focus()
                errorPro.SetError(TextBoxConfirmar, Mensajes.Mensaje5)
            Else
                errorPro.Clear()
                ButtonGrabar.Focus()
            End If
        End If
    End Sub

    Private Sub ButtonGrabar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGrabar.Click
        Grabar = True
        TextBoxClave_KeyPress(ButtonGrabar, Tecla)
        If (Grabar) Then
            TextBoxClaveNueva_KeyPress(ButtonGrabar, Tecla)
            If (Grabar) Then
                TextBoxConfirmar_KeyPress(ButtonGrabar, Tecla)
                If (Grabar) Then
                    Guardar()
                End If
            End If
        End If
    End Sub

    Private Sub Guardar()
        Dim Resultado As Integer
        Resultado = _controlador.GuardarCambioClave(TextBoxClave.Text.Trim, TextBoxClaveNueva.Text.Trim)
        If (Resultado = 0) Then
            MessageBox.Show(Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf (Resultado = 1) Then
            MessageBox.Show(Mensajes.Mensaje3, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        ButtonSalir.PerformClick()
    End Sub

    Private Sub ButtonSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSalir.Click
        _controlador = Nothing
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub ButtonCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancelar.Click
        Limpiar()
    End Sub

    Private Sub Limpiar()
        Funciones.LimpiarForma(panel2)
        errorPro.Clear()
        TextBoxClave.Focus()
    End Sub
End Class