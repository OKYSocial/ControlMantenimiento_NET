﻿using System;
using ControlMantenimiento_NetWeb.BO;
using ControlMantenimiento_NetWeb.BLL;

public partial class Forms_WebFormListaValores : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["TIPO_USUARIO"] == null)
        {
            Response.Redirect("~/Forms/WebFormAcceso.aspx");
        }
        lblTitulo.Text = Funciones.Pagina;
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        if (Funciones.ParametroBuscar != null)
        {
            LlenarCampos();
        }
    }

    private void LlenarCampos()
    {
        Controlador controlador = Funciones.CrearControlador();
        ListaValores listavalores = (ListaValores)controlador.ObtenerRegistro(Funciones.ParametroBuscar, "LISTAVALORES");
        if (listavalores != null)
        {
            lblCodigo.Text = listavalores.Codigo.ToString();
            TextBoxNombre.Text = listavalores.Nombre;
            TextBoxDescripcion.Text = listavalores.Descripcion;
        }
        TextBoxNombre.Focus();
    }

    private bool Verificar()
    {
        if (Funciones.Validar_CampoVacio(TextBoxNombre.Text))
        {
            TextBoxMensajeError.Text = Mensajes.MensajeCampoRequerido;
            TextBoxNombre.Focus();
            return false;
        }
        return true;
    }

    protected void ButtonGrabar_Click(object sender, EventArgs e)
    {
        if (Verificar())
        {
            Guardar(Convert.ToInt32(lblCodigo.Text), (lblCodigo.Text == "0") ? Mensajes.MensajeGraba : Mensajes.MensajeActualiza);
        }
    }

    private void Guardar(int ElCodigo, string Mensaje)
    {
        int Resultado;
        ListaValores listavalores = new ListaValores();
        listavalores.Codigo = ElCodigo;
        listavalores.Nombre = TextBoxNombre.Text.Trim();
        listavalores.Descripcion = TextBoxDescripcion.Text;
        listavalores.Tipo = Funciones.Pagina;
        Controlador controlador = Funciones.CrearControlador();
        Resultado = controlador.Guardar(listavalores, "");
        if (Resultado == 0)
        {
            listavalores = null;
            Funciones.ParametroBuscar = null;
            Response.Redirect("~/Forms/WebFormRespuesta.aspx");
        }
        else if (Resultado == 1)
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje8;
            TextBoxNombre.Focus();
        }
        else
        {
            Response.Redirect("~/Forms/WebFormError.aspx");
        }
    }

    protected void ImageButtonAyuda_Click(object sender, System.Web.UI.ImageClickEventArgs e)
    {
        /* System.Diagnostics.Process proc = new System.Diagnostics.Process();
        proc.EnableRaisingEvents = false;
        proc.StartInfo.FileName = "E:/Fuentes CM/ControlMantenimiento-NetWeb/ControlMantenimiento-NetWeb/ControlMantenimiento-NetWeb/Ayudas/Ayuda.chm";
        proc.Start();
        proc.Dispose();*/

        // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
        // donde descomprimió el archivo descargado de la web
    }
}