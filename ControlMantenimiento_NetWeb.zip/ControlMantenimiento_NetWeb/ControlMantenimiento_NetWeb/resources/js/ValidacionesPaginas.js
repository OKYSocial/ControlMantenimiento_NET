function VerificarAcceso() {  
  document.getElementById("itDocumento").value = document.getElementById("itDocumento").value.replace(/^\s+|\s+$/g,"");
  if (document.getElementById("itDocumento").value == ""){
      document.getElementById("itMensajeError").value = "Documento es requerido";      
      document.getElementById("itDocumento").focus();
      return false;
  }
   if (document.getElementById("itDocumento").value.length < 6) 
   { 	
      document.getElementById("itMensajeError").value = 'Documento debe ser mayor de 6 digitos';	
      document.getElementById("itDocumento").focus();
      return false;
   }
  document.getElementById("isClave").value = document.getElementById("isClave").value.replace(/^\s+|\s+$/g,"");
  if (document.getElementById("isClave").value == ""){
      document.getElementById("itMensajeError").value = "Clave es requerido"	
      document.getElementById("frmAcceso:isClave").focus();
      return false;
  }
  if (document.getElementById("isClave").value.length < 6) 
  {
      document.getElementById("isClave").focus();
      return false;
  }  
  
    return true;
}


function VerificarOperarios()
{
  if (document.frmOperarios.FileFoto.value != "")  
  { 
    document.getElementById("frmOperarios:ihFoto").value = document.frmOperarios.FileFoto.value;
  }  
  document.getElementById("frmOperarios:itDocumento").value = document.getElementById("frmOperarios:itDocumento").value.replace(/^\s+|\s+$/g,"");
  if (document.getElementById("frmOperarios:itDocumento").value == ""){
      document.getElementById("frmOperarios:itMensajeError").value = "Documento es requerido";      
      document.getElementById("frmOperarios:itDocumento").focus();
      return false;
  } 
   if (document.getElementById("frmOperarios:itDocumento").value.length < 6) 
   { 	
      document.getElementById("frmOperarios:itMensajeError").value = 'Documento debe ser mayor de 6 digitos';	
      document.getElementById("frmOperarios:itDocumento").focus();
      return false;
   }
   if (document.getElementById("frmOperarios:itDocumento").value.substring(0,1)==0) 
   { 	
       document.getElementById("frmOperarios:itMensajeError").value = 'Error, primera cifra no puede ser 0';	
       document.getElementById("frmOperarios:itDocumento").focus();             
       return false;
   }
   document.getElementById("frmOperarios:itNombres").value = document.getElementById("frmOperarios:itNombres").value.replace(/^\s+|\s+$/g,"");
   if (document.getElementById("frmOperarios:itNombres").value == "")
   {    
        document.getElementById("frmOperarios:itMensajeError").value= 'Nombres es requerido';
        document.getElementById("frmOperarios:itNombres").focus();
	return false;
   }
   document.getElementById("frmOperarios:itApellidos").value = document.getElementById("frmOperarios:itApellidos").value.replace(/^\s+|\s+$/g,"");
   if (document.getElementById("frmOperarios:itApellidos").value == "")
   {    
        document.getElementById("frmOperarios:itMensajeError").value= 'Apellidos es requerido';	
        document.getElementById("frmOperarios:itApellidos").focus();
	return false;
   }
  document.getElementById("frmOperarios:itTelefono").value = document.getElementById("frmOperarios:itTelefono").value.replace(/^\s+|\s+$/g,"");
  if (document.getElementById("frmOperarios:itTelefono").value == "")
   {    
        document.getElementById("frmOperarios:itMensajeError").value= 'Telefono es requerido';	
        document.getElementById("frmOperarios:itTelefono").focus();
	return false;
   }
   if ((document.getElementById("frmOperarios:itTelefono").value.length != 7)  && (document.getElementById("frmOperarios:itTelefono").value.length != 10))
   { // Si es un teléfono celular debe ser de 10 dígitos	
       document.getElementById("frmOperarios:itMensajeError").value= 'Por favor debe ingresar entre 7 y 10 digitos para el telefono';
       document.getElementById("frmOperarios:itTelefono").focus();	 
       return false;
   }
   if (document.getElementById("frmOperarios:itTelefono").value.substring(0,1)==0) 
   { 	
       document.getElementById("frmOperarios:itMensajeError").value = 'Error, primera cifra no puede ser 0';	
       document.getElementById("frmOperarios:itTelefono").focus();             
       return false;
   }
   document.getElementById("frmOperarios:itCorreo").value = document.getElementById("frmOperarios:itCorreo").value.replace(/^\s+|\s+$/g,"");
   if (document.getElementById("frmOperarios:itCorreo").value.length > 0)
   {
    if( !(/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/.test(document.getElementById("frmOperarios:itCorreo").value)) )                        
     {
       document.getElementById("frmOperarios:itMensajeError").value= 'Formato de correo errado';
       document.getElementById("frmOperarios:itCorreo").focus();   
       return false;    
     }
   }
    document.getElementById("frmOperarios:isClave").value = document.getElementById("frmOperarios:isClave").value.replace(/^\s+|\s+$/g,"");  
   if (document.getElementById("frmOperarios:isClave").value == ""){
      document.getElementById("frmOperarios:itMensajeError").value = "Clave es requerido"	
      document.getElementById("frmOperarios:isClave").focus();
      return false;
   } 
   if ( document.getElementById("frmOperarios:isClave").value.length < 6)
   {    
        document.getElementById("frmOperarios:itMensajeError").value= 'Error, por favor ingrese una clave que contenga al menos 6 digitos';	
        document.getElementById("frmOperarios:isClave").focus();
	return false;
   }       

   return true;
}

function VerificarListaValores()
{ 
   document.getElementById("frmListaValores:itNombre").value = document.getElementById("frmListaValores:itNombre").value.replace(/^\s+|\s+$/g,"");
   if (document.getElementById("frmListaValores:itNombre").value == "")
   {    
       document.getElementById("frmListaValores:itMensajeError").value= 'Nombre es requerido';	
       document.getElementById("frmListaValores:itNombre").focus();
       return false;
   }
   return true;
}	

function VerificarEquipos()
{ 
   document.getElementById("frmEquipos:itNombre").value = document.getElementById("frmEquipos:itNombre").value.replace(/^\s+|\s+$/g,"");    
   if (document.getElementById("frmEquipos:itNombre").value == "")
   {    
       document.getElementById("frmEquipos:itMensajeError").value= 'Nombre es requerido';	
       document.getElementById("frmEquipos:itNombre").focus();
       return false;
   }
   document.getElementById("frmEquipos:itSerie").value = document.getElementById("frmEquipos:itSerie").value.replace(/^\s+|\s+$/g,"");    
   if (document.getElementById("frmEquipos:itSerie").value == "")
   {    
       document.getElementById("frmEquipos:itMensajeError").value= 'Serie es requerido';	
       document.getElementById("frmEquipos:itSerie").focus();
       return false;
   } 
   return true;
}

function VerificarCambioClave()
{ 
  document.getElementById("frmCambioClave:isClave").value = document.getElementById("frmCambioClave:isClave").value.replace(/^\s+|\s+$/g,"");  
  if (document.getElementById("frmCambioClave:isClave").value == ""){
      document.getElementById("frmCambioClave:itMensajeError").value = "Clave es requerido"	
      document.getElementById("frmCambioClave:isClave").focus();
      return false;
  }
  if (document.getElementById("frmCambioClave:isClave").value.length < 6) 
  {
      document.getElementById("frmCambioClave:itMensajeError").value = "Clave debe ser mayor de 6 digitos"
      document.getElementById("frmCambioClave:isClave").focus();
      return false;
  }
  document.getElementById("frmCambioClave:isClaveNueva").value = document.getElementById("frmCambioClave:isClaveNueva").value.replace(/^\s+|\s+$/g,"");  
   if (document.getElementById("frmCambioClave:isClaveNueva").value == ""){
      document.getElementById("frmCambioClave:itMensajeError").value = "Clave Nueva es requerido"	
      document.getElementById("frmCambioClave:isClaveNueva").focus();
      return false;
  }
  if (document.getElementById("frmCambioClave:isClaveNueva").value.length < 6) 
  {
      document.getElementById("frmCambioClave:itMensajeError").value = "Clave debe ser mayor de 6 digitos"
      document.getElementById("frmCambioClave:isClaveNueva").focus();
      return false;
  }
   if (document.getElementById("frmCambioClave:isClaveNueva").value == document.getElementById("frmCambioClave:isClave").value)
   {    
      document.getElementById("frmCambioClave:itMensajeError").value = "La clave debe ser diferente"
      document.getElementById("frmCambioClave:isClaveNueva").focus();
      return false;
   }
   document.getElementById("frmCambioClave:isConfirmar").value = document.getElementById("frmCambioClave:isConfirmar").value.replace(/^\s+|\s+$/g,"");  
   if (document.getElementById("frmCambioClave:isConfirmar").value == ""){
      document.getElementById("frmCambioClave:itMensajeError").value = "Debe confirmar la clave"	
      document.getElementById("frmCambioClave:isConfirmar").focus();
      return false;
  }
   
   if (document.getElementById("frmCambioClave:isConfirmar").value != document.getElementById("frmCambioClave:isClaveNueva").value)
   {    
      document.getElementById("frmCambioClave:itMensajeError").value = "La clave es diferente"
      document.getElementById("frmCambioClave:isConfirmar").focus();
      return false;
   }
   return true;
}	

function VerificarBusquedas()
{ 
   var indice = document.getElementById("frmBusquedas:soLista").selectedIndex;
   document.getElementById("frmBusquedas:itDatoBuscar").value = document.getElementById("frmBusquedas:itDatosBuscar").value.replace(/^\s+|\s+$/g,"");
   if ((document.getElementById("frmBusquedas:itDatoBuscar").value == "") && ( indice == -1))
   {    
      document.getElementById("frmBusquedas:itMensajeError").value = "Por favor seleccione o ingrese el dato a buscar"
      document.getElementById("frmBusquedas:itDatoBuscar").focus();
      return false;
   }   
   if (document.getElementById("frmBusquedas:itDatoBuscar").value.substring(0,1)==0) 
   { 	
       document.getElementById("frmBusquedas:itMensajeError").value = 'Error, primera cifra no puede ser 0';	
       document.getElementById("frmBusquedas:itDatoBuscar").focus();             
       return false;
   }
   return true;
}

function ConfirmarBorrado()
{
 if (confirm("¿ Esta seguro que desea eliminar este registro ?")) 
 {
   return true;
 }
 else
 {
  return false;
 }
}
