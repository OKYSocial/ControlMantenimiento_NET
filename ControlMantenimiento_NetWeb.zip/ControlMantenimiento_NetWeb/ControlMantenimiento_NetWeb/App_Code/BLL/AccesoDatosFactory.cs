﻿using ControlMantenimiento_NetWeb.DAL; // Patrón de Creación Factory Method

    public static class AccesoDatosFactory
    {
        public static IAccesoDatos ObtenerAccesoDatos()
        {
            return new AccesoDatos();
        }
    }
