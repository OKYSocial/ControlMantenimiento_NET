﻿// Este es el Controlador Manager general de todo el sistema. Todo tiene que pasar por esta clase
using ControlMantenimiento_NetWeb.BO;
using ControlMantenimiento_NetWeb.DAL;
using System;
using System.Collections;


namespace ControlMantenimiento_NetWeb.BLL
{
    public class Controlador
    {
        private readonly IAccesoDatos _accesoDatos;        

        public Controlador(IAccesoDatos accesoDatos)
        {
            _accesoDatos = accesoDatos;
        }

        // Ingresar al Sistema
        public Operario ObtenerAcceso(string DatoBuscar, string Clave)
        {
            Operario operario = null;
            operario = _accesoDatos.ObtenerAcceso(DatoBuscar, Clave);
            return operario;
        }

        public ArrayList CargarListas(string Tabla, string Condicion)
        {
            return _accesoDatos.CargarListas(Tabla, Condicion);
        }

        public ArrayList CargarListado(string Tabla, string Condicion)
        {
            return _accesoDatos.CargarListado(Tabla, Condicion);
        }

        public ArrayList ControlProgramacion(string Tabla)
        {
            return _accesoDatos.ControlProgramacion(Tabla);
        }               
          
        // Consultar Registro de BD
        public Object ObtenerRegistro(string DatoBuscar, string Tabla)
        {
            Object objeto = null;
            switch (Tabla)
            {
                case "OPERARIOS":
                    objeto = _accesoDatos.ObtenerOperario(DatoBuscar);
                    break;
                case "EQUIPOS":
                    objeto = _accesoDatos.ObtenerEquipo(DatoBuscar);
                    break;
                case "MANTENIMIENTO":
                    objeto = _accesoDatos.ObtenerMantenimiento(DatoBuscar);
                    break;
                case "LISTAVALORES":
                    objeto = _accesoDatos.ObtenerListaValores(DatoBuscar);
                    break;
            }
            return objeto;
        }

        // Grabar en BD
        public int GuardarOperario(Operario operario, string Accion)
        {
            return _accesoDatos.GuardarOperario(operario, Accion, Funciones.UsuarioConectado);
        }

        public int GuardarEquipo(Equipo equipo)
        {
            return _accesoDatos.GuardarEquipo(equipo, Funciones.UsuarioConectado);
        }

        public int GuardarListaValores(ListaValores listavalores)
        {
            return _accesoDatos.GuardarListaValores(listavalores, Funciones.UsuarioConectado);
        }

        public int GuardarMantenimiento(Mantenimiento mantenimiento, string Accion)
        {
            return _accesoDatos.GuardarMantenimiento(mantenimiento, Accion, Funciones.UsuarioConectado);
        }

        public int GuardarCambioClave(string ClaveAnterior, string ClaveNueva)
        {
            return _accesoDatos.GuardarCambioClave(Funciones.UsuarioConectado, ClaveAnterior, ClaveNueva);
        }

        // Borrar Registro
        public int EliminarRegistro(string DatoEliminar, string Tabla)
        {
            return _accesoDatos.EliminarRegistro(DatoEliminar, Tabla);
        }
        
    }
}
