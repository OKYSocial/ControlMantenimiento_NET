﻿// Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   

using System.Collections;
using ControlMantenimiento_NetWeb.BO;

namespace ControlMantenimiento_NetWeb.DAL
{
    public interface IAccesoDatos
    {
        Operario ObtenerAcceso(string datoBuscar, string clave);
        Operario ObtenerOperario(string datoBuscar);
        ListaValores ObtenerListaValores(string datoBuscar);
        Equipo ObtenerEquipo(string datoBuscar);
        Mantenimiento ObtenerMantenimiento(string datoBuscar);

        int GuardarOperario(Operario operario, string accion, string usuario);
        int GuardarCambioClave(string Documento, string ClaveAnterior, string ClaveNueva);
        int GuardarListaValores(ListaValores listavalores, string usuario);
        int GuardarEquipo(Equipo equipo, string usuario);
        int GuardarMantenimiento(Mantenimiento mantenimiento, string accion, string usuario);

        ArrayList CargarListas(string Tabla, string Condicion);
        ArrayList CargarListado(string Tabla, string Condicion);
        ArrayList ControlProgramacion(string Tabla);        
        int ValidarTablaVacia(string Tabla);
        int EliminarRegistro(string datoEliminar, string tabla);
    }
        
}
