﻿// Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   

using System.Collections;
using ControlMantenimiento_NetWeb.BO;

namespace ControlMantenimiento_NetWeb.DAL
{
    public interface IAccesoDatos
    {
        Operario ObtenerAcceso(string documento, string clave);
        Operario ObtenerOperario(int datoBuscar);
        ListaValores ObtenerListaValores(int datoBuscar);
        Equipo ObtenerEquipo(int datoBuscar);
        Mantenimiento ObtenerMantenimiento(int datoBuscar);

        int GuardarOperario(Operario operario, int usuario);
        int GuardarCambioClave(int Usuario, string ClaveAnterior, string ClaveNueva);
        int GuardarListaValores(ListaValores listavalores, int usuario);
        int GuardarEquipo(Equipo equipo, int usuario);
        int GuardarMantenimiento(Mantenimiento mantenimiento, int usuario);

        ArrayList CargarListado(string Tabla, string Condicion);
        ArrayList ControlProgramacion(string Tabla);
        int EliminarRegistro(int datoEliminar, string tabla);
    }
        
}
