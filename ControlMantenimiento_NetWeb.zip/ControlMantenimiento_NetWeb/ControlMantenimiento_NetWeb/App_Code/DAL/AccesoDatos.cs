﻿// DAL: Data Access Layer - Capa Acceso Datos
using System;
using System.Data.SqlClient;
using System.Collections;
using System.Data;
using ControlMantenimiento_NetWeb.BO;

namespace ControlMantenimiento_NetWeb.DAL
{
    public class AccesoDatos : IAccesoDatos
    {
        // Default Constructor
        public AccesoDatos() { }

        private SqlConnection Cn;   // Conexion 
        private SqlDataReader sdr;  // Cursor - Recordset de solo lectura
        private SqlCommand Cmd;     // Objeto de tipo Command para acceder a Procedimientos Almacenados        

        private void BuscarRegistro(string Tabla, string DatoBuscar, string Condicion)
        {
            try
            {
                Cn = new SqlConnection(Conexion.ObtenerConexion);
                Cmd = new SqlCommand("spr_CBuscarRegistro", Cn);
                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = Tabla;
                Cmd.Parameters.Add("p_DATOBUSCAR", SqlDbType.VarChar, 50).Value = DatoBuscar;
                Cmd.Parameters.Add("p_CONDICION", SqlDbType.VarChar, 50).Value = Condicion;
                Cn.Open();
                sdr = Cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ArrayList CargarListas(string Tabla, string Condicion)
        {
            ArrayList arlListado = new ArrayList();
            try
            {
                using (SqlConnection Cn = new SqlConnection(Conexion.ObtenerConexion))
                {
                    Cmd = new SqlCommand("spr_CCargarListado", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 30).Value = Tabla;
                    Cmd.Parameters.Add("p_CONDICION", SqlDbType.VarChar, 20).Value = Condicion;
                    Cn.Open();
                    using (sdr = Cmd.ExecuteReader(CommandBehavior.CloseConnection))
                        while (sdr.Read())
                        {
                            arlListado.Add(new CargaCombosListas(sdr.GetValue(0).ToString(), sdr.GetValue(1).ToString()));
                        }
                    sdr.Close();
                    LiberarRecursos();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                LiberarRecursos();
            }
            return arlListado;
        }

        public ArrayList CargarListado(string Tabla, string Condicion)
        {
            ArrayList arlListado = new ArrayList();
            try
            {
                using (SqlConnection Cn = new SqlConnection(Conexion.ObtenerConexion))
                {
                    Cmd = new SqlCommand("spr_CCargarListado", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 30).Value = Tabla;
                    Cmd.Parameters.Add("p_CONDICION", SqlDbType.VarChar, 20).Value = Condicion;
                    Cn.Open();
                    using (sdr = Cmd.ExecuteReader(CommandBehavior.CloseConnection))
                        while (sdr.Read())
                        {
                            arlListado.Add(new CargarListado(sdr.GetValue(0).ToString(), sdr.GetValue(1).ToString(), sdr.GetValue(2).ToString(), sdr.GetValue(3).ToString()));
                        }
                    sdr.Close();
                    LiberarRecursos();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                LiberarRecursos();
            }
            return arlListado;
        }

        public ArrayList ControlProgramacion(string Tabla)
        {
            ArrayList arlListControlProgramacion = new ArrayList();
            try
            {
                using (SqlConnection Cn = new SqlConnection(Conexion.ObtenerConexion))
                {
                    Cmd = new SqlCommand("spr_CCargarCombosListas", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 30).Value = Tabla;
                    Cn.Open();
                    using (sdr = Cmd.ExecuteReader(CommandBehavior.CloseConnection))
                        while (sdr.Read())
                        {
                            arlListControlProgramacion.Add(sdr.GetValue(2).ToString());
                            arlListControlProgramacion.Add(sdr.GetValue(0).ToString());
                            arlListControlProgramacion.Add(sdr.GetValue(1).ToString());
                        }
                    sdr.Close();
                    LiberarRecursos();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                LiberarRecursos();
            }
            return arlListControlProgramacion;
        }

        /*
         =======================================================================================================================================================
         Inicio Operaciones sobre estructura Operarios
         =======================================================================================================================================================
         */


        public Operario ObtenerAcceso(string DatoBuscar, string Clave)
        {
            Operario operario = new Operario();
            try
            {
                BuscarRegistro("OPERARIOS", DatoBuscar, Clave);
                if (sdr.Read())
                {
                    operario.Documento = sdr["DOCUMENTO"].ToString();
                    operario.Nombres = sdr["NOMBRES"].ToString();
                    operario.Apellidos = sdr["APELLIDOS"].ToString();
                    operario.Perfil = Convert.ToInt32(sdr["PERFIL"].ToString());
                }
                else
                {
                    operario = null;
                }
                sdr.Close();
                LiberarRecursos();
            }
            catch (Exception ex)
            {
                LiberarRecursos();
                throw ex;
            }
            finally
            {
                LiberarRecursos();
            }
            return operario;
        }

        public Operario ObtenerOperario(string DatoBuscar)
        {
            Operario operario = new Operario();
            try
            {
                BuscarRegistro("OPERARIOS", DatoBuscar, "");
                if (sdr.Read())
                {
                    operario.Documento = sdr["DOCUMENTO"].ToString();
                    operario.Nombres = sdr["NOMBRES"].ToString();
                    operario.Apellidos = sdr["APELLIDOS"].ToString();
                    operario.Correo = sdr["CORREO"].ToString();
                    operario.Telefono = sdr["TELEFONO"].ToString();
                    operario.Foto = sdr["FOTO"].ToString();
                }
                else
                {
                    operario = null;
                }
                sdr.Close();
                LiberarRecursos();
            }
            catch (Exception ex)
            {
                LiberarRecursos();
                throw ex;
            }
            finally
            {
                LiberarRecursos();
            }
            return operario;
        }

        public int GuardarOperario(Operario operario, string Accion, string Usuario)
        {
            int Resultado = -1;
            try
            {
                using (SqlConnection Cn = new SqlConnection(Conexion.ObtenerConexion))
                {
                    Cmd = new SqlCommand("spr_IUOperarios", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_ACCION", SqlDbType.VarChar, 1).Value = Accion;
                    Cmd.Parameters.Add("p_DOCUMENTO", SqlDbType.VarChar, 10).Value = operario.Documento;
                    Cmd.Parameters.Add("p_NOMBRES", SqlDbType.VarChar, 25).Value = operario.Nombres;
                    Cmd.Parameters.Add("p_APELLIDOS", SqlDbType.VarChar, 25).Value = operario.Apellidos;
                    Cmd.Parameters.Add("p_CORREO", SqlDbType.VarChar, 50).Value = operario.Correo;
                    Cmd.Parameters.Add("p_TELEFONO", SqlDbType.VarChar, 10).Value = operario.Telefono;
                    Cmd.Parameters.Add("p_FOTO", SqlDbType.VarChar, 50).Value = operario.Foto;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.VarChar, 10).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                    LiberarRecursos();
                }
            }
            catch (Exception e)
            {
                LiberarRecursos();
                throw e;
            }
            finally
            {
                LiberarRecursos();
            }
            return Resultado;

        }

        public int GuardarCambioClave(string Documento, string ClaveAnterior, string ClaveNueva)
        {
            int Resultado = -1;
            try
            {
                using (SqlConnection Cn = new SqlConnection(Conexion.ObtenerConexion))
                {
                    Cmd = new SqlCommand("spr_UCambioClave", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_DOCUMENTO", SqlDbType.VarChar, 10).Value = Documento;
                    Cmd.Parameters.Add("p_CLAVE_ANTERIOR", SqlDbType.VarChar, 20).Value = ClaveAnterior;
                    Cmd.Parameters.Add("p_CLAVE_NUEVA", SqlDbType.VarChar, 20).Value = ClaveNueva;
                    Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                }
            }
            catch (Exception e)
            {
                LiberarRecursos();
                throw e;
            }
            finally
            {
                LiberarRecursos();
            }
            return Resultado;
        }
        /*
         =======================================================================================================================================================
         Fin Operaciones sobre estructura Operarios
         =======================================================================================================================================================
         */

        /*
        =======================================================================================================================================================
        Inicio Operaciones sobre estructura ListaValores
        =======================================================================================================================================================
        */
        public ListaValores ObtenerListaValores(string DatoBuscar)
        {
            ListaValores listavalores = new ListaValores();
            try
            {
                BuscarRegistro("LISTAVALORES", DatoBuscar, "");
                if (sdr.Read())
                {
                    listavalores.Codigo = Convert.ToInt32(sdr["CODIGO"].ToString());
                    listavalores.Nombre = sdr["NOMBRE"].ToString();
                    listavalores.Descripcion = sdr["DESCRIPCION"].ToString();
                }
                else
                {
                    listavalores = null;
                }
                sdr.Close();
                LiberarRecursos();
            }
            catch (Exception ex)
            {
                LiberarRecursos();
                throw ex;
            }
            finally
            {
                LiberarRecursos();
            }
            return listavalores;
        }

        public int GuardarListaValores(ListaValores listavalores, string Usuario)
        {
            int Resultado = -1;
            try
            {
                using (SqlConnection Cn = new SqlConnection(Conexion.ObtenerConexion))
                {
                    Cmd = new SqlCommand("spr_IUListaValores", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_CODIGO", SqlDbType.Int, 10).Value = listavalores.Codigo;
                    Cmd.Parameters.Add("p_NOMBRE", SqlDbType.VarChar, 50).Value = listavalores.Nombre;
                    Cmd.Parameters.Add("p_DESCRIPCION", SqlDbType.VarChar, 255).Value = listavalores.Descripcion;
                    Cmd.Parameters.Add("p_TIPO", SqlDbType.VarChar, 50).Value = listavalores.Tipo;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.VarChar, 10).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                    LiberarRecursos();
                }
            }
            catch (Exception e)
            {
                LiberarRecursos();
                throw e;
            }
            finally
            {
                LiberarRecursos();
            }
            return Resultado;
        }
        /*
        =======================================================================================================================================================
        Fin Operaciones sobre estructura ListaValores
        =======================================================================================================================================================
        */

        /*
        =======================================================================================================================================================
        Inicio Operaciones sobre estructura Equipos
        =======================================================================================================================================================
        */
        public Equipo ObtenerEquipo(string DatoBuscar)
        {
            Equipo equipo = new Equipo();
            try
            {
                BuscarRegistro("EQUIPOS", DatoBuscar, "Codigo");
                if (sdr.Read())
                {
                    equipo.CodigoEquipo = Convert.ToInt32(sdr["CODIGOEQUIPO"].ToString());
                    equipo.NombreEquipo = sdr["NOMBREEQUIPO"].ToString();
                    equipo.CodigoMarca = Convert.ToInt32(sdr["CODIGOMARCA"].ToString());
                    equipo.Serie = sdr["SERIE"].ToString();
                    equipo.CodigoLinea = Convert.ToInt32(sdr["CODIGOLINEA"].ToString());
                    if (sdr.GetBoolean(sdr.GetOrdinal("LUBRICACION"))) equipo.Lubricacion = 1;
                }
                else
                {
                    equipo = null;
                }
                sdr.Close();
                LiberarRecursos();
            }
            catch (Exception ex)
            {
                LiberarRecursos();
                throw ex;
            }
            finally
            {
                LiberarRecursos();
            }
            return equipo;
        }

        public int GuardarEquipo(Equipo equipo, string Usuario)
        {
            int Resultado = -1;
            try
            {
                using (SqlConnection Cn = new SqlConnection(Conexion.ObtenerConexion))
                {
                    Cmd = new SqlCommand("spr_IUEquipos", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_CODIGOEQUIPO", SqlDbType.Int, 10).Value = equipo.CodigoEquipo;
                    Cmd.Parameters.Add("p_NOMBREEQUIPO", SqlDbType.VarChar, 50).Value = equipo.NombreEquipo;
                    Cmd.Parameters.Add("p_CODIGOMARCA", SqlDbType.Int, 10).Value = equipo.CodigoMarca;
                    Cmd.Parameters.Add("p_SERIE", SqlDbType.VarChar, 20).Value = equipo.Serie;
                    Cmd.Parameters.Add("p_CODIGOLINEA", SqlDbType.Int, 10).Value = equipo.CodigoLinea;
                    Cmd.Parameters.Add("p_LUBRICACION", SqlDbType.Int, 1).Value = equipo.Lubricacion;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.VarChar, 10).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                    LiberarRecursos();
                }

            }
            catch (Exception e)
            {
                LiberarRecursos();
                throw e;
            }
            finally
            {
                LiberarRecursos();
            }
            return Resultado;
        }

        /*
       =======================================================================================================================================================
       Fin Operaciones sobre estructura Equipos
       =======================================================================================================================================================
       */

        /*
       =======================================================================================================================================================
       Inicio Operaciones sobre estructura Mantenimiento
       =======================================================================================================================================================
       */
        public Mantenimiento ObtenerMantenimiento(string DatoBuscar)
        {
            Mantenimiento mantenimiento = new Mantenimiento();
            try
            {
                BuscarRegistro("MANTENIMIENTO", DatoBuscar, "");
                if (sdr.Read())
                {
                    mantenimiento.CodigoEquipo = Convert.ToInt32(sdr["CODIGOEQUIPO"].ToString());
                    mantenimiento.Documento = Convert.ToDouble(sdr["DOCUMENTO"].ToString());
                    mantenimiento.Fecha = Convert.ToDateTime(sdr["FECHA"].ToString());
                    mantenimiento.Observaciones = sdr["OBSERVACIONES"].ToString();
                }
                else
                {
                    mantenimiento = null;
                }
                sdr.Close();
                LiberarRecursos();
            }
            catch (Exception ex)
            {
                LiberarRecursos();
                throw ex;
            }
            finally
            {
                LiberarRecursos();
            }
            return mantenimiento;
        }

        public int GuardarMantenimiento(Mantenimiento mantenimiento, string Accion, string Usuario)
        {
            int Resultado = -1;
            try
            {
                using (SqlConnection Cn = new SqlConnection(Conexion.ObtenerConexion))
                {
                    Cmd = new SqlCommand("spr_IUMantenimiento", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_ACCION", SqlDbType.VarChar, 1).Value = Accion;
                    Cmd.Parameters.Add("p_CODIGOEQUIPO", SqlDbType.Int, 10).Value = mantenimiento.CodigoEquipo;
                    Cmd.Parameters.Add("p_DOCUMENTO", SqlDbType.Int, 10).Value = mantenimiento.Documento;
                    Cmd.Parameters.Add("p_FECHA", SqlDbType.DateTime, 10).Value = mantenimiento.Fecha;
                    Cmd.Parameters.Add("p_OBSERVACIONES", SqlDbType.VarChar, 255).Value = mantenimiento.Observaciones;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.VarChar, 10).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                    LiberarRecursos();
                }
            }
            catch (Exception e)
            {
                LiberarRecursos();
                throw e;
            }
            finally
            {
                LiberarRecursos();
            }
            return Resultado;
        }

        /*
       =======================================================================================================================================================
       Fin Operaciones sobre estructura Mantenimiento
       =======================================================================================================================================================
       */


        public int EliminarRegistro(string DatoEliminar, string Tabla)
        {
            int Resultado = 0;
            try
            {
                using (SqlConnection Cn = new SqlConnection(Conexion.ObtenerConexion))
                {
                    Cmd = new SqlCommand("spr_DRegistro", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = Tabla;
                    Cmd.Parameters.Add("p_CONDICION", SqlDbType.Int, 10).Value = DatoEliminar;
                    Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                    LiberarRecursos();
                }
            }
            catch (Exception e)
            {
                LiberarRecursos();
                throw e;
            }
            finally
            {
                LiberarRecursos();
            }
            return Resultado;
        }

        private void LiberarRecursos()
        {
            Cmd.Dispose();
            if (Cn != null)
            {
                Cn.Close();
                Cn.Dispose();
            }
        }

    }

}
