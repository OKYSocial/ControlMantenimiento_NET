﻿// Clase para cargar en los Repeater los diferentes listados
namespace ControlMantenimiento_NetWeb.BO
{
    public class CargarListado
    {
        private string Columna1;
        private string Columna2;
        private string Columna3;
        private string Columna4;

        public CargarListado(string columna1,
                             string columna2,
                             string columna3,
                             string columna4)
                             {
                                Columna1 = columna1;
                                Columna2 = columna2;
                                Columna3 = columna3;
                                Columna4 = columna4;
                             }

        public string columna1
        {
            get { return Columna1; }
            set { Columna1 = value; }
        }
        public string columna2
        {
            get { return Columna2; }
            set { Columna2 = value; }
        }
        public string columna3
        {
            get { return Columna3; }
            set { Columna3 = value; }
        }
        public string columna4
        {
            get { return Columna4; }
            set { Columna4 = value; }
        }
    }
}