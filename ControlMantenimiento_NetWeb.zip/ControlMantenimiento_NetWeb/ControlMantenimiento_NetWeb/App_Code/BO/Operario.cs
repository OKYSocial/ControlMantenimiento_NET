﻿namespace ControlMantenimiento_NetWeb.BO
{
    public class Operario // Clase que representa la estructura en BD para Operarios
    {        
        // Default Constructor
        public Operario() { }

        public string Documento { get; set; }

        public string Nombres { get; set; }

        public string Apellidos { get; set; }

        public string Correo { get; set; }

        public string Telefono { get; set; }

        public string Clave { get; set; }

        public int Perfil { get; set; }

        public string Foto { get; set; }
    }    
}
