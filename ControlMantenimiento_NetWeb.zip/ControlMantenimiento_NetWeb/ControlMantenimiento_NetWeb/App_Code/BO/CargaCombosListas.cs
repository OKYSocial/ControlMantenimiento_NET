﻿// Clase que nos permite cargar Pares de clave y valor para los ComboBox
namespace ControlMantenimiento_NetWeb.BO
{
    public class CargaCombosListas
    {
        private string Codigo;
        private string Detalle;

        public string codigo
        {
            get { return Codigo; }
            set { Codigo = value; }
        }

        public string detalle
        {
            get { return Detalle; }
            set { Detalle = value; }
        }

        // Default Constructor
        public CargaCombosListas()
        {
        }

        public CargaCombosListas(string codigo, string detalle)
        {
            Codigo = codigo;
            Detalle = detalle;
        }
    }
}
