﻿namespace ControlMantenimiento_NetWeb.BO
{
    public class Equipo // Clase que representa la estructura en BD para Equipos
    {
        // Default Constructor
        public Equipo() { }

        public int Equipo_id { get; set; }

        public string Nombre_equipo { get; set; }

        public int Marca { get; set; }

        public string Serie { get; set; }

        public int Linea { get; set; }

        public int Lubricacion { get; set; }
    }
}
