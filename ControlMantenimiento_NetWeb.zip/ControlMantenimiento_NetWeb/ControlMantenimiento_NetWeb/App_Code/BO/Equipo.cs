﻿namespace ControlMantenimiento_NetWeb.BO
{
    public class Equipo // Clase que representa la estructura en BD para Equipos
    {
        // Default Constructor
        public Equipo() { }

        public int CodigoEquipo { get; set; }

        public string NombreEquipo { get; set; }

        public int CodigoMarca { get; set; }

        public string Serie { get; set; }

        public int CodigoLinea { get; set; }

        public int Lubricacion { get; set; }
    }
}
