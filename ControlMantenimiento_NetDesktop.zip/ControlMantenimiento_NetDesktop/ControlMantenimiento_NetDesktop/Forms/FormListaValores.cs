﻿using System;
using System.Data;
using System.Windows.Forms;
using ControlMantenimiento_NetDesktop.BO;
using ControlMantenimiento_NetDesktop.BLL;

namespace ControlMantenimiento_NetDesktop
{
    public partial class FormListaValores : Form
    {
        public FormListaValores()
        {
            InitializeComponent();
            this.TextBoxNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxNombre_KeyPress);
            this.TextBoxDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxDescripcion_KeyPress);
            this.ListBoxListaValores.Click += new System.EventHandler(this.lstListaValores_Click);
        }

        private Controlador _controlador = Funciones.CrearControlador();
        private bool Grabar;
        private KeyPressEventArgs Tecla = new KeyPressEventArgs('\r'); // Send Enter
       
        private void FrmListaValores_Load(object sender, EventArgs e)
        {
            this.Text = BLL.Funciones.ValorTipo.ToLower();
            this.Text = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(this.Text);
            CargarListaSeleccion();
        }

        private void CargarListaSeleccion()
        {
            ListBoxListaValores.ValueMember = "CODIGO";
            ListBoxListaValores.DisplayMember = "DETALLE";
            
            if (BLL.Funciones.ValorTipo == "LINEAS")
            {
                ListBoxListaValores.DataSource = _controlador.CargarListas("CLineas");
            }
            else
            {
                ListBoxListaValores.DataSource = _controlador.CargarListas("CMarcas");
            }
        }

        private void TextBoxNombre_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.Validar_CampoVacio(TextBoxNombre.Text))
                {
                    Grabar = false;
                    MessageBox.Show(BLL.Mensajes.MensajeCampoRequerido, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxNombre.Focus();
                    errorPro.SetError(TextBoxNombre, BLL.Mensajes.MensajeCampoRequerido);
                }
                else
                {
                    TextBoxDescripcion.Focus();                    
                }
            }
        }

        private void TextBoxDescripcion_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                BLL.Funciones.EliminarTabulador(TextBoxDescripcion.Text, "");
                ButtonGrabar.Focus();
            }
        }

        private void ButtonGrabar_Click(object sender, EventArgs e)
        {
            Grabar = true;
            TextBoxNombre_KeyPress(ButtonGrabar, Tecla);
            if (Grabar)
            {  
               Guardar(Convert.ToInt32(lblCodigo.Text),  (lblCodigo.Text == "0") ? BLL.Mensajes.MensajeGraba : BLL.Mensajes.MensajeActualiza);               
            }
        }

        private void Guardar(int ElCodigo, string Mensaje)
        {
            int Resultado;
            ListaValores listavalores = new ListaValores();
            listavalores.Codigo = ElCodigo;
            listavalores.Nombre = TextBoxNombre.Text.Trim();
            listavalores.Descripcion = TextBoxDescripcion.Text.Trim();
            listavalores.Tipo = BLL.Funciones.ValorTipo;

            Resultado = _controlador.Guardar(listavalores, "");
            if (Resultado == 0)
            {
                MessageBox.Show(Mensaje, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarListaSeleccion();
                Limpiar();
            }
            else if (Resultado == 1)
            {
              MessageBox.Show(BLL.Mensajes.Mensaje8, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
              TextBoxNombre.Focus();
              errorPro.SetError(TextBoxNombre, BLL.Mensajes.Mensaje8);
            }
            else
            {
                MessageBox.Show(BLL.Mensajes.MensajeErrorBD, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }            
        }

        private void ButtonBuscar_Click(object sender, EventArgs e)
        {
            if (ListBoxListaValores.Items.Count != 0)
            {
                ListBoxListaValores.Visible = true;
            }
        }

        private void lstListaValores_Click(object sender, EventArgs e)
        {
            lblCodigo.Text = ListBoxListaValores.SelectedValue.ToString();
            ListBoxListaValores.Visible = false;
            LlenarCampos();
        }

        private void LlenarCampos()
        {
            ListaValores listavalores = (ListaValores) _controlador.ObtenerRegistro(lblCodigo.Text,"LISTAVALORES");
            if (listavalores != null)
            {
                ButtonEliminar.Enabled = true;
                TextBoxNombre.Text = listavalores.Nombre;
                TextBoxDescripcion.Text = listavalores.Descripcion;
                TextBoxNombre.Focus();
            }
        }

        private void Limpiar()
        {
            BLL.Funciones.LimpiarForma(panel2);
            ListBoxListaValores.Visible = false;
            ButtonEliminar.Enabled = false;
            errorPro.Clear();
            lblCodigo.Text = "0";
            TextBoxNombre.Focus();
        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {            
            Limpiar();
        }

        private void ButtonSalir_Click(object sender, EventArgs e)
        {
            _controlador = null;
            this.Close();
            this.Dispose();
        }

        private void ButtonEliminar_Click(object sender, EventArgs e)
        {
            int Resultado;
            if (MessageBox.Show(BLL.Mensajes.MensajeConfirmarBorrado, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {
                Resultado = _controlador.EliminarRegistro(lblCodigo.Text, "LISTAVALORES");
                if (Resultado == 0)
                {
                    MessageBox.Show(BLL.Mensajes.MensajeBorrado, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CargarListaSeleccion();
                    Limpiar();
                }
                else if (Resultado == 1)
                {
                    MessageBox.Show(BLL.Mensajes.Mensaje9, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(BLL.Mensajes.MensajeErrorBD, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void ButtonAyuda_Click(object sender, EventArgs e)
        {
            /* System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.EnableRaisingEvents = false;
            proc.StartInfo.FileName = "E:/Fuentes CM/ControlMantenimiento-NetDesktop/ControlMantenimiento-NetDesktop/Ayudas/Ayuda.chm";
            proc.Start();
            proc.Dispose();*/

            // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
            // donde descomprimió el archivo descargado de la web
        }
    }       
}
