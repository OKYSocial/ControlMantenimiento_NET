﻿using System;
using System.Drawing;
using System.Windows.Forms;
using ControlMantenimiento_NetDesktop.BO;
using ControlMantenimiento_NetDesktop.BLL;

namespace ControlMantenimiento_NetDesktop
{
    public partial class FormOperarios : Form
    {
        public FormOperarios()
        {
            InitializeComponent();
            var blankContextMenu = new ContextMenuStrip();            
            TextBoxDocumento.ContextMenuStrip = blankContextMenu;
            TextBoxNombres.ContextMenuStrip = blankContextMenu;
            TextBoxApellidos.ContextMenuStrip = blankContextMenu;
            TextBoxTelefono.ContextMenuStrip = blankContextMenu;
            
            // Habilitando teclas de Enter y Tab
            this.TextBoxDocumento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxDocumento_KeyPress);
            this.TextBoxNombres.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxNombres_KeyPress);
            this.TextBoxApellidos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxApellidos_KeyPress);
            this.TextBoxCorreo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxCorreo_KeyPress);
            this.TextBoxTelefono.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxTelefono_KeyPress);                 
        }

        private int ElOperario = 0;
        private Controlador _controlador = Funciones.CrearControlador();
        private bool   Grabar;       
        private string RutaFoto = "";
        private KeyPressEventArgs Tecla = new KeyPressEventArgs('\r'); // Send Enter
        
        private void FormOperarios_Load(object sender, EventArgs e)
        {
            CargarListaSeleccion();
        }

        private void CargarListaSeleccion()
        {           
            ListBoxOperarios.ValueMember = "CODIGO";        // Documento de Operario a relacionar en BD
            ListBoxOperarios.DisplayMember = "DETALLE";     // Visualizar Nombres y Apellidos de Operario            
            ListBoxOperarios.DataSource = _controlador.CargarListas("TBL_OPERARIOS");            
        }

        private void TextBoxDocumento_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {           
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.Validar_CampoVacio(TextBoxDocumento.Text))
                {
                    Grabar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxDocumento.Focus();
                    errorPro.SetError(TextBoxDocumento, Mensajes.MensajeCampoRequerido);
                }
                else if (TextBoxDocumento.Text.Length < 6)
                {
                    Grabar = false;
                    MessageBox.Show(Mensajes.Mensaje15, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxDocumento.Focus();
                    errorPro.SetError(TextBoxDocumento, Mensajes.Mensaje15);
                }
                else if (TextBoxDocumento.Text.Substring(0, 1) == "0")
                {
                    Grabar = false;
                    MessageBox.Show(Mensajes.Mensaje6, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxDocumento.Focus();
                    errorPro.SetError(TextBoxDocumento, Mensajes.Mensaje6);
                }
                else
                {
                    errorPro.Clear();
                    if (TextBoxDocumento.Enabled)
                    {
                        LlenarCampos();
                    }
                    else
                    {
                        TextBoxNombres.Focus();
                    }                    
                }              
            }
            else
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
                {
                    e.Handled = true; // Remover el caracter
                }
            }
        }

        private void TextBoxNombres_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
        if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.Validar_CampoVacio(TextBoxNombres.Text))
                {
                    Grabar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxNombres.Focus();
                    errorPro.SetError(TextBoxNombres, Mensajes.MensajeCampoRequerido);
                }               
                else
                {
                    TextBoxNombres.Text = Funciones.EliminarTabulador(TextBoxNombres.Text, "1MAY");
                    errorPro.Clear();
                    TextBoxApellidos.Focus();
                }  
            }
            else 
            {
                if ((e.KeyChar < 65 || e.KeyChar > 97) && (e.KeyChar < 90 || e.KeyChar > 122) && e.KeyChar != 8 && e.KeyChar != 32)                
                {
                    e.Handled = true ; // Remover el caracter
                }
            }
        }

        private void TextBoxApellidos_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.Validar_CampoVacio(TextBoxApellidos.Text))
                {
                    Grabar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxApellidos.Focus();
                    errorPro.SetError(TextBoxApellidos, Mensajes.MensajeCampoRequerido);
                }
                else
                {
                    TextBoxApellidos.Text = Funciones.EliminarTabulador(TextBoxApellidos.Text, "1MAY");
                    errorPro.Clear();
                    TextBoxCorreo.Focus();
                }
            }
            else
            {
                if ((e.KeyChar < 65 || e.KeyChar > 97) && (e.KeyChar < 90 || e.KeyChar > 122) && e.KeyChar != 8 && e.KeyChar != 32)
                {
                    e.Handled = true; // Remover el caracter
                }
            }
        }

        private void TextBoxCorreo_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (TextBoxCorreo.Text.Length != 0)
                {
                    TextBoxCorreo.Text = TextBoxCorreo.Text.ToLower();
                    if (Funciones.Validar_Correo(TextBoxCorreo.Text))                    
                    {
                        Grabar = false;
                        MessageBox.Show(Mensajes.Mensaje16, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxCorreo.Focus();
                        errorPro.SetError(TextBoxCorreo, Mensajes.Mensaje16);
                    }
                    else
                    {
                        errorPro.Clear();
                        TextBoxTelefono.Focus();
                    }                    
                }
                else
                {
                    TextBoxTelefono.Focus();
                }                
            }
        }

        private void TextBoxTelefono_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (e.KeyChar != 8) // Habilitar tecla de retroceso
            {
                if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
                {                    
                    if (Funciones.Validar_CampoVacio(TextBoxTelefono.Text))
                    {
                        Grabar = false;
                        MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxTelefono.Focus();
                        errorPro.SetError(TextBoxTelefono, Mensajes.MensajeCampoRequerido);
                    }
                    else
                    {
                        if ((TextBoxTelefono.Text.Length != 7) && (TextBoxTelefono.Text.Length != 10))
                        {
                            Grabar = false;
                            MessageBox.Show(Mensajes.Mensaje17, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            TextBoxTelefono.Focus();
                            errorPro.SetError(TextBoxTelefono, Mensajes.Mensaje17);
                        }
                        else if (TextBoxTelefono.Text.Substring(0, 1) == "0")
                        {
                            Grabar = false;
                            MessageBox.Show(Mensajes.Mensaje6, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            TextBoxTelefono.Focus();
                            errorPro.SetError(TextBoxTelefono, Mensajes.Mensaje6);
                        }
                        else
                        {
                            errorPro.Clear();
                            ButtonGrabar.Focus();
                        }
                    }
                }
                else
                    if (e.KeyChar >= 48 && e.KeyChar <= 57)
                        e.Handled = false;
                    else if (e.KeyChar == 46)
                        e.Handled = false;
                    else
                        e.Handled = true;
            }
        }

        private void ButtonGrabar_Click(object sender, EventArgs e)
        {
          Grabar = true;
          TextBoxDocumento_KeyPress(ButtonGrabar,Tecla);
          if (Grabar)
          {
              TextBoxNombres_KeyPress(ButtonGrabar, Tecla);         
              if (Grabar)
              {
                  TextBoxApellidos_KeyPress(ButtonGrabar, Tecla);         
                  if (Grabar)
                  {
                      TextBoxCorreo_KeyPress(ButtonGrabar, Tecla);
                      if (Grabar)
                      {
                        TextBoxTelefono_KeyPress(ButtonGrabar, Tecla);
                        if (Grabar)
                        {
                                Guardar((TextBoxDocumento.Enabled) ? Mensajes.MensajeGraba : Mensajes.MensajeActualiza);
                        }
                      }
                  }
              }
          }     
        }
        
        private void Guardar(string Mensaje)
        {
            int Resultado;
            Operario operario = new Operario();
            operario.Operario_id = ElOperario;
            operario.Documento = TextBoxDocumento.Text;
            operario.Nombres = TextBoxNombres.Text.Trim();
            operario.Apellidos = TextBoxApellidos.Text.Trim().Trim();
            operario.Telefono = TextBoxTelefono.Text;
            operario.Correo = TextBoxCorreo.Text.Trim(); 
            operario.Foto = RutaFoto;
            Resultado = _controlador.GuardarOperario(operario);
            if (Resultado == 0)
            {
                MessageBox.Show(Mensaje, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (Funciones.PerfilAcceso == 1)
                {                   
                    CargarListaSeleccion();
                }
                else
                {
                  ButtonSalir.PerformClick();
                }
            }
            else if (Resultado == 1)
            {
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.Mensaje26, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Limpiar();
        }
      
        private void Limpiar()
        {
          ElOperario = 0;
          ButtonEliminar.Enabled = false; 
          Funciones.LimpiarForma(panel2);
          errorPro.Clear();
          PictureBoxFotoUsuario.Image = null;
          RutaFoto = "";         
          ListBoxOperarios.Visible = false;          
          TextBoxDocumento.Enabled = true; // Habilitar Campo de documento si esta Inactivo            
          TextBoxDocumento.Focus();
        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {          
          Limpiar();
        }

        private void PictureBoxFotoUsuario_Click(object sender, EventArgs e)
        {
            OpenFileDialog oFD = new OpenFileDialog();
            oFD.Title = "Seleccionar imagen";
            oFD.Filter = "Imagenes|*.jpg;*.gif;*.png;*.bmp|Todos (*.*)|*.*";
            if (oFD.ShowDialog() == DialogResult.OK)
            {
                RutaFoto = oFD.FileName;
                System.IO.FileInfo peso = new System.IO.FileInfo(oFD.FileName);
                if ((RutaFoto.Length) > 50)
                {
                    MessageBox.Show(Mensajes.Mensaje28, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (peso.Length > 133000) // Imagen de 3x4 no debería superar este peso
                {
                    MessageBox.Show(Mensajes.Mensaje29, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    this.PictureBoxFotoUsuario.Image = Image.FromFile(RutaFoto);
                }
            }
        }

        private void LlenarCampos()// Volcar datos de estrucura de Base da Datos sobre el Formulario actual
        {  
            Operario operario = (Operario) _controlador.ObtenerRegistro(ElOperario, "TBL_OPERARIOS"); 
            if (operario != null)
            {
                TextBoxDocumento.Enabled = false;
                if (Funciones.PerfilAcceso == 1)
                {
                    ButtonEliminar.Enabled = true;
                }
                ElOperario = operario.Operario_id;
                TextBoxDocumento.Text = operario.Documento;
                TextBoxNombres.Text = operario.Nombres;
                TextBoxApellidos.Text = operario.Apellidos;
                TextBoxCorreo.Text = operario.Correo;
                TextBoxTelefono.Text = operario.Telefono;
                if (operario.Foto != null && operario.Foto != "")
                {
                    try
                    {
                        RutaFoto = operario.Foto;
                        PictureBoxFotoUsuario.Image = Image.FromFile(RutaFoto);
                    }
                    catch
                    {
                        MessageBox.Show(Mensajes.Mensaje24, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }                
            }
            TextBoxNombres.Focus();
        }

        private void ButtonSalir_Click(object sender, EventArgs e)
        {
            _controlador = null;
            this.Close();
            this.Dispose();
        }

        private void ButtonEliminar_Click(object sender, EventArgs e)
        {
            int Resultado;
            if (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {
               Resultado = _controlador.EliminarRegistro(Convert.ToInt32(TextBoxDocumento.Text), "TBL_OPERARIOS");
               if (Resultado == 0)
               {
                   MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                   CargarListaSeleccion();
                   Limpiar();
               }
                else if (Resultado == 1)
               {
                  MessageBox.Show(Mensajes.Mensaje20, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
               }
               else
               {
                    MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
               }                
               
            }
        }
       
        private void ButtonBuscar_Click(object sender, EventArgs e)
        {

            if (ListBoxOperarios.Items.Count != 0)
            {
                ListBoxOperarios.Visible = true;
            }            
        }

        private void ListBoxOperarios_DoubleClick(object sender, EventArgs e)
        {
            ElOperario = Convert.ToInt32(ListBoxOperarios.SelectedValue.ToString());
            ListBoxOperarios.Visible = false;
            LlenarCampos();       
        }

        private void LabelBorrarFoto_Click(object sender, EventArgs e)
        {
            PictureBoxFotoUsuario.Image = null;
            RutaFoto = "";          
        }

        private void ButtonAyuda_Click(object sender, EventArgs e)
        {
            /* System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.EnableRaisingEvents = false;
            proc.StartInfo.FileName = "E:/Fuentes CM/ControlMantenimiento-NetDesktop/ControlMantenimiento-NetDesktop/Ayudas/Ayuda.chm";
            proc.Start();
            proc.Dispose();*/

            // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
            // donde descomprimió el archivo descargado de la web
        }                                  
    }
}
