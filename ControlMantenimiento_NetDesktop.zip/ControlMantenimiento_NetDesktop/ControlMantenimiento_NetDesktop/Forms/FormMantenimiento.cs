﻿
/*=================================================================================== 
 La norma es que no puede haber sino una sola programación por equipo
 Un Operario no puede estar asignado en la misma fecha para varios mantenimientos
 ==================================================================================== */

using System;
using System.Windows.Forms;
using ControlMantenimiento_NetDesktop.BO;
using ControlMantenimiento_NetDesktop.BLL;
using System.Collections;

namespace ControlMantenimiento_NetDesktop
{
    public partial class FormMantenimiento : Form
    {
        public FormMantenimiento()
        {
            InitializeComponent();
            this.DropDownListEquipos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DropDownListEquipos_KeyPress);
            this.DropDownListOperarios.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DropDownListOperarios_KeyPress);
            this.DateTimePickerFecha.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DateTimePickerFecha_KeyPress);
            this.TextBoxObservaciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxObservaciones_KeyPress);
        }

        private Controlador _controlador = Funciones.CrearControlador();
        private bool Grabar;
        private KeyPressEventArgs Tecla = new KeyPressEventArgs('\r'); // Send Enter

        private void FormMantenimiento_Load(object sender, EventArgs e)
        {
            ArrayList arlListado = new ArrayList();
            if (Funciones.Fuente == "CPROGRAMACION")
            {
                ButtonBuscar.Visible = true;
                lbMensaje.Visible = true;
                ButtonGrabar.Enabled = false;
                arlListado = _controlador.ControlProgramacion("CONTROLPROGRAMACION");
            }
            else 
            {
                arlListado = _controlador.ControlProgramacion("CONTROLPROGRAMAREQUIPOS");               
            }


            ArrayList arlListadoEquipos = new ArrayList();
            ArrayList arlListadoOperarios = new ArrayList();

            for (int i = 0; i < arlListado.Count; i++)
            {
                if (Convert.ToString(arlListado[i]).Trim().Equals("EQUIPOS"))
                {
                    arlListadoEquipos.Add(new CargaCombosListas(arlListado[i + 1].ToString(), arlListado[i + 1].ToString() + " " + arlListado[i + 2].ToString()));
                    i++; i++;
                }
                else if (Convert.ToString(arlListado[i]).Trim().Equals("OPERARIOS"))
                {
                    arlListadoOperarios.Add(new CargaCombosListas(arlListado[i + 1].ToString(), arlListado[i + 1].ToString() + " " + arlListado[i + 2].ToString()));
                    i++; i++;
                }
            }

            if (arlListadoOperarios == null)
            {
                MessageBox.Show(Mensajes.Mensaje13, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                ButtonSalir.PerformClick();
            }
            else if (arlListadoEquipos == null)
            {
                MessageBox.Show(Mensajes.Mensaje14, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                ButtonSalir.PerformClick();
            }
            else
            {

                DropDownListEquipos.ValueMember = "CODIGO";
                DropDownListEquipos.DisplayMember = "DETALLE";
                DropDownListEquipos.DataSource = arlListadoEquipos;

                DropDownListOperarios.ValueMember = "CODIGO";
                DropDownListOperarios.DisplayMember = "DETALLE";
                DropDownListOperarios.DataSource = arlListadoOperarios;
            }
        }

        private void CargarEquipos()
        {   
           DropDownListEquipos.ValueMember = "CODIGO";
           DropDownListEquipos.DisplayMember = "DETALLE";
           DropDownListEquipos.DataSource = _controlador.CargarListas(Funciones.Fuente);
        }

        private void DropDownListEquipos_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                DropDownListOperarios.Focus();
            }
        }

        private void DropDownListOperarios_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                DateTimePickerFecha.Focus();
            }
        }

        private void DateTimePickerFecha_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                DateTimePickerFecha_ValueChanged(DateTimePickerFecha, e);
            }            
        }

        private void TextBoxObservaciones_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
               Funciones.EliminarTabulador(TextBoxObservaciones.Text, "");
               ButtonGrabar.Focus();
            }
        }

        private void ButtonGrabar_Click(object sender, EventArgs e)
        {
            Grabar = true;
            DateTimePickerFecha_KeyPress(ButtonGrabar, Tecla);              
            if (Grabar)
            {
                if (Funciones.Fuente == "CPROGRAMAREQUIPOS")
                {
                    Guardar("I", Mensajes.MensajeGraba);
                }
                else
                {
                    Guardar("U", Mensajes.MensajeActualiza);
                }
            }            
        }

        private void Guardar(string Accion, string Mensaje)
        {
            int Resultado;
            Mantenimiento mantenimiento = 
                new Mantenimiento();
            mantenimiento.CodigoEquipo = Convert.ToInt32(DropDownListEquipos.SelectedValue.ToString()); 
            mantenimiento.Documento = Convert.ToDouble(DropDownListOperarios.SelectedValue.ToString()); 
            mantenimiento.Fecha = Convert.ToDateTime(DateTimePickerFecha.Value);
            mantenimiento.Observaciones = TextBoxObservaciones.Text;
            
            Resultado = _controlador.Guardar(mantenimiento, Accion);
            if (Resultado == 0)
            {
                MessageBox.Show(Mensaje, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarEquipos();
                Limpiar();
            }
            else if (Resultado == 1)
            {
                MessageBox.Show(Mensajes.Mensaje10, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                DropDownListOperarios.Focus();
                errorPro.SetError(DropDownListOperarios, Mensajes.Mensaje10);
            }
            else
            {
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            if (DropDownListEquipos.Items.Count <= 0)
            {
                ButtonSalir.PerformClick();
            }
        }

        private void Limpiar()
        {
            ButtonEliminar.Enabled = false;
            DropDownListEquipos.Enabled = true;
            Funciones.LimpiarForma(panel2);
            DateTimePickerFecha.Value = DateTime.Now.Date;
            errorPro.Clear();
            if (Funciones.Fuente == "CPROGRAMACION")
            {
                ButtonGrabar.Enabled = false;
            }
            DropDownListEquipos.Focus();
        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {            
            Limpiar();            
        }
                
        private void ButtonBuscar_Click(object sender, EventArgs e)
        {
            LlenarCampos();        
        }
        
        private void LlenarCampos()
        {
          Mantenimiento mantenimiento = (Mantenimiento)_controlador.ObtenerRegistro(DropDownListEquipos.SelectedValue.ToString(),"MANTENIMIENTO");
          if (mantenimiento != null)
          {
              ButtonEliminar.Enabled = true;
              DropDownListEquipos.Enabled = false;
              DropDownListOperarios.SelectedValue = mantenimiento.Documento.ToString();
              ButtonEliminar.Enabled = true;
              DateTimePickerFecha.Value = mantenimiento.Fecha;
              TextBoxObservaciones.Text = mantenimiento.Observaciones;
              ButtonGrabar.Enabled = true;
              DropDownListOperarios.Focus();
          }
        }

        private void ButtonSalir_Click(object sender, EventArgs e)
        {
            _controlador = null;
            this.Close();
            this.Dispose();
        }

        private void ButtonEliminar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {
                
                if (_controlador.EliminarRegistro(DropDownListEquipos.SelectedValue.ToString(), "MANTENIMIENTO")==0)
                {
                    MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                Limpiar();
                CargarEquipos();
                if (DropDownListEquipos.Items.Count <= 0)
                {
                    ButtonSalir.PerformClick();
                }
            }
            
        }

        private void DateTimePickerFecha_ValueChanged(object sender, EventArgs e)
        {
            if (DateTimePickerFecha.Value < DateTime.Now.Date)
            {
                Grabar = false;
                MessageBox.Show(Mensajes.Mensaje27, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                DateTimePickerFecha.Focus();
                errorPro.SetError(DateTimePickerFecha, Mensajes.Mensaje27);
            }
            else
            {
                errorPro.Clear();
                TextBoxObservaciones.Focus ();
            }
        }

        private void ButtonAyuda_Click(object sender, EventArgs e)
        {
           /* System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.EnableRaisingEvents = false;
            proc.StartInfo.FileName = "E:/Fuentes CM/ControlMantenimiento-NetDesktop/ControlMantenimiento-NetDesktop/Ayudas/Ayuda.chm";
            proc.Start();
            proc.Dispose();*/

            // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
            // donde descomprimió el archivo descargado de la web
        }
                      

    }
}
