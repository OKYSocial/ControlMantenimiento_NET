﻿using System;
using System.Windows.Forms;
using ControlMantenimiento_NetDesktop.BLL;

namespace ControlMantenimiento_NetDesktop
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
        }

        private void FormMenu_Load(object sender, EventArgs e)
        {
            if (Funciones.PerfilAcceso == 1) // Solo si tiene perfil de Administrador habilitar
            {
                menuToolStripMenuItem.Enabled = true;
                toolStripButton2.Enabled = true;
                toolStripButton3.Enabled = true;
                toolStripButton4.Enabled = true;
                toolStripButton5.Enabled = true;
                toolStripButton6.Enabled = true;
            }
            lblUsuarioConectado.Text = lblUsuarioConectado.Text + " " + Funciones.NombreUsuario;
        }

        private void operariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SeleccionarOpcion(0);  
        }

        private void equiposToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SeleccionarOpcion(1);
        }

        private void programarMantenimientoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SeleccionarOpcion(2);
        }

        private void modificarProgramacionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SeleccionarOpcion(3);
        }

        private void lineasToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SeleccionarOpcion(4);
        }

        private void marcasToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            SeleccionarOpcion(5); 
        }
        
        private void tostMenu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            int Seleccion = tostMenu.Items.IndexOf(e.ClickedItem);
            SeleccionarOpcion(Seleccion);
        }

        private void cambioClaveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ControlMantenimiento_NetDesktop.FormCambioClave Form_CambioClave = new ControlMantenimiento_NetDesktop.FormCambioClave();
            Form_CambioClave.ShowDialog(this);
        }

        private void SeleccionarOpcion(int Opcion)
        {
            switch (Opcion)
            {
                case 0:
                       ControlMantenimiento_NetDesktop.FormOperarios Form_Operarios = new ControlMantenimiento_NetDesktop.FormOperarios();
                       Form_Operarios.ShowDialog(this);
                       break;
                case 1:
                       ControlMantenimiento_NetDesktop.FormEquipos Form_Equipos = new ControlMantenimiento_NetDesktop.FormEquipos();
                       Form_Equipos.ShowDialog(this);                                             
                       break;                
                case 2:
                       ControlMantenimiento_NetDesktop.FormMantenimiento Form_Mantenimiento = new ControlMantenimiento_NetDesktop.FormMantenimiento();
                       Funciones.Fuente = "CPROGRAMAREQUIPOS";
                       Form_Mantenimiento.ShowDialog(this);
                                             
                       break;
                case 3:
                       ControlMantenimiento_NetDesktop.FormMantenimiento Form_Mantenimientoo = new ControlMantenimiento_NetDesktop.FormMantenimiento();
                       Funciones.Fuente = "CPROGRAMACION";
                       Form_Mantenimientoo.ShowDialog(this);                       
                       break;
                case 4:
                        Funciones.ValorTipo = "LINEAS";
                        ControlMantenimiento_NetDesktop.FormListaValores Form_ListaValores = new ControlMantenimiento_NetDesktop.FormListaValores();
                        Form_ListaValores.ShowDialog(this);
                        break;
                case 5:
                        Funciones.ValorTipo = "MARCAS";
                        ControlMantenimiento_NetDesktop.FormListaValores Form_ListaValoress = new ControlMantenimiento_NetDesktop.FormListaValores();
                        Form_ListaValoress.ShowDialog(this);
                        break;
            }
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }       
    }
}
