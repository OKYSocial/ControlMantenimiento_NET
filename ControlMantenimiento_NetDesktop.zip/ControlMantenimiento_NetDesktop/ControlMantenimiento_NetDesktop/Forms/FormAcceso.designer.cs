﻿namespace ControlMantenimiento_NetDesktop
{
    partial class FormAcceso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAcceso));
            this.panel1 = new System.Windows.Forms.Panel();
            this.ButtonSalir = new System.Windows.Forms.Button();
            this.ButtonAyuda = new System.Windows.Forms.Button();
            this.ButtonCancelar = new System.Windows.Forms.Button();
            this.ButtonIngresar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.TextBoxClave = new System.Windows.Forms.TextBox();
            this.TextBoxDocumento = new System.Windows.Forms.TextBox();
            this.errorPro = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.ButtonSalir);
            this.panel1.Controls.Add(this.ButtonAyuda);
            this.panel1.Controls.Add(this.ButtonCancelar);
            this.panel1.Controls.Add(this.ButtonIngresar);
            this.panel1.Location = new System.Drawing.Point(-1, 123);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(369, 60);
            this.panel1.TabIndex = 286;
            // 
            // ButtonSalir
            // 
            this.ButtonSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.ButtonSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSalir.ForeColor = System.Drawing.Color.Black;
            this.ButtonSalir.Image = ((System.Drawing.Image)(resources.GetObject("ButtonSalir.Image")));
            this.ButtonSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonSalir.Location = new System.Drawing.Point(238, 16);
            this.ButtonSalir.Name = "ButtonSalir";
            this.ButtonSalir.Size = new System.Drawing.Size(60, 35);
            this.ButtonSalir.TabIndex = 5;
            this.ButtonSalir.TabStop = false;
            this.ButtonSalir.Text = "Salir";
            this.ButtonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonSalir.UseVisualStyleBackColor = false;
            this.ButtonSalir.Click += new System.EventHandler(this.ButtonSalir_Click);
            // 
            // ButtonAyuda
            // 
            this.ButtonAyuda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonAyuda.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonAyuda.ForeColor = System.Drawing.Color.Black;
            this.ButtonAyuda.Image = ((System.Drawing.Image)(resources.GetObject("ButtonAyuda.Image")));
            this.ButtonAyuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonAyuda.Location = new System.Drawing.Point(181, 16);
            this.ButtonAyuda.Name = "ButtonAyuda";
            this.ButtonAyuda.Size = new System.Drawing.Size(60, 35);
            this.ButtonAyuda.TabIndex = 4;
            this.ButtonAyuda.TabStop = false;
            this.ButtonAyuda.Text = "Ayuda";
            this.ButtonAyuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonAyuda.UseVisualStyleBackColor = false;
            this.ButtonAyuda.Click += new System.EventHandler(this.ButtonAyuda_Click);
            // 
            // ButtonCancelar
            // 
            this.ButtonCancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCancelar.ForeColor = System.Drawing.Color.Black;
            this.ButtonCancelar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonCancelar.Image")));
            this.ButtonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonCancelar.Location = new System.Drawing.Point(129, 16);
            this.ButtonCancelar.Name = "ButtonCancelar";
            this.ButtonCancelar.Size = new System.Drawing.Size(60, 35);
            this.ButtonCancelar.TabIndex = 3;
            this.ButtonCancelar.TabStop = false;
            this.ButtonCancelar.Text = "Cancelar";
            this.ButtonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonCancelar.UseVisualStyleBackColor = false;
            this.ButtonCancelar.Click += new System.EventHandler(this.ButtonCancelar_Click);
            // 
            // ButtonIngresar
            // 
            this.ButtonIngresar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonIngresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonIngresar.ForeColor = System.Drawing.Color.Black;
            this.ButtonIngresar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonIngresar.Image")));
            this.ButtonIngresar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonIngresar.Location = new System.Drawing.Point(75, 16);
            this.ButtonIngresar.Name = "ButtonIngresar";
            this.ButtonIngresar.Size = new System.Drawing.Size(60, 35);
            this.ButtonIngresar.TabIndex = 2;
            this.ButtonIngresar.TabStop = false;
            this.ButtonIngresar.Text = "Ingresar";
            this.ButtonIngresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonIngresar.UseVisualStyleBackColor = false;
            this.ButtonIngresar.Click += new System.EventHandler(this.ButtonIngresar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(81, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 337;
            this.label1.Text = "Usuario";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(83, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 340;
            this.label4.Text = "Clave";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.TextBoxClave);
            this.panel2.Controls.Add(this.TextBoxDocumento);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(24, 20);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(369, 185);
            this.panel2.TabIndex = 287;
            // 
            // TextBoxClave
            // 
            this.TextBoxClave.Location = new System.Drawing.Point(156, 72);
            this.TextBoxClave.MaxLength = 20;
            this.TextBoxClave.Name = "TextBoxClave";
            this.TextBoxClave.PasswordChar = '*';
            this.TextBoxClave.Size = new System.Drawing.Size(129, 20);
            this.TextBoxClave.TabIndex = 1;
            this.TextBoxClave.TabStop = false;
            // 
            // TextBoxDocumento
            // 
            this.TextBoxDocumento.Location = new System.Drawing.Point(156, 24);
            this.TextBoxDocumento.MaxLength = 10;
            this.TextBoxDocumento.Name = "TextBoxDocumento";
            this.TextBoxDocumento.Size = new System.Drawing.Size(72, 20);
            this.TextBoxDocumento.TabIndex = 0;
            this.TextBoxDocumento.TabStop = false;
            // 
            // errorPro
            // 
            this.errorPro.ContainerControl = this;
            // 
            // FormAcceso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(421, 225);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FormAcceso";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Acceso SIMI";
           
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button ButtonCancelar;
        private System.Windows.Forms.Button ButtonSalir;
        private System.Windows.Forms.Button ButtonAyuda;
        private System.Windows.Forms.Button ButtonIngresar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ErrorProvider errorPro;
        private System.Windows.Forms.TextBox TextBoxClave;
        private System.Windows.Forms.TextBox TextBoxDocumento;
    }
}