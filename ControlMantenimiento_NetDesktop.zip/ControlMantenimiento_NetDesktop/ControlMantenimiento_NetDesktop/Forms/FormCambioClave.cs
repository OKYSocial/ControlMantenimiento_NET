﻿using System;
using System.Windows.Forms;
using ControlMantenimiento_NetDesktop.BLL;

namespace ControlMantenimiento_NetDesktop
{
    public partial class FormCambioClave : Form
    {
        public FormCambioClave()
        {
            InitializeComponent();
            this.TextBoxClave.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxClave_KeyPress);
            this.TextBoxClaveNueva.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxClaveNueva_KeyPress);
            this.TextBoxConfirmar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxConfirmar_KeyPress);
        }

        private Controlador _controlador = Funciones.CrearControlador();
        private bool Grabar;
        private KeyPressEventArgs Tecla = new KeyPressEventArgs('\r'); // Send Enter

        private void FormCambioClave_Load(object sender, EventArgs e)
        {                
        }

        private void TextBoxClave_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.Validar_CampoVacio(TextBoxClave.Text))
                {
                    Grabar = false;
                    MessageBox.Show(BLL.Mensajes.MensajeCampoRequerido, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxClave.Focus();
                    errorPro.SetError(TextBoxClave, BLL.Mensajes.MensajeCampoRequerido);
                }                
                else
                {
                    TextBoxClaveNueva.Focus();
                }
            }
        }

        private void TextBoxClaveNueva_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.Validar_CampoVacio(TextBoxClaveNueva.Text))
                {
                    Grabar = false;
                    MessageBox.Show(BLL.Mensajes.MensajeCampoRequerido, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxClaveNueva.Focus();
                    errorPro.SetError(TextBoxClaveNueva, BLL.Mensajes.MensajeCampoRequerido);
                }
                else if (TextBoxClaveNueva.Text == TextBoxClave.Text) // Clave Nueva debe ser diferente de la actual
                {
                    Grabar = false;
                    MessageBox.Show(BLL.Mensajes.Mensaje4, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxClaveNueva.Focus();
                    errorPro.SetError(TextBoxClaveNueva, BLL.Mensajes.Mensaje4);
                }
                else if (TextBoxClaveNueva.Text.Length < 6)
                {
                    Grabar = false;
                    MessageBox.Show(BLL.Mensajes.Mensaje21, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxClaveNueva.Focus();
                    errorPro.SetError(TextBoxClaveNueva, BLL.Mensajes.Mensaje21);
                }
                else
                {
                    errorPro.Clear();
                    TextBoxConfirmar.Focus();
                }
            }
        }

        private void TextBoxConfirmar_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.Validar_CampoVacio(TextBoxConfirmar.Text))
                {
                    Grabar = false;
                    MessageBox.Show(BLL.Mensajes.MensajeCampoRequerido, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxConfirmar.Focus();
                    errorPro.SetError(TextBoxConfirmar, BLL.Mensajes.MensajeCampoRequerido);
                }
                else if (TextBoxConfirmar.Text != TextBoxClaveNueva.Text) // Debe confirmar la clave y debe ser igual a Clave Nueva
                {
                    Grabar = false;
                    MessageBox.Show(BLL.Mensajes.Mensaje5, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxConfirmar.Focus();
                    errorPro.SetError(TextBoxConfirmar, BLL.Mensajes.Mensaje5);
                }
                else
                {
                    errorPro.Clear();
                    ButtonGrabar.Focus();
                }
            }
        }

        private void ButtonGrabar_Click(object sender, EventArgs e)
        {
            Grabar = true;
            TextBoxClave_KeyPress(ButtonGrabar, Tecla);
            if (Grabar)
            {
                TextBoxClaveNueva_KeyPress(ButtonGrabar, Tecla);
                if (Grabar)
                {
                    TextBoxConfirmar_KeyPress(ButtonGrabar, Tecla);
                    if (Grabar)
                    {
                        Guardar();
                    }
                }
            }
        }

        private void Guardar()
        {
            int Resultado = _controlador.GuardarCambioClave(TextBoxClave.Text.Trim(), TextBoxClaveNueva.Text.Trim());
            if (Resultado == 0)
            {
                MessageBox.Show(BLL.Mensajes.MensajeActualiza, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (Resultado == 1)
            {
                MessageBox.Show(BLL.Mensajes.Mensaje3, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {                
                MessageBox.Show(BLL.Mensajes.MensajeErrorBD, BLL.Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }            
            ButtonSalir.PerformClick(); 
        }
                     
        private void ButtonCancelar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void Limpiar()
        {
            BLL.Funciones.LimpiarForma(panel2);
            errorPro.Clear();
            TextBoxClave.Focus();
        }
              
        private void ButtonSalir_Click(object sender, EventArgs e)
        {
            _controlador = null;
            this.Close();
            this.Dispose();
        }

        

        
    }
}
