﻿// Este es el Controlador Manager general de todo el sistema. Todo tiene que pasar por esta clase
using System;
using ControlMantenimiento_NetDesktop.DAL;
using System.Collections;
using ControlMantenimiento_NetDesktop.BO;

namespace ControlMantenimiento_NetDesktop.BLL
{
    public class Controlador 
    {
        private readonly IAccesoDatos _accesoDatos;
        
        public Controlador(IAccesoDatos accesoDatos)
        {
            _accesoDatos = accesoDatos;            
        }

        public ArrayList CargarListas(string Tabla)
        {
            return _accesoDatos.CargarListas(Tabla);
        }
        
        public ArrayList ControlProgramacion(string Tabla)
        {
            return _accesoDatos.ControlProgramacion(Tabla);
        }
        
        // Obtener Registro
        public Operario ObtenerAcceso(string DatoBuscar, string Clave)
        {
            Operario operario = null;
            operario = _accesoDatos.ObtenerAcceso(DatoBuscar, Clave);
            return operario;
        }

        public Object ObtenerRegistro(string DatoBuscar, string Tabla)
        {
            Object objeto = null;
            switch (Tabla)
            {
                case "OPERARIOS":
                    objeto = _accesoDatos.ObtenerOperario(DatoBuscar);
                    break;
                case "EQUIPOS":
                    objeto = _accesoDatos.ObtenerEquipo(DatoBuscar);
                    break;
                case "MANTENIMIENTO":
                    objeto = _accesoDatos.ObtenerMantenimiento(DatoBuscar);
                    break;
                case "LISTAVALORES":
                    objeto = _accesoDatos.ObtenerListaValores(DatoBuscar);
                    break;
            }
            return objeto;
        }


        // Grabar en BD
        public int GuardarOperario(Operario operario, string Accion)
        {
           return _accesoDatos.GuardarOperario(operario, Accion, Funciones.UsuarioConectado);
        }

        public int GuardarEquipo(Equipo equipo)
        {
           return _accesoDatos.GuardarEquipo(equipo, Funciones.UsuarioConectado);
        }

        public int GuardarListaValores(ListaValores listavalores)
        {
            return _accesoDatos.GuardarListaValores(listavalores, Funciones.UsuarioConectado);
        }

        public int GuardarMantenimiento(Mantenimiento mantenimiento, string Accion)
        {
            return _accesoDatos.GuardarMantenimiento(mantenimiento, Accion, Funciones.UsuarioConectado);
        }
        
        public int GuardarCambioClave(string ClaveAnterior, string ClaveNueva)
        {
            return _accesoDatos.GuardarCambioClave(Funciones.UsuarioConectado, ClaveAnterior, ClaveNueva);
        }

        // Eliminar Registro
        public int EliminarRegistro(string DatoEliminar, string Tabla)
        {
            return _accesoDatos.EliminarRegistro(DatoEliminar, Tabla);
        }                       

    }
}
