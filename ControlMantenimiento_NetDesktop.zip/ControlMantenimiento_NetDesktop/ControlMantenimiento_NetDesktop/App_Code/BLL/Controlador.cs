﻿// Este es el Controlador Manager general de todo el sistema. Todo tiene que pasar por esta clase
using System;
using ControlMantenimiento_NetDesktop.DAL;
using System.Collections;
using ControlMantenimiento_NetDesktop.BO;

namespace ControlMantenimiento_NetDesktop.BLL
{
    public class Controlador 
    {
        private readonly IAccesoDatos _accesoDatos;
        
        public Controlador(IAccesoDatos accesoDatos)
        {
            _accesoDatos = accesoDatos;            
        }

        #region IControlador Members


        public ArrayList CargarListas(string Tabla)
        {
            return _accesoDatos.CargarListas(Tabla);
        }
        
        public ArrayList ControlProgramacion(string Tabla)
        {
            return _accesoDatos.ControlProgramacion(Tabla);
        }
        
        // Obtener Registro
        public Operario ObtenerAcceso(string DatoBuscar, string Clave)
        {
            Operario operario = null;
            operario = _accesoDatos.ObtenerAcceso(DatoBuscar, Clave);
            return operario;
        }

        public Object ObtenerRegistro(string DatoBuscar, string Tabla)
        {
            Object objeto = null;
            switch (Tabla)
            {
                case "OPERARIOS":
                    objeto = _accesoDatos.ObtenerOperario(DatoBuscar);
                    break;
                case "EQUIPOS":
                    objeto = _accesoDatos.ObtenerEquipo(DatoBuscar);
                    break;
                case "MANTENIMIENTO":
                    objeto = _accesoDatos.ObtenerMantenimiento(DatoBuscar);
                    break;
                case "LISTAVALORES":
                    objeto = _accesoDatos.ObtenerListaValores(DatoBuscar);
                    break;
            }
            return objeto;
        }


        // Grabar en BD
        public int Guardar(object o, string Accion)
        {
            int status = 0;
            if (o is Operario)
            {
                Operario operario = (Operario)o;
                status = _accesoDatos.GuardarOperario(operario, Accion, Funciones.UsuarioConectado);
            }
            else if (o is Mantenimiento)
            {
                Mantenimiento mantenimiento = (Mantenimiento)o;
                status = _accesoDatos.GuardarMantenimiento(mantenimiento, Accion, Funciones.UsuarioConectado);
            }
            else if (o is Equipo)
            {
                Equipo equipo = (Equipo)o;
                status = _accesoDatos.GuardarEquipo(equipo, Funciones.UsuarioConectado);
            }
            else if (o is ListaValores)
            {
                ListaValores listavalores = (ListaValores)o;
                status = _accesoDatos.GuardarListaValores(listavalores, Funciones.UsuarioConectado);
            }

            return status;
        }

        public int GuardarCambioClave(string ClaveAnterior, string ClaveNueva)
        {
            return _accesoDatos.GuardarCambioClave(Funciones.UsuarioConectado, ClaveAnterior, ClaveNueva);
        }

        // Eliminar Registro
        public int EliminarRegistro(string DatoEliminar, string Tabla)
        {
            return _accesoDatos.EliminarRegistro(DatoEliminar, Tabla);
        }


        #endregion

    }
}
