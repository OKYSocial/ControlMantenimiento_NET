﻿// Esta es una clase transversal, desde donde se instancia el Factory Method y hay algunas validaciones

using System;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using ControlMantenimiento_NetDesktop.BO;
using ControlMantenimiento_NetDesktop.DAL;

namespace ControlMantenimiento_NetDesktop.BLL
{
    class Funciones
    {
        public static string ValorTipo;        // Variable para controlar Tipo en Lista de Valores (Lineas o Marcas)
        public static string Fuente;
        public static int PerfilAcceso;
        public static string NombreUsuario;
        public static string UsuarioConectado;
        private static AccesoDatos accesoDatos;

        public static Controlador CrearControlador()
        {
            accesoDatos = (AccesoDatos)AccesoDatosFactory.GetAccesoDatos();
            return new Controlador(accesoDatos);
        }        

        // Funcion para validar campos de frmulario vacios 
        public static bool Validar_CampoVacio(string Cadena)
        {
            bool Vacio = false;
            Cadena = Cadena.Trim();
            if (string.IsNullOrEmpty(Cadena))
            {
                Vacio = true;
            }
            return Vacio;
        }

        // Funcion para validar direcciones de correo electronico
        public static bool Validar_Correo(string Cadena)
        {
            Cadena = Cadena.Trim();
            return !Regex.IsMatch(Cadena, "\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*");         
        }

        // Funcion para comprobar existencia de caracteres no numericos
        public static bool Validar_SoloNumeros(string Cadena)
        {
            bool status = false;
            for (int i = 0; i < Cadena.Length; i++)
            {
                if (!Char.IsNumber(Cadena[i]))
                {
                    status = true;
                    break;
                }
            }
            return status;
        }

        // Funcion para comprobar existencia de caracteres diferentes de letras
        public static bool Validar_SoloLetras(string Cadena)
        {
            bool Resultado = false;
            for (int i = 0; i < Cadena.Length; i++)
            {
                if (Char.IsNumber(Cadena[i]))
                {
                    Resultado = true;
                    break;
                }
            }
            return Resultado;
        }

        // Funcion para limpiar los controles en un frmulario (Solo TextBox)
        public static void LimpiarForma(Panel pnl)
        {
            foreach (Control oControls in pnl.Controls)
            {
                if (oControls is TextBox)
                {
                    oControls.Text = ""; 
                }
            }
        }

        // Funcion para eliminar posibles espacios de tabulacion en un campo de texto
        public static string EliminarTabulador(string Cadena, string Conversion)
        {
            Cadena = Cadena.Trim();
            while (Cadena.IndexOf("  ", 0) != -1)
            {
                Cadena = (Cadena.Replace("  ", " "));
            }
            if (Conversion == "MAY")
            {
                Cadena = Cadena.ToUpper();
            }
            else if (Conversion == "1MAY") // Organizar primera letra en Mayuscula y siguientes en Minuscula
            {
                Cadena = Cadena.ToLower();
                Cadena = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(Cadena);
            }
            return Cadena;
        }
        
        // Default Constructor
        public Funciones()
        { }
    }
}
