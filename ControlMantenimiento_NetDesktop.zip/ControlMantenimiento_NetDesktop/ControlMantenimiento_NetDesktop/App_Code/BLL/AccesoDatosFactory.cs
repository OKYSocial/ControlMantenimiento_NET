﻿using ControlMantenimiento_NetDesktop.DAL; // Patron de Creacion: Factory Method


namespace ControlMantenimiento_NetDesktop.BLL
{
    public static class AccesoDatosFactory
    {
        public static IAccesoDatos GetAccesoDatos()
        {
            return new AccesoDatos();
        }
    }
}
