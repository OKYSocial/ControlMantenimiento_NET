﻿using System;

namespace ControlMantenimiento_NetDesktop.BO
{
    public class Mantenimiento // Clase que representa la estructura en BD para Mantenimiento
    {

        // Default Constructor
        public Mantenimiento() { }
           
        public int CodigoEquipo { get; set; }

        public double Documento { get; set; }

        public DateTime Fecha { get; set; }

        public string Observaciones { get; set; }
    }
}

 
