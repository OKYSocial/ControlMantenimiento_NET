﻿using System;

namespace ControlMantenimiento_NetDesktop.BO
{
    public class Mantenimiento // Clase que representa la estructura en BD para Mantenimiento
    {

        // Default Constructor
        public Mantenimiento() { }

        public int Mantenimiento_id { get; set; }
           
        public int Equipo_id { get; set; }

        public double Operario_id { get; set; }

        public DateTime Fecha { get; set; }

        public string Observaciones { get; set; }
    }
}

 
