﻿namespace ControlMantenimiento_NetDesktop.BO
{
    public class Operario // Clase que representa la estructura en BD Operarios
    {
        private string Documento;
        private string Nombres;
        private string Apellidos;
        private string Correo;
        private string Telefono;
        private string Clave;
        private int Perfil;
        private string Foto;

        // Default Constructor
        public Operario() { }

        public string documento
        {
            get { return Documento; }
            set { Documento = value; }
        }
        public string nombres
        {
            get { return Nombres; }
            set { Nombres = value; }
        }
        public string apellidos
        {
            get { return Apellidos; }
            set { Apellidos = value; }
        }
        public string correo
        {
            get { return Correo; }
            set { Correo = value; }
        }
        public string telefono
        {
            get { return Telefono; }
            set { Telefono = value; }
        }
        public string clave
        {
            get { return Clave; }
            set { Clave = value; }
        }
        public int perfil
        {
            get { return Perfil; }
            set { Perfil = value; }
        }
        public string foto
        {
            get { return Foto; }
            set { Foto = value; }
        }
       
    }
}
