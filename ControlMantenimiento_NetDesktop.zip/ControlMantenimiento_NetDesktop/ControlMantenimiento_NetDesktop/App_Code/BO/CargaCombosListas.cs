﻿// Clase que nos permite cargar Pares de clave y valor para los ComboBox y ListBox
namespace ControlMantenimiento_NetDesktop.BO
{
    public class CargaCombosListas
    {
       public string Codigo { get; set; }

       public string Detalle { get; set; }

       public CargaCombosListas() { }

       public CargaCombosListas(string Codigo, string Detalle)
       {
            this.Codigo  = Codigo;
            this.Detalle = Detalle;
       }
    }  
}
