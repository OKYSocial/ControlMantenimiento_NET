﻿namespace ControlMantenimiento_NetDesktop.BO
{
    public class ListaValores // Clase que representa la estructura en BD para ListaValores
    {
        // Default Constructor
        public ListaValores() { }

        public int Codigo { get; set; }

        public string Nombre { get; set; }

        public string Descripcion { get; set; }

        public string Tipo { get; set; }       

    }

}

