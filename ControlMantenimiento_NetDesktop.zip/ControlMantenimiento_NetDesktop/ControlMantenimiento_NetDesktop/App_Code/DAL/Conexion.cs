﻿// Clase que nos devuelve la conexion con el proveedor que se desee
namespace ControlMantenimiento_NetDesktop.DAL
{
    public class Conexion
    {
        public static string ObtenerConexion
        {
            get
            {
               return System.Configuration.ConfigurationManager.ConnectionStrings["Conexion"].ToString();
            }
        }
    }
}
