﻿// Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   

using System.Collections;
using ControlMantenimiento_NetDesktop.BO;

namespace ControlMantenimiento_NetDesktop.DAL
{
    public interface IAccesoDatos
    {
        Operario ObtenerAcceso(string datoBuscar, string clave);
        Operario ObtenerOperario(string datoBuscar);
        ListaValores ObtenerListaValores(string datoBuscar);
        Equipo ObtenerEquipo(string datoBuscar);
        Mantenimiento ObtenerMantenimiento(string datoBuscar);

        int GuardarOperario(Operario operario, string accion, string Usuario);
        int GuardarCambioClave(string Documento, string ClaveAnterior, string ClaveNueva);
        int GuardarListaValores(ListaValores listavalores, string Usuario);        
        int GuardarEquipo(Equipo equipo, string Usuario);
        int GuardarMantenimiento(Mantenimiento mantenimiento, string accion, string Usuario);

        ArrayList CargarListas(string Tabla);
        ArrayList ControlProgramacion(string Tabla);        
        int EliminarRegistro(string datoEliminar, string tabla);
    }
}
