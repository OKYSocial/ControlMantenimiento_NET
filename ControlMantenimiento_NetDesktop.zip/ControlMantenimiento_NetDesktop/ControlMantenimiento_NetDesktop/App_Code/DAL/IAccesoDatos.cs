﻿// Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   

using System.Collections;
using ControlMantenimiento_NetDesktop.BO;

namespace ControlMantenimiento_NetDesktop.DAL
{
    public interface IAccesoDatos
    {
        Operario ObtenerAcceso(string Documento, string Clave);
        Operario ObtenerOperario(int DatoBuscar);
        ListaValores ObtenerListaValores(int DatoBuscar);
        Equipo ObtenerEquipo(int DatoBuscar);
        Mantenimiento ObtenerMantenimiento(int DatoBuscar);

        int GuardarOperario(Operario operario, int Usuario);
        int GuardarCambioClave(int Usuario, string ClaveAnterior, string ClaveNueva);
        int GuardarListaValores(ListaValores listavalores, int Usuario);        
        int GuardarEquipo(Equipo equipo, int Usuario);
        int GuardarMantenimiento(Mantenimiento mantenimiento, int Usuario);

        ArrayList CargarListas(string Tabla);
        ArrayList ControlProgramacion(string Tabla);        
        int EliminarRegistro(int DatoEliminar, string Tabla);
    }
}
