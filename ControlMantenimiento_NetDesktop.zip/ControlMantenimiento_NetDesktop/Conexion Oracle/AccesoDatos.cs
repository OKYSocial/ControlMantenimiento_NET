﻿/*=================================================================================================================
  Bien como se puede apreciar no se disparan Querys desde la aplicación, todo se realiza en el lado del servidor,
  lo que se traduce en mayor eficiencia y velocidad en tiempo de respuesta. Todo lo que tiene que ver con acceso
  a datos está centralizado en este módulo, que bien podría separarse aún más si se quisiera, diseñando un módulo
  DAL para cada una de las estructuras de la BD, pero para este caso se puede dejar así y funciona bastante bien
 =================================================================================================================*/

using System;
using Oracle.ManagedDataAccess.Client;
using System.Data;
using System.Collections;
using ControlMantenimiento_NetDesktop.BO;

namespace ControlMantenimiento_NetDesktop.DAL
{
    public class AccesoDatos : IAccesoDatos
    {
        // Default Constructor
        public AccesoDatos() { }


        private OracleConnection Cn;
        private OracleDataReader sdr;
        private OracleCommand Cmd;

        private void BuscarRegistro(string Tabla, string DatoBuscar, string Condicion)
        {
            try
            {
                Cn = new OracleConnection(Conexion.obtenerConexion);
                Cmd = new OracleCommand("spr_CBuscarRegistro", Cn);
                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Parameters.Add("p_TABLA", OracleDbType.Varchar2, 20).Value = Tabla;
                Cmd.Parameters.Add("p_DATOBUSCAR", OracleDbType.Varchar2, 50).Value = DatoBuscar;
                Cmd.Parameters.Add("p_CONDICION", OracleDbType.Varchar2, 50).Value = Condicion;
                Cmd.Parameters.Add("Out_Data", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                Cn.Open();
		sdr = Cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public ArrayList CargarListas(string Tabla)
        {
            try
            {
                ArrayList arlLista = new ArrayList();
                using (OracleConnection Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("spr_CCargarCombosListas", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", OracleDbType.Varchar2, 30).Value = Tabla;
                    Cmd.Parameters.Add("Out_Data", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    Cn.Open();
                    sdr = Cmd.ExecuteReader();
                    while (sdr.Read())
                    {
                        arlLista.Add(new CargaCombosListas(sdr.GetValue(0).ToString(), sdr.GetValue(0).ToString() + " " + sdr.GetValue(1).ToString()));
                    }
                    sdr.Close();
                    LiberarRecursos();
                    return arlLista;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public ArrayList ControlProgramacion(string Tabla)
        {
            try
            {
                ArrayList arlListControlProgramacion = new ArrayList();
                using (OracleConnection Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("spr_CCargarCombosListas", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", OracleDbType.Varchar2, 30).Value = Tabla;
                    Cmd.Parameters.Add("Out_Data", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    Cn.Open();
                    sdr = Cmd.ExecuteReader();
                    while (sdr.Read())
                    {
                        arlListControlProgramacion.Add(sdr.GetValue(2).ToString());
                        arlListControlProgramacion.Add(sdr.GetValue(0).ToString());
                        arlListControlProgramacion.Add(sdr.GetValue(1).ToString());
                    }
                    sdr.Close();
                    LiberarRecursos();
                    return arlListControlProgramacion;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /*
         =======================================================================================================================================================
         Inicio Operaciones sobre estructura Operarios
         =======================================================================================================================================================
         */

        public Operario ObtenerAcceso(string DatoBuscar, string Clave)
        {
            Operario operario = new Operario();
            try
            {
                BuscarRegistro("OPERARIOS", DatoBuscar, Clave);
                if (sdr.Read())
                {                   
                    operario.documento = sdr["DOCUMENTO"].ToString();
                    operario.nombres = sdr["NOMBRES"].ToString();
                    operario.apellidos = sdr["APELLIDOS"].ToString();                    
                    operario.perfil = Convert.ToInt32(sdr["PERFIL"].ToString());                   
                    sdr.Close();
                    LiberarRecursos();
                    return operario;
                }
                else
                {
                    sdr.Close();
                    LiberarRecursos();
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Operario ObtenerOperario(string DatoBuscar)
        {
            Operario operario = new Operario();
            try
            {
                BuscarRegistro("OPERARIOS", DatoBuscar, "");
                if (sdr.Read())
                {
                    operario.documento = sdr["DOCUMENTO"].ToString();
                    operario.nombres = sdr["NOMBRES"].ToString();
                    operario.apellidos = sdr["APELLIDOS"].ToString();
                    operario.correo = sdr["CORREO"].ToString();
                    operario.telefono = sdr["TELEFONO"].ToString();
                    operario.foto = sdr["FOTO"].ToString();
                    sdr.Close();
                    LiberarRecursos();
                    return operario;
                }
                else
                {
                    sdr.Close();
                    LiberarRecursos();
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int GuardarOperario(Operario operario, string Accion, string Usuario)
        {
            try
            {
                using (OracleConnection Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("spr_IUOperarios", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_ACCION", OracleDbType.Varchar2, 1).Value = Accion;
                    Cmd.Parameters.Add("p_DOCUMENTO", OracleDbType.Int32, 10).Value = operario.documento;
                    Cmd.Parameters.Add("p_NOMBRES", OracleDbType.Varchar2, 25).Value = operario.nombres;
                    Cmd.Parameters.Add("p_APELLIDOS", OracleDbType.Varchar2, 25).Value = operario.apellidos;
                    Cmd.Parameters.Add("p_CORREO", OracleDbType.Varchar2, 50).Value = operario.correo;
                    Cmd.Parameters.Add("p_TELEFONO", OracleDbType.Int32, 10).Value = operario.telefono;
                    Cmd.Parameters.Add("p_CLAVE", OracleDbType.Varchar2, 20).Value = operario.clave;
                    Cmd.Parameters.Add("p_PERFIL", OracleDbType.Int32, 1).Value = operario.perfil;
                    Cmd.Parameters.Add("p_FOTO", OracleDbType.Varchar2, 50).Value = operario.foto;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", OracleDbType.Int32, 10).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", OracleDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Int32 Resultado = (Int32)(Oracle.ManagedDataAccess.Types.OracleDecimal)Cmd.Parameters["p_RESULTADO"].Value;
                    LiberarRecursos();
                    return Resultado;
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        public int GuardarCambioClave(string Documento, string ClaveAnterior, string ClaveNueva)
        {
            try
            {
                using (OracleConnection Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("spr_UCambioClave", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_DOCUMENTO", OracleDbType.Int32, 10).Value = Documento;
                    Cmd.Parameters.Add("p_CLAVE_ANTERIOR", OracleDbType.Varchar2, 20).Value = ClaveAnterior;
                    Cmd.Parameters.Add("p_CLAVE_NUEVA", OracleDbType.Varchar2, 20).Value = ClaveNueva;
                    Cmd.Parameters.Add("p_RESULTADO", OracleDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Int32 Resultado = (Int32)(Oracle.ManagedDataAccess.Types.OracleDecimal)Cmd.Parameters["p_RESULTADO"].Value;
                    LiberarRecursos();
                    return Resultado;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /*
         =======================================================================================================================================================
         Fin Operaciones sobre estructura Operarios
         =======================================================================================================================================================
         */

        /*
        =======================================================================================================================================================
        Inicio Operaciones sobre estructura ListaValores
        =======================================================================================================================================================
        */
        public ListaValores ObtenerListaValores(string DatoBuscar)
        {
            ListaValores listavalores = new ListaValores();
            try
            {

                BuscarRegistro("LISTAVALORES", DatoBuscar, "");
                if (sdr.Read())
                {
                    listavalores.codigo = Convert.ToInt32(sdr["CODIGO"].ToString());
                    listavalores.nombre = sdr["NOMBRE"].ToString();
                    listavalores.descripcion = sdr["DESCRIPCION"].ToString();
                    sdr.Close();
                    LiberarRecursos();
                    return listavalores;
                }
                else
                {
                    sdr.Close();
                    LiberarRecursos();
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int GuardarListaValores(ListaValores listavalores, string Usuario)
        {
            try
            {
                using (OracleConnection Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("spr_IUListaValores", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_CODIGO", OracleDbType.Int32, 10).Value = listavalores.codigo;
                    Cmd.Parameters.Add("p_NOMBRE", OracleDbType.Varchar2, 50).Value = listavalores.nombre;
                    Cmd.Parameters.Add("p_DESCRIPCION", OracleDbType.Varchar2, 255).Value = listavalores.descripcion;
                    Cmd.Parameters.Add("p_TIPO", OracleDbType.Varchar2, 50).Value = listavalores.tipo;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", OracleDbType.Int32, 10).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", OracleDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Int32 Resultado = (Int32)(Oracle.ManagedDataAccess.Types.OracleDecimal)Cmd.Parameters["p_RESULTADO"].Value;
                    LiberarRecursos();
                    return Resultado;
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }
        /*
        =======================================================================================================================================================
        Fin Operaciones sobre estructura ListaValores
        =======================================================================================================================================================
        */

        /*
        =======================================================================================================================================================
        Inicio Operaciones sobre estructura Equipos
        =======================================================================================================================================================
        */
        public Equipo ObtenerEquipo(string DatoBuscar)
        {
            ControlMantenimiento_NetDesktop.BO.Equipo equipo = new Equipo();
            try
            {
                BuscarRegistro("EQUIPOS", DatoBuscar, "Codigo");
                if (sdr.Read())
                {
                    equipo.codigoequipo = Convert.ToInt32(sdr["CODIGOEQUIPO"].ToString());
                    equipo.nombreequipo = sdr["NOMBREEQUIPO"].ToString();
                    equipo.codigomarca = Convert.ToInt32(sdr["CODIGOMARCA"].ToString());
                    equipo.serie = sdr["SERIE"].ToString();
                    equipo.codigolinea = Convert.ToInt32(sdr["CODIGOLINEA"].ToString());
                    equipo.lubricacion = Convert.ToInt32(sdr["LUBRICACION"].ToString());
                    sdr.Close();
                    LiberarRecursos();
                    return equipo;
                }
                else
                {
                    sdr.Close();
                    LiberarRecursos();
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int GuardarEquipo(Equipo equipo, string Usuario)
        {
            try
            {
                using (OracleConnection Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("spr_IUEquipos", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_CODIGOEQUIPO", OracleDbType.Int32, 10).Value = equipo.codigoequipo;
                    Cmd.Parameters.Add("p_NOMBREEQUIPO", OracleDbType.Varchar2, 50).Value = equipo.nombreequipo;
                    Cmd.Parameters.Add("p_CODIGOMARCA", OracleDbType.Int32, 10).Value = equipo.codigomarca;
                    Cmd.Parameters.Add("p_SERIE", OracleDbType.Varchar2, 20).Value = equipo.serie;
                    Cmd.Parameters.Add("p_CODIGOLINEA", OracleDbType.Int32, 10).Value = equipo.codigolinea;
                    Cmd.Parameters.Add("p_LUBRICACION", OracleDbType.Int32, 1).Value = equipo.lubricacion;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", OracleDbType.Int32, 10).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", OracleDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Int32 Resultado = (Int32)(Oracle.ManagedDataAccess.Types.OracleDecimal)Cmd.Parameters["p_RESULTADO"].Value;
                    LiberarRecursos();
                    return Resultado;
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /*
       =======================================================================================================================================================
       Fin Operaciones sobre estructura Equipos
       =======================================================================================================================================================
       */

        /*
       =======================================================================================================================================================
       Inicio Operaciones sobre estructura Mantenimiento
       =======================================================================================================================================================
       */
        public Mantenimiento ObtenerMantenimiento(string DatoBuscar)
        {
            Mantenimiento mantenimiento = new Mantenimiento();
            try
            {
                BuscarRegistro("MANTENIMIENTO", DatoBuscar, "");
                if (sdr.Read())
                {
                    mantenimiento.codigoequipo = Convert.ToInt32(sdr["CODIGOEQUIPO"].ToString());
                    mantenimiento.documento = Convert.ToDouble(sdr["DOCUMENTO"].ToString());
                    mantenimiento.fecha = Convert.ToDateTime(sdr["FECHA"].ToString());
                    mantenimiento.observaciones = sdr["OBSERVACIONES"].ToString();
                    sdr.Close();
                    LiberarRecursos();
                    return mantenimiento;
                }
                else
                {
                    sdr.Close();
                    LiberarRecursos();
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int GuardarMantenimiento(Mantenimiento mantenimiento, string Accion, string Usuario)
        {
            try
            {
                using (OracleConnection Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("spr_IUMantenimiento", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_ACCION", OracleDbType.Varchar2, 1).Value = Accion;
                    Cmd.Parameters.Add("p_CODIGOEQUIPO", OracleDbType.Int32, 10).Value = mantenimiento.codigoequipo;
                    Cmd.Parameters.Add("p_DOCUMENTO", OracleDbType.Int32, 10).Value = mantenimiento.documento;
                    Cmd.Parameters.Add("p_FECHA", OracleDbType.Date, 10).Value = mantenimiento.fecha;
                    Cmd.Parameters.Add("p_OBSERVACIONES", OracleDbType.Varchar2, 255).Value = mantenimiento.observaciones;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", OracleDbType.Int32, 10).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", OracleDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Int32 Resultado = (Int32)(Oracle.ManagedDataAccess.Types.OracleDecimal)Cmd.Parameters["p_RESULTADO"].Value;
                    LiberarRecursos();
                    return Resultado;
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /*
       =======================================================================================================================================================
       Fin Operaciones sobre estructura Mantenimiento
       =======================================================================================================================================================
       */


        public int EliminarRegistro(string DatoEliminar, string Tabla)
        {
            int Resultado = 0;
            try
            {

                using (OracleConnection Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("spr_DRegistro", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", OracleDbType.Varchar2, 20).Value = Tabla;
                    Cmd.Parameters.Add("p_CONDICION", OracleDbType.Int32, 10).Value = DatoEliminar;
                    Cmd.Parameters.Add("p_RESULTADO", OracleDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    Resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                    LiberarRecursos();
                    return Resultado;
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private void LiberarRecursos()
        {
            Cmd.Dispose();
            if (Cn != null)
            {
                Cn.Close();
                Cn.Dispose();
            }
        }

    }
}
