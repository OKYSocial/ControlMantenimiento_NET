﻿Option Strict On

Public Class Equipo ' Clase que respresenta la estructura Equipos en BD

    Private _CodigoEquipo As Integer
    Private _NombreEquipo As String
    Private _CodigoMarca As Integer
    Private _Serie As String
    Private _CodigoLinea As Integer
    Private _Lubricacion As Integer

    Public Sub New()

    End Sub

    Public Property CodigoEquipo() As Integer
        Get
            Return _CodigoEquipo
        End Get
        Set(ByVal value As Integer)
            _CodigoEquipo = value
        End Set
    End Property

    Public Property NombreEquipo() As String
        Get
            Return _NombreEquipo
        End Get
        Set(ByVal value As String)
            _NombreEquipo = value
        End Set
    End Property

    Public Property CodigoMarca() As Integer
        Get
            Return _CodigoMarca
        End Get
        Set(ByVal value As Integer)
            _CodigoMarca = value
        End Set
    End Property

    Public Property Serie() As String
        Get
            Return _Serie
        End Get
        Set(ByVal value As String)
            _Serie = value
        End Set
    End Property

    Public Property CodigoLinea() As Integer
        Get
            Return _CodigoLinea
        End Get
        Set(ByVal value As Integer)
            _CodigoLinea = value
        End Set
    End Property

    Public Property Lubricacion() As Integer
        Get
            Return _Lubricacion
        End Get
        Set(ByVal value As Integer)
            _Lubricacion = value
        End Set
    End Property

End Class
