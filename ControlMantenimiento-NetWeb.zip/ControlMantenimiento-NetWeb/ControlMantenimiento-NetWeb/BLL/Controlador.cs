﻿// Este es el Controlador Manager general de todo el sistema. Todo tiene que pasar por esta clase
using System;
using ControlMantenimiento_NetWeb.DAL;
using ControlMantenimiento_NetWeb.BO;
using System.Collections;


namespace ControlMantenimiento_NetWeb.BLL
{
    public class Controlador
    {
        private readonly IAccesoDatos _accesoDatos;        

        public Controlador(IAccesoDatos accesoDatos)
        {
            _accesoDatos = accesoDatos;
        }
        
        public ArrayList CargarListas(string Tabla, string Condicion)
        {
            return _accesoDatos.CargarListas(Tabla, Condicion);
        }

        public ArrayList CargarListado(string Tabla, string Condicion)
        {
            return _accesoDatos.CargarListado(Tabla, Condicion);
        }

        public ArrayList ControlProgramacion(string Tabla)
        {
            return _accesoDatos.ControlProgramacion(Tabla);
        }               

        public int ValidarTablaVacia(string Tabla)
        {
            return _accesoDatos.ValidarTablaVacia(Tabla);
        }

  
        // Obtener Registro
        public Object ObtenerRegistro(string DatoBuscar, string Tabla)
        {
            Object objeto = null;
            switch (Tabla)
            {
                case "OPERARIOS":
                    objeto = _accesoDatos.ObtenerOperario(DatoBuscar);
                    break;
                case "EQUIPOS":
                    objeto = _accesoDatos.ObtenerEquipo(DatoBuscar);
                    break;
                case "MANTENIMIENTO":
                    objeto = _accesoDatos.ObtenerMantenimiento(DatoBuscar);
                    break;
                case "LISTAVALORES":
                    objeto = _accesoDatos.ObtenerListaValores(DatoBuscar);
                    break;
            }
            return objeto;
        }

        public Operario ObtenerAcceso(string DatoBuscar, string Clave)
        {
            Operario operario = null;
            operario = _accesoDatos.ObtenerAcceso(DatoBuscar, Clave);
            return operario;
        }
  
       
        // Grabar en BD
        public int Guardar(object o, string Accion)
        {
            int status = 0;
            if (o is Operario)
            {
                Operario operario = (Operario)o;
                status = _accesoDatos.GuardarOperario(operario, Accion, Funciones.UsuarioConectado);
            }
            else if (o is Mantenimiento)
            {
                Mantenimiento mantenimiento = (Mantenimiento)o;
                status = _accesoDatos.GuardarMantenimiento(mantenimiento, Accion, Funciones.UsuarioConectado);
            }
            else if (o is Equipo)
            {
                Equipo equipo = (Equipo)o;
                status = _accesoDatos.GuardarEquipo(equipo, Funciones.UsuarioConectado);
            }
            else if (o is ListaValores)
            {
                ListaValores listavalores = (ListaValores)o;
                status = _accesoDatos.GuardarListaValores(listavalores, Funciones.UsuarioConectado);
            }
            
            return status;
        }                

        public int GuardarCambioClave(string ClaveAnterior, string ClaveNueva)
        {
            return _accesoDatos.GuardarCambioClave(Funciones.UsuarioConectado, ClaveAnterior, ClaveNueva);
        }

       
        // Eliminar Registro
        public int EliminarRegistro(string DatoEliminar, string Tabla)
        {
            return _accesoDatos.EliminarRegistro(DatoEliminar, Tabla);
        }



    }
}
