﻿using ControlMantenimiento_NetWeb.DAL; // Patron de Creacion: Factory Method

namespace ControlMantenimiento_NetWeb.BO
{
    public static class AccesoDatosFactory
    {
        public static IAccesoDatos GetAccesoDatos()
        {
            return new AccesoDatos();
        }
    }
}
