﻿using System;


namespace ControlMantenimiento_NetWeb.Forms
{
    public partial class WebFormRespuesta : System.Web.UI.Page
    {
        
    }
}
