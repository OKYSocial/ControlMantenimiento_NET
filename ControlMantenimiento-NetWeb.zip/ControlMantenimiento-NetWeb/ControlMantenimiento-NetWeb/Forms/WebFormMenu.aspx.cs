﻿using System;
using ControlMantenimiento_NetWeb.BLL;


namespace ControlMantenimiento_NetWeb.Forms
{
    public partial class WebFormMenu : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["TIPO_USUARIO"] == null)
            {
                Response.Redirect("~/Forms/WebFormAcceso.aspx");
            }
            if (Session["TIPO_USUARIO"].ToString() != "1")
            {              
                LinkButton2.Enabled = false;
                LinkButton3.Enabled = false;
                LinkButton4.Enabled = false;               
                LinkButton5.Enabled = false;                
            }
            Funciones.ParametroBuscar = null;
            lblUsuarioConectado.Text = "Bienvenido: " + " " + Session["NOMBRE_USUARIO"].ToString();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            if (Session["TIPO_USUARIO"].ToString() != "1")
            {
                Response.Redirect("~/Forms/WebFormOperarios.aspx");
            }
            else
            {
                Response.Redirect("~/Forms/WebFormListadoOperarios.aspx");
            }
        }
        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Forms/WebFormListadoEquipos.aspx");
        }
        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Forms/WebFormListadoMarcas.aspx");
        }
        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Forms/WebFormListadoLineas.aspx");
        }

        protected void LinkButton5_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Forms/WebFormListadoMantenimientos.aspx");
        }
        protected void LinkButton6_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Forms/WebFormCambioClave.aspx");
        }

        

        
    }
}
