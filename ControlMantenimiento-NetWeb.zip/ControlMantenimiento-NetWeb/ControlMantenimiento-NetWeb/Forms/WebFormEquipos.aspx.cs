﻿using System;
using ControlMantenimiento_NetWeb.BO;
using ControlMantenimiento_NetWeb.BLL;
using System.Collections;

namespace ControlMantenimiento_NetWeb.Forms
{
    public partial class WebFormEquipos : System.Web.UI.Page
    {
        
        protected void Page_Init(object sender, EventArgs e)
        {
            ArrayList arlListado = new ArrayList();
            ArrayList arlListadoMarcas = new ArrayList();
            ArrayList arlListadoLineas = new ArrayList();

            Controlador controlador = Funciones.CrearControlador();
            arlListado = controlador.ControlProgramacion("CONTROLEQUIPOS");

            for (int i = 0; i < arlListado.Count; i++)
            {
                if (Convert.ToString(arlListado[i]).Trim().Equals("MARCAS"))
                {
                    arlListadoMarcas.Add(new CargaCombosListas(arlListado[i + 1].ToString(), arlListado[i + 1].ToString() + " " + arlListado[i + 2].ToString()));
                    i++; i++;
                }
                else if (Convert.ToString(arlListado[i]).Trim().Equals("LINEAS"))
                {
                    arlListadoLineas.Add(new CargaCombosListas(arlListado[i + 1].ToString(), arlListado[i + 1].ToString() + " " + arlListado[i + 2].ToString()));
                    i++; i++;
                }
            }

            DropDownListMarcas.DataValueField = "CODIGO";
            DropDownListMarcas.DataTextField = "DETALLE";
            DropDownListMarcas.DataSource = arlListadoMarcas;
            DropDownListMarcas.DataBind();

            DropDownListLineas.DataValueField = "CODIGO";
            DropDownListLineas.DataTextField = "DETALLE";
            DropDownListLineas.DataSource = arlListadoLineas;
            DropDownListLineas.DataBind();

            if (Funciones.ParametroBuscar != null)
            {
                LlenarCampos();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["TIPO_USUARIO"] == null)
            {
                Response.Redirect("~/Forms/WebFormAcceso.aspx");
            }           
        }

        private void LlenarCampos()
        {
            Controlador controlador = Funciones.CrearControlador();
            Equipo equipo = (Equipo)controlador.ObtenerRegistro(Funciones.ParametroBuscar,"EQUIPOS");
            if (equipo != null)
            {
                lblCodigo.Text = equipo.codigoequipo.ToString();                
                DropDownListMarcas.SelectedValue = equipo.codigomarca.ToString();
                TextBoxNombre.Text = equipo.nombreequipo.Trim();
                TextBoxSerie.Text = equipo.serie.Trim();
                DropDownListLineas.SelectedValue = equipo.codigolinea.ToString();
                CheckBoxLubricacion.Checked = equipo.lubricacion == 1 ? CheckBoxLubricacion.Checked = true : CheckBoxLubricacion.Checked = false;                
            }

            TextBoxNombre.Focus();
        }

        protected void ButtonGrabar_Click(object sender, EventArgs e)
        {
            if (Verificar())
            {
                Guardar(Convert.ToInt32(lblCodigo.Text), (lblCodigo.Text == "0") ? BLL.Mensajes.MensajeGraba : BLL.Mensajes.MensajeActualiza);
            }
        }

        private void Guardar(int ElCodigo, string Mensaje)
        {
            int Resultado;
            Equipo equipo = new Equipo();
            equipo.codigoequipo = ElCodigo;
            equipo.nombreequipo = TextBoxNombre.Text;            
            equipo.codigomarca = Convert.ToInt32(DropDownListMarcas.SelectedValue);
            equipo.codigolinea = Convert.ToInt32(DropDownListLineas.SelectedValue);
            equipo.serie = TextBoxSerie.Text;
            equipo.lubricacion = CheckBoxLubricacion.Checked ? equipo.lubricacion = 1 : equipo.lubricacion = 0;            
            Controlador controlador = Funciones.CrearControlador();
            Resultado = controlador.Guardar(equipo, "");
            if (Resultado == 0)
            {
                equipo = null;
                Funciones.ParametroBuscar = null;
                Response.Redirect("~/Forms/WebFormRespuesta.aspx");
            }
            else if (Resultado == 1)
            {
                TextBoxMensajeError.Text = Mensajes.Mensaje7;
                TextBoxSerie.Focus(); 
            }
            else
            {
                Response.Redirect("~/Forms/WebFormError.aspx");
            }

        }

        private bool Verificar()
        {
            if (Funciones.Validar_CampoVacio(TextBoxNombre.Text))
            {
                TextBoxMensajeError.Text = Mensajes.MensajeCampoRequerido;
                TextBoxNombre.Focus();
                return false;
            }
            if (Funciones.Validar_CampoVacio(TextBoxSerie.Text))
            {
                TextBoxMensajeError.Text = Mensajes.MensajeCampoRequerido;
                TextBoxSerie.Focus();
                return false;
            }           
            return true;
        }

        
        protected void ImageButtonAyuda_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            /* System.Diagnostics.Process proc = new System.Diagnostics.Process();
              proc.EnableRaisingEvents = false;
              proc.StartInfo.FileName = "E:/Fuentes CM/ControlMantenimiento-NetWeb/ControlMantenimiento-NetWeb/ControlMantenimiento-NetWeb/Ayudas/Ayuda.chm";
              proc.Start();
              proc.Dispose();*/

            // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
            // donde descomprimió el archivo descargado de la web
        }
        

    }
}
