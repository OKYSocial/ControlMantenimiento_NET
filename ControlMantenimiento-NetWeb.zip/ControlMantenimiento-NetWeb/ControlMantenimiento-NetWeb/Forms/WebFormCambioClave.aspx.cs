﻿using System;
using ControlMantenimiento_NetWeb.BLL;


namespace ControlMantenimiento_NetWeb.Forms
{
    public partial class WebFormCambioClave : System.Web.UI.Page
    {
        protected void Page_Init(object sender, EventArgs e)
        {          
        }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["TIPO_USUARIO"] == null)
            {
                Response.Redirect("~/Forms/WebFormAcceso.aspx");
            }
        }

        protected void ButtonGrabar_Click(object sender, EventArgs e)
        {
            if (Verificar())
            {
                Guardar();
            }
        }

        private void Guardar()
        {
            Controlador controlador = Funciones.CrearControlador();
            int Resultado = controlador.GuardarCambioClave(TextBoxClave.Text.Trim(), TextBoxClaveNueva.Text.Trim());
            if (Resultado == 0)
            {
                Response.Redirect("~/Forms/WebFormRespuesta.aspx");
            }
            else if (Resultado == 1)

            {
                Response.Redirect("~/Forms/WebFormError.aspx");
            }
            else
            {
                Response.Redirect("~/Forms/WebFormError.aspx");
            }
        }
       
        private bool Verificar()
        {
            if (Funciones.Validar_CampoVacio(TextBoxClave.Text))
            {
                TextBoxMensajeError.Text = Mensajes.MensajeCampoRequerido;
                TextBoxClave.Focus();
                return false;
            }
            if (TextBoxClave.Text.Length < 6)
            {
                TextBoxMensajeError.Text = Mensajes.Mensaje21;
                TextBoxClave.Focus();
                return false;
            }
            if (Funciones.Validar_CampoVacio(TextBoxClaveNueva.Text))
            {
                TextBoxMensajeError.Text = Mensajes.MensajeCampoRequerido;
                TextBoxClaveNueva.Focus();
                return false;
            }
            if (TextBoxClaveNueva.Text.Length < 6)
            {
                TextBoxMensajeError.Text = Mensajes.Mensaje21;
                TextBoxClaveNueva.Focus();
                return false;
            }
            if (TextBoxClaveNueva.Text == TextBoxClave.Text)
            {
                TextBoxMensajeError.Text = Mensajes.Mensaje4;
                TextBoxClaveNueva.Focus();
                return false;
            }
            if (Funciones.Validar_CampoVacio(TextBoxConfirmar.Text))
            {
                TextBoxMensajeError.Text = Mensajes.MensajeCampoRequerido;
                TextBoxConfirmar.Focus();
                return false;
            }
            if (TextBoxConfirmar.Text.Length < 6)
            {
                TextBoxMensajeError.Text = Mensajes.Mensaje21;
                TextBoxConfirmar.Focus();
                return false;
            }
            if (TextBoxConfirmar.Text != TextBoxClaveNueva.Text)
            {
                TextBoxMensajeError.Text = Mensajes.Mensaje5;
                TextBoxConfirmar.Focus();
                return false;
            }

            return true;
        }

    }
}
