﻿using System;
using ControlMantenimiento_NetWeb.BLL;
using System.Web.UI.WebControls;

namespace ControlMantenimiento_NetWeb.Forms
{
    public partial class WebFormListadoMarcas : System.Web.UI.Page
    {
        protected void Page_Init(object sender, EventArgs e)
        {

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["TIPO_USUARIO"] == null)
            {
                Response.Redirect("~/Forms/WebFormAcceso.aspx");
            }
            if (!this.IsPostBack)
            {
                this.BindRepeater();
            }
        }

        private void BindRepeater()
        {
            Controlador controlador = Funciones.CrearControlador();
            Repeater1.DataSource = controlador.CargarListado("MARCAS", "");
            Repeater1.DataBind();
        }



        protected void ButtonBuscar_Click(object sender, EventArgs e)
        {
            TextBoxBuscar.Text = TextBoxBuscar.Text.Trim();
            LabelInformacion.Text = "";
            LabelInformacion.ForeColor = System.Drawing.Color.Red;
            if (string.IsNullOrEmpty(TextBoxBuscar.Text.Trim()))
            {
                LabelInformacion.Text = Mensajes.MensajeCampoRequerido;
                TextBoxBuscar.Focus();
            }
            else if (TextBoxBuscar.Text.Substring(0, 1) == "0")
            {
                LabelInformacion.Text = Mensajes.Mensaje6;
                TextBoxBuscar.Focus();
            }
            else
            {
                Controlador controlador = Funciones.CrearControlador();
                Repeater1.DataSource = controlador.CargarListas("MARCAS", TextBoxBuscar.Text);
                Repeater1.DataBind();
            }

        }



        protected void Repeater1_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "Editar")
            {
                Funciones.ParametroBuscar = ((Button)e.CommandSource).CommandArgument;
                Funciones.Pagina = "MARCAS";
                Response.Redirect("~/Forms/WebFormListaValores.aspx");
            }

            else if (e.CommandName == "Eliminar")
            {
                int Resultado;
                Controlador controlador = Funciones.CrearControlador();
                Resultado = controlador.EliminarRegistro(((Button)e.CommandSource).CommandArgument, "LISTAVALORES");

                if (Resultado == 0)
                {
                    Response.Redirect("~/Forms/WebFormListadoMarcas.aspx");
                }
                else if (Resultado == 1)
                {
                    LabelInformacion.Text = Mensajes.Mensaje9;
                }
                else
                {
                    LabelInformacion.Text = Mensajes.MensajeErrorBD;
                    Response.Redirect("~/Forms/WebFormError.aspx");
                }
            }

        }

        protected void ButtonNuevo_Click(object sender, EventArgs e)
        {
            Funciones.Pagina = "MARCAS";
            Response.Redirect("~/Forms/WebFormListavalores.aspx");
        }
    }
}
